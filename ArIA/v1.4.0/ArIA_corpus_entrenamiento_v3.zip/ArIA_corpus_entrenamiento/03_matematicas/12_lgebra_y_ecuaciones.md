# Álgebra y ecuaciones

## Definición
El álgebra utiliza símbolos para representar números y relaciones. Una ecuación afirma que dos expresiones tienen el mismo valor para determinados valores de las incógnitas.

## Método de trabajo
Simplifica ambos miembros; realiza la misma operación en ambos lados; agrupa términos semejantes; despeja la incógnita; sustituye el resultado para comprobarlo.

## Ejemplo explicado
En 2x + 3 = 11, resta 3: 2x = 8. Divide entre 2: x = 4. Comprobación: 2·4 + 3 = 11.

## Errores y límites
Al multiplicar una desigualdad por un número negativo, invierte el signo. En ecuaciones con denominadores, comprueba restricciones y soluciones extrañas.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de álgebra y ecuaciones?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
