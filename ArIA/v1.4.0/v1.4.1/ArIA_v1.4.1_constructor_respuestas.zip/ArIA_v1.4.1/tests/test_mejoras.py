import unittest

from aria import mate
from aria.cerebro import quiere_busqueda_web


class MatematicasEnLenguajeNatural(unittest.TestCase):
    def test_operaciones_habladas(self):
        casos = {
            "quanto es 2 por 4?": "8",
            "cuánto es 2 por 4?": "8",
            "cuanto son 50 más 30": "80",
            "divide 100 entre 5": "20",
            "cuanto es 10 menos 3": "7",
            "cuanto es 2 multiplicado por 6": "12",
            "quanto es 9 dividido entre 3": "3",
            "cuanto es 2 al cuadrado": "4",
        }
        for pregunta, resultado in casos.items():
            with self.subTest(pregunta=pregunta):
                respuesta = mate.responder(pregunta)
                self.assertIn(f"**{resultado}**", respuesta)

    def test_busqueda_solo_si_se_pide(self):
        self.assertFalse(quiere_busqueda_web("¿Qué es Python?"))
        self.assertFalse(quiere_busqueda_web("quanto es 2 por 4?"))
        self.assertTrue(quiere_busqueda_web("busca en internet Python"))
        self.assertTrue(quiere_busqueda_web("dame el enlace de la web oficial de Python"))
        self.assertTrue(quiere_busqueda_web("¿Cuál es la web de Python?"))


if __name__ == "__main__":
    unittest.main()


class ComandosYAprendizaje(unittest.TestCase):
    def setUp(self):
        import tempfile
        from aria.cerebro import Cerebro
        from aria.memoria import Memoria
        from aria.config import DEFAULTS
        import copy
        self.tmp = tempfile.TemporaryDirectory()
        self.mem = Memoria(ruta=f"{self.tmp.name}/memoria.db")
        self.cerebro = Cerebro(copy.deepcopy(DEFAULTS), self.mem)

    def tearDown(self):
        self.mem.bd.close()
        self.tmp.cleanup()

    def test_aprender_solo_muestra_ayuda(self):
        for texto in ("Aprender", "aprender", "/Aprender", "/aprender"):
            with self.subTest(texto=texto):
                respuesta = self.cerebro.responder(texto).texto
                self.assertIn("Cómo enseñarme cosas", respuesta)

    def test_aprender_con_contenido_funciona_con_y_sin_barra(self):
        r1 = self.cerebro.responder("aprende que mi gato se llama Mou").texto
        self.assertIn("Apuntado", r1)
        self.assertIn("Mou", self.cerebro.perfil.resumen())
        r2 = self.cerebro.responder("/aprender que mi perro se llama Nube").texto
        self.assertIn("Apuntado", r2)
        self.assertIn("Nube", self.cerebro.perfil.resumen())

    def test_comandos_basicos_y_mayusculas(self):
        self.assertIn("Lo que sé hacer", self.cerebro.responder("/AYUDA").texto)
        self.assertIn("Mi memoria", self.cerebro.responder("/Memoria").texto)
        self.assertIn("Lo que sé de ti", self.cerebro.responder("/fuentes").texto)
        self.assertIn("No conozco ese comando", self.cerebro.responder("/noexiste").texto)

    def test_aprender_tabulador_en_comando(self):
        respuesta = self.cerebro.responder("/aprender\tque mi gato se llama Mou").texto
        self.assertIn("Apuntado", respuesta)


class ReglasMatematicasAprendidas(ComandosYAprendizaje):
    def test_generaliza_propiedad_distributiva(self):
        ensenanza = self.cerebro.responder("aprende que (2+2)*5=20 porque se multiplica cada sumando por 5").texto
        self.assertIn("Propiedad distributiva", ensenanza)
        respuesta = self.cerebro.responder("calcula (3+4)*6").texto
        self.assertIn("**42**", respuesta)
        self.assertIn("propiedad distributiva", respuesta.lower())
        respuesta2 = self.cerebro.responder("cuanto es 8*(10-3)").texto
        self.assertIn("**56**", respuesta2)
        self.assertIn("propiedad distributiva", respuesta2.lower())

    def test_regla_persiste_y_se_puede_consultar(self):
        self.cerebro.responder("aprende que (2+2)*5=20")
        self.assertIn("Propiedad distributiva", self.cerebro.responder("/reglas").texto)
        self.assertIn("reglas generales aprendidas", self.cerebro.responder("/memoria").texto)

    def test_nuevas_formas_de_pedir_calculos(self):
        for pregunta, resultado in (("oye, me puedes calcular 3 por 7", "21"),
                                    ("haz la cuenta de 12 entre 3", "4"),
                                    ("cuanto sale 5 mas 6", "11")):
            with self.subTest(pregunta=pregunta):
                self.assertIn(f"**{resultado}**", mate.responder(pregunta))


class RazonamientoLocalYPrivacidad(unittest.TestCase):
    def setUp(self):
        import tempfile
        from aria.cerebro import Cerebro
        from aria.memoria import Memoria
        from aria.config import DEFAULTS
        import copy
        self.tmp = tempfile.TemporaryDirectory()
        self.mem = Memoria(ruta=f"{self.tmp.name}/memoria.db")
        self.cerebro = Cerebro(copy.deepcopy(DEFAULTS), self.mem)

    def tearDown(self):
        self.mem.bd.close()
        self.tmp.cleanup()

    def test_regla_logica_se_aplica_a_hechos_nuevos(self):
        r1 = self.cerebro.responder("aprende que si algo es mamífero, entonces es vertebrado").texto
        self.assertIn("regla lógica", r1.lower())
        self.cerebro.responder("aprende que un perro es mamífero")
        r2 = self.cerebro.responder("¿un perro es vertebrado?").texto
        self.assertIn("deducir", r2.lower())
        self.assertIn("vertebrado", r2.lower())

    def test_puede_encadenar_reglas_logicas(self):
        self.mem.aprender_regla_logica("mamifero", "vertebrado")
        self.mem.aprender_regla_logica("vertebrado", "animal")
        self.mem.aprender_hecho("perro", "mamifero")
        self.assertTrue(self.mem.inferir_hecho("perro", "animal"))

    def test_recupera_respuestas_con_redaccion_distinta(self):
        self.mem.aprender_qa("¿Qué es la fotosíntesis?", "Proceso por el que las plantas convierten luz en energía química.")
        respuesta = self.mem.mejor_qa("explícame la fotosintesis")
        self.assertIsNotNone(respuesta)
        self.assertIn("energía química", respuesta["respuesta"])

    def test_no_hay_conexion_a_modelos_ni_con_configuracion_antigua(self):
        from aria import llm
        self.assertFalse(llm.activo({"proveedor": "ollama", "modelo": "modelo-cualquiera"}))
        with self.assertRaises(llm.ErrorLLM):
            llm.generar({"proveedor": "openai", "modelo": "x"}, [])

    def test_reutiliza_conocimiento_de_programacion_ensenado(self):
        self.cerebro.responder("aprende que en Python para convertir Celsius a Fahrenheit usa este código: def celsius_a_fahrenheit(c): return c * 9 / 5 + 32")
        respuesta = self.cerebro.responder("escribe un programa para convertir temperaturas en Python").texto
        self.assertIn("patrón de programación", respuesta)
        self.assertIn("celsius_a_fahrenheit", respuesta)


class AnalisisLocal(unittest.TestCase):
    def test_extrae_cifras_razones_y_conclusiones(self):
        from aria.analisis import analizar_texto
        texto = ("La empresa creció un 20% este año. "
                 "Esto ocurrió porque aumentaron las ventas. "
                 "Por tanto, el beneficio mejoró.")
        respuesta = analizar_texto(texto)
        self.assertIn("20%", respuesta)
        self.assertIn("porque", respuesta)
        self.assertIn("Por tanto", respuesta)



class ConfiguracionSinModelosExternos(unittest.TestCase):
    def test_elimina_credenciales_heredadas_de_modelos(self):
        import json, tempfile
        from pathlib import Path
        from unittest.mock import patch
        from aria import config
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            cfg_file = base / "config.json"
            cfg_file.write_text(json.dumps({"llm": {"proveedor": "openai", "api_key": "SECRETO"}, "tema": "oscuro"}), encoding="utf-8")
            with patch.object(config, "DATA_DIR", base), patch.object(config, "CHATS_DIR", base / "chats"), patch.object(config, "CONFIG_FILE", cfg_file):
                cfg = config.cargar()
                persisted = json.loads(cfg_file.read_text(encoding="utf-8"))
            self.assertNotIn("llm", cfg)
            self.assertNotIn("llm", persisted)
            self.assertEqual(cfg["tema"], "oscuro")


class IntegracionAnalisisLocal(unittest.TestCase):
    def setUp(self):
        import tempfile, copy
        from aria.cerebro import Cerebro
        from aria.memoria import Memoria
        from aria.config import DEFAULTS
        self.tmp = tempfile.TemporaryDirectory()
        self.mem = Memoria(ruta=f"{self.tmp.name}/memoria.db")
        self.cerebro = Cerebro(copy.deepcopy(DEFAULTS), self.mem)

    def tearDown(self):
        self.mem.bd.close()
        self.tmp.cleanup()

    def test_comando_analiza_se_interpreta(self):
        texto = "La producción aumentó un 15%. Esto ocurrió porque mejoró el proceso. Por tanto, bajaron los costes."
        respuesta = self.cerebro.responder("analiza este texto: " + texto).texto
        self.assertIn("15%", respuesta)
        self.assertIn("Razones", respuesta)
        self.assertIn("Conclusiones", respuesta)


class MotorGenerativoLocal(unittest.TestCase):
    def test_detecta_intenciones_y_compone_respuesta_con_evidencias(self):
        from aria import razonamiento
        textos = [
            "La fotosíntesis es el proceso por el que las plantas convierten la luz solar en energía química. "
            "La fotosíntesis libera oxígeno porque durante las reacciones se separan moléculas de agua. "
            "Este proceso ocurre en los cloroplastos y utiliza agua y dióxido de carbono."
        ]
        definicion = razonamiento.componer_respuesta("¿Qué es la fotosíntesis?", textos)
        causa = razonamiento.componer_respuesta("¿Por qué la fotosíntesis libera oxígeno?", textos)
        proceso = razonamiento.componer_respuesta("¿Cómo funciona la fotosíntesis?", textos)
        self.assertIn("se puede explicar", definicion["texto"])
        self.assertIn("porque", causa["texto"].lower())
        self.assertIn("funcionamiento", proceso["texto"].lower())
        self.assertGreater(definicion["confianza"], 0.3)

    def test_no_inventa_si_no_hay_evidencia(self):
        from aria import razonamiento
        r = razonamiento.componer_respuesta("¿Cómo se construye un cohete?", [
            "La fotosíntesis es el proceso por el que las plantas convierten luz en energía."
        ])
        self.assertEqual(r["texto"], "")

    def test_expande_sinonimos_localmente(self):
        from aria import razonamiento
        consulta = razonamiento.expandir_consulta("ordenador")
        self.assertIn("computadora", consulta)

    def test_seguimiento_breve_recupera_el_tema(self):
        import tempfile, copy
        from aria.cerebro import Cerebro
        from aria.memoria import Memoria
        from aria.config import DEFAULTS
        with tempfile.TemporaryDirectory() as d:
            mem = Memoria(ruta=f"{d}/memoria.db")
            cerebro = Cerebro(copy.deepcopy(DEFAULTS), mem)
            mem.aprender_texto(
                "La fotosíntesis es el proceso por el que las plantas convierten luz en energía. "
                "La fotosíntesis libera oxígeno porque se separan moléculas de agua.",
                fuente="usuario:nota", titulo="Fotosíntesis")
            cerebro.responder("¿Qué es la fotosíntesis?")
            seguimiento = cerebro.responder("¿Y por qué?").texto
            self.assertIn("explicación", seguimiento.lower())
            self.assertIn("oxígeno", seguimiento.lower())
            mem.bd.close()


class AnalisisProfundoLocal(unittest.TestCase):
    def test_separa_definiciones_causas_contrastes_y_pasos(self):
        from aria.analisis import analizar_texto
        texto = (
            "La energía solar es una fuente renovable que procede del Sol. "
            "Primero, los paneles captan la radiación y después la convierten en electricidad. "
            "Esto ocurre porque las células fotovoltaicas transforman la luz en corriente. "
            "Sin embargo, la producción puede disminuir durante la noche. "
            "Por tanto, conviene combinarla con sistemas de almacenamiento."
        )
        r = analizar_texto(texto)
        for esperado in ("Definiciones", "Razones, causas", "Contrastes", "Pasos", "Consecuencias"):
            self.assertIn(esperado, r)

    def test_distingue_opinion_e_incertidumbre(self):
        from aria.analisis import analizar_texto
        r = analizar_texto("Creo que el proyecto podría funcionar bien. Tal vez necesite más pruebas.")
        self.assertIn("requieren cautela", r)
        self.assertIn("Creo que", r)


class PreguntasCompuestasEContexto(unittest.TestCase):
    def test_compone_ventajas_y_desventajas_con_evidencias_distintas(self):
        import tempfile, copy
        from aria.cerebro import Cerebro
        from aria.memoria import Memoria
        from aria.config import DEFAULTS
        with tempfile.TemporaryDirectory() as d:
            mem = Memoria(ruta=f"{d}/memoria.db")
            cerebro = Cerebro(copy.deepcopy(DEFAULTS), mem)
            mem.aprender_texto(
                "La energía solar es renovable y procede de la radiación del Sol. "
                "Sus ventajas incluyen que no produce emisiones directas durante la generación y que reduce la dependencia de combustibles fósiles. "
                "Sin embargo, la producción depende de la luz disponible y puede bajar durante la noche. "
                "Las baterías permiten almacenar electricidad para utilizarla más tarde.",
                fuente="usuario:nota", titulo="Energía solar")
            respuesta = cerebro.responder("¿Cuáles son las ventajas y desventajas de la energía solar?").texto.lower()
            self.assertIn("ventajas", respuesta)
            self.assertIn("sin embargo", respuesta)
            self.assertIn("noche", respuesta)
            mem.bd.close()

    def test_seguimiento_como_funciona_conserva_tema(self):
        import tempfile, copy
        from aria.cerebro import Cerebro
        from aria.memoria import Memoria
        from aria.config import DEFAULTS
        with tempfile.TemporaryDirectory() as d:
            mem = Memoria(ruta=f"{d}/memoria.db")
            cerebro = Cerebro(copy.deepcopy(DEFAULTS), mem)
            mem.aprender_texto(
                "La energía solar es renovable y procede de la radiación del Sol. "
                "Los paneles captan la radiación y la convierten en electricidad.",
                fuente="usuario:nota", titulo="Energía solar")
            cerebro.responder("¿Qué es la energía solar?")
            respuesta = cerebro.responder("¿Cómo funciona?").texto.lower()
            self.assertIn("paneles", respuesta)
            mem.bd.close()


class GeneracionEstadisticaLocal(unittest.TestCase):
    def setUp(self):
        import tempfile
        from aria.cerebro import Cerebro
        from aria.memoria import Memoria
        from aria.config import DEFAULTS
        import copy
        self.tmp = tempfile.TemporaryDirectory()
        self.mem = Memoria(ruta=f"{self.tmp.name}/memoria.db")
        self.cerebro = Cerebro(copy.deepcopy(DEFAULTS), self.mem)

    def tearDown(self):
        self.mem.bd.close()
        self.tmp.cleanup()

    def test_aprender_texto_entrena_modelo_y_persiste(self):
        texto = ("Los robots exploran jardines antiguos y encuentran semillas brillantes. "
                 "Los robots estudian las plantas y aprenden cómo crecen bajo la luz del sol. "
                 "En el jardín, las máquinas riegan las flores y observan los cambios del clima. "
                 "Cada robot comparte sus descubrimientos con otros exploradores del bosque. " * 5)
        self.mem.aprender_texto(texto, fuente="usuario:corpus", titulo="Robots")
        stats = self.mem.generador.estadisticas()
        self.assertGreater(stats["tokens"], 80)
        self.assertGreater(stats["transiciones"], 0)
        resultado = self.mem.generador.generar("robots", [texto], semilla=7)
        self.assertTrue(resultado["texto"])
        self.assertIn("robot", resultado["texto"].lower())

    def test_modelo_ngram_persiste_al_reabrir_base_de_datos(self):
        texto = ("Los volcanes expulsan lava y ceniza durante las erupciones. "
                 "La actividad volcánica modifica el paisaje y crea nuevas rocas. " * 12)
        self.mem.aprender_texto(texto, fuente="usuario:volcanes", titulo="Volcanes")
        antes = self.mem.generador.estadisticas()["tokens"]
        ruta = self.mem.bd.execute("PRAGMA database_list").fetchone()[2]
        self.mem.bd.close()
        from aria.memoria import Memoria
        reabierta = Memoria(ruta=ruta)
        try:
            self.assertEqual(reabierta.generador.estadisticas()["tokens"], antes)
        finally:
            reabierta.bd.close()

    def test_comando_generar_y_estadisticas(self):
        texto = ("Los dragones viven en montañas lejanas y protegen antiguos tesoros. "
                 "Los dragones vuelan sobre los valles cuando sale el sol. "
                 "En las montañas, los viajeros estudian las huellas de estas criaturas. " * 8)
        self.mem.aprender_texto(texto, fuente="usuario:dragones", titulo="Dragones")
        respuesta = self.cerebro.responder("/generar una historia sobre dragones").texto
        self.assertIn("Texto generado localmente", respuesta)
        self.assertIn("dragones", respuesta.lower())
        estado = self.cerebro.responder("/modelo").texto
        self.assertIn("Tokens de entrenamiento", estado)

    def test_generacion_natural_no_se_confunde_con_pregunta_factual(self):
        texto = ("Los bosques guardan historias antiguas entre sus árboles. "
                 "Los exploradores caminan por senderos y descubren animales. "
                 "Cada amanecer ilumina las hojas y despierta nuevos sonidos. " * 8)
        self.mem.aprender_texto(texto, fuente="usuario:bosque", titulo="Bosque")
        respuesta = self.cerebro.responder("inventa una historia sobre bosques").texto
        self.assertIn("Texto generado localmente", respuesta)
        respuesta_escribe = self.cerebro.responder("escribe una historia de bosques").texto
        self.assertIn("Texto generado localmente", respuesta_escribe)
        factual = self.cerebro.responder("¿Cuál es la capital de Marte?").texto
        self.assertIn("No sé responder", factual)

    def test_olvidar_borra_tambien_el_entrenamiento(self):
        texto = ("Las ballenas recorren océanos profundos y se comunican mediante sonidos. "
                 "Los océanos contienen ecosistemas complejos y muchas especies. " * 10)
        self.mem.aprender_texto(texto, fuente="usuario:ballenas", titulo="Ballenas")
        self.assertGreater(self.mem.generador.estadisticas()["tokens"], 0)
        self.mem.olvidar()
        self.assertEqual(self.mem.generador.estadisticas()["tokens"], 0)
        self.assertEqual(self.mem.generador.estadisticas()["documentos"], 0)


class TransformerDesdeCero(unittest.TestCase):
    def test_entrena_checkpoint_local_y_lo_borra_al_olvidar(self):
        import importlib.util
        if importlib.util.find_spec("torch") is None:
            self.skipTest("PyTorch no está instalado")
        import tempfile
        from aria.memoria import Memoria
        with tempfile.TemporaryDirectory() as tmp:
            mem = Memoria(ruta=f"{tmp}/memoria.db")
            try:
                corpus = " ".join(
                    f"Los robots numero {i} aprenden a explorar jardines y a reconocer flores de colores. "
                    f"En el laboratorio {i} descubren patrones nuevos y comparten sus resultados."
                    for i in range(100)
                )
                mem.aprender_texto(corpus, fuente="usuario:corpus-gpt", titulo="Corpus de entrenamiento")
                resultado = mem.transformer.entrenar(pasos=1, batch_size=4, bloque=64)
                self.assertTrue(resultado["ok"], resultado)
                self.assertTrue(mem.transformer.disponible())
                self.assertTrue(mem.transformer.ruta.is_file())
                mem.aprender_texto("Una nueva fuente añade información al corpus y cambia el conocimiento del asistente.",
                                   fuente="usuario:nueva-fuente", titulo="Actualización")
                self.assertFalse(mem.transformer.disponible())
                self.assertTrue(mem.transformer.estado()["desactualizado"])
                mem.olvidar()
                self.assertFalse(mem.transformer.disponible())
                self.assertFalse(mem.transformer.ruta.exists())
            finally:
                mem.bd.close()


class IdentidadNuclearArIA(unittest.TestCase):
    def test_preguntas_sobre_creadora_y_ayudantes(self):
        from aria import nucleo
        casos = [
            "Hola ArIA, quen te ha creado?",
            "quien te ha creado?",
            "quién es tu creadora y quién ayudó a crearte?",
            "quien te creo y quien te ayudo?",
            "qui t'ha creat i qui t'ha ajudat?",
            "háblame de tu creadora",
        ]
        for pregunta in casos:
            with self.subTest(pregunta=pregunta):
                respuesta = nucleo.responder(pregunta)
                self.assertIsNotNone(respuesta)
                self.assertIn("Aria català", respuesta)
                self.assertIn("Claude", respuesta)
                self.assertIn("CatGPT", respuesta)

    def test_identidad_va_antes_que_el_corpus(self):
        import tempfile, copy
        from aria.cerebro import Cerebro
        from aria.memoria import Memoria
        from aria.config import DEFAULTS
        with tempfile.TemporaryDirectory() as d:
            mem = Memoria(ruta=f"{d}/memoria.db")
            try:
                mem.aprender_texto("La creadora de ArIA es una persona distinta y el ayudante es otro.",
                                   fuente="archivo:corpus.txt", titulo="Corpus")
                cerebro = Cerebro(copy.deepcopy(DEFAULTS), mem)
                r = cerebro.responder("quien te ha creado y quien te ayudo?").texto
                self.assertIn("Aria català", r)
                self.assertIn("Claude", r)
                self.assertIn("CatGPT", r)
                self.assertNotIn("persona distinta", r)
            finally:
                mem.bd.close()

    def test_no_confunde_pregunta_sobre_otro_creador(self):
        from aria import nucleo
        self.assertIsNone(nucleo.responder("quien creo Python?"))


class LecturaPromptsMejorada(unittest.TestCase):
    def test_limpia_caracteres_invisibles_y_espacios_de_pdf(self):
        from aria.entrada import limpiar_entrada
        self.assertEqual(limpiar_entrada("\ufeff  hola\u200b\u00a0ArIA  "), "hola ArIA")

    def test_preguntas_en_catala_detectan_intencion(self):
        from aria.razonamiento import detectar_intencion
        self.assertEqual(detectar_intencion("Per què funciona l'energia solar?"), "causa")
        self.assertEqual(detectar_intencion("Com funciona un ordinador?"), "proceso")
        self.assertEqual(detectar_intencion("Quins són els avantatges?"), "ventajas")

    def test_respuesta_compuesta_en_catala(self):
        from aria.razonamiento import componer_respuesta
        r = componer_respuesta("Quins són els avantatges?", [
            "Un dels avantatges de l'energia solar és que és renovable i no produeix emissions directes durant la generació."
        ])
        self.assertTrue(r["texto"].startswith("Els avantatges"))


class CalidadRespuestaYCorpus(unittest.TestCase):
    def test_no_devuelve_rutas_como_evidencias(self):
        from aria import razonamiento
        resultado = razonamiento.componer_respuesta(
            "¿Qué es un ordenador?",
            ["/home/usuario/Documents/ArIA_corpus_entrenamiento/01_lengua/documento.txt"],
        )
        self.assertEqual(resultado["texto"], "")

    def test_no_responde_con_coincidencia_de_una_palabra_ajena(self):
        import tempfile, copy
        from aria.cerebro import Cerebro
        from aria.memoria import Memoria
        from aria.config import DEFAULTS
        with tempfile.TemporaryDirectory() as d:
            mem = Memoria(ruta=f"{d}/memoria.db")
            cerebro = Cerebro(copy.deepcopy(DEFAULTS), mem)
            try:
                mem.aprender_texto(
                    "Este documento trata sobre novelas históricas y sus personajes principales. " * 5,
                    fuente="archivo:novela.txt", titulo="Novela")
                respuesta = cerebro.responder("¿Cómo funciona un ordenador cuántico?").texto
                self.assertIn("No sé responder", respuesta)
                self.assertNotIn("novelas históricas", respuesta)
            finally:
                mem.bd.close()

    def test_elimina_rutas_del_corpus_neuronal(self):
        from aria.transformer_local import _limpiar_linea_corpus
        self.assertEqual(_limpiar_linea_corpus("/home/usuario/Documents/ArIA/corpus/a.txt"), "")
        self.assertEqual(_limpiar_linea_corpus("Un ordenador procesa instrucciones."), "Un ordenador procesa instrucciones.")


class ConstructorRespuestasMejorado(unittest.TestCase):
    def test_explica_un_concepto_con_definicion_componentes_y_ejemplo(self):
        from aria import razonamiento
        documento = """# Componentes del ordenador

## Definición
Un ordenador combina hardware y software. La CPU ejecuta instrucciones; la RAM mantiene datos temporales; el almacenamiento conserva datos; la placa base conecta componentes y los periféricos permiten entrada y salida.

## Método de trabajo
Relaciona cada componente con su función y sus límites. Evalúa compatibilidad, consumo, refrigeración, capacidad y necesidades reales antes de elegir piezas.

## Ejemplo explicado
Al abrir un programa, sus instrucciones y datos se cargan desde almacenamiento a memoria y la CPU los procesa.

## Errores y límites
Más núcleos o más memoria no garantizan por sí solos mayor rendimiento. Importan la carga de trabajo y el equilibrio del sistema."""
        r = razonamiento.componer_respuesta("Explícame qué es un ordenador", [documento])
        texto = r["texto"]
        self.assertIn("Un ordenador combina hardware y software", texto)
        self.assertIn("La CPU ejecuta instrucciones", texto)
        self.assertIn("Al abrir un programa", texto)
        self.assertNotIn("Componentes del ordenador", texto)
        self.assertNotIn("## Definición", texto)
        self.assertTrue(texto.startswith("El concepto se puede explicar"))

    def test_respuesta_integrada_recupera_y_construye_explicacion_completa(self):
        import tempfile, copy
        from aria.cerebro import Cerebro
        from aria.memoria import Memoria
        from aria.config import DEFAULTS
        documento = """# Componentes del ordenador

## Definición
Un ordenador combina hardware y software. La CPU ejecuta instrucciones; la RAM mantiene datos temporales; el almacenamiento conserva datos; la placa base conecta componentes y los periféricos permiten entrada y salida.

## Ejemplo explicado
Al abrir un programa, sus instrucciones y datos se cargan desde almacenamiento a memoria y la CPU los procesa."""
        with tempfile.TemporaryDirectory() as d:
            mem = Memoria(ruta=f"{d}/memoria.db")
            try:
                mem.aprender_texto(documento, fuente="corpus:componentes", titulo="Componentes del ordenador")
                respuesta = Cerebro(copy.deepcopy(DEFAULTS), mem).responder("Explícame qué es un ordenador").texto
                self.assertIn("Un ordenador combina hardware y software", respuesta)
                self.assertIn("La CPU ejecuta instrucciones", respuesta)
                self.assertIn("Al abrir un programa", respuesta)
                self.assertNotIn("## Definición", respuesta)
            finally:
                mem.bd.close()

    def test_no_confunde_castellano_con_catala_por_explicame(self):
        from aria.razonamiento import _es_catalan
        self.assertFalse(_es_catalan("Explícame qué es un ordenador"))
        self.assertTrue(_es_catalan("Explica'm què és un ordinador"))

    def test_descarta_metadatos_y_etiquetas_del_glosario(self):
        from aria import razonamiento
        r = razonamiento.componer_respuesta("¿Qué es un ordenador?", [
            "# Glosario y relaciones: Componentes del ordenador\n"
            "Concepto central: componentes del ordenador.\n"
            "Definición breve: Un ordenador combina hardware y software."
        ])
        self.assertIn("Un ordenador combina hardware y software", r["texto"])
        self.assertNotIn("Concepto central", r["texto"])
        self.assertNotIn("Glosario y relaciones", r["texto"])
