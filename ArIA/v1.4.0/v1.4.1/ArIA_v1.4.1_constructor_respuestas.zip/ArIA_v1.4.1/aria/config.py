"""Rutas y configuración de ArIA."""
import copy
import json
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("ARIA_DATA", BASE_DIR / "data"))
CHATS_DIR = DATA_DIR / "chats"
CONFIG_FILE = DATA_DIR / "config.json"
DB_FILE = DATA_DIR / "memoria.db"

DEFAULTS = {
    "nombre_usuario": "",
    "tema": "claro",
    "buscar_en_internet": True,
    "aprender_de_internet": True,
    "ejecutar_codigo": True,
    "umbral_cobertura": 0.6,
    "paginas_por_busqueda": 2,
    "carpetas_permitidas": [],
}


def _fusionar(base, extra):
    for clave, valor in extra.items():
        if isinstance(valor, dict) and isinstance(base.get(clave), dict):
            _fusionar(base[clave], valor)
        else:
            base[clave] = valor


def cargar():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CHATS_DIR.mkdir(parents=True, exist_ok=True)
    cfg = copy.deepcopy(DEFAULTS)
    if CONFIG_FILE.exists():
        try:
            _fusionar(cfg, json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            pass
    # Eliminar y persistir la retirada de credenciales/endpoints antiguos de IA.
    tenia_llm = "llm" in cfg
    cfg.pop("llm", None)
    if tenia_llm:
        guardar(cfg)
    return cfg


def guardar(cfg):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(
        json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8"
    )
