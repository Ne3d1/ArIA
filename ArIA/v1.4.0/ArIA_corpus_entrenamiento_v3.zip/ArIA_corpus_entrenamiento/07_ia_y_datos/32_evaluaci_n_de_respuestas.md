# Evaluación de respuestas

## Definición
Evaluar una respuesta requiere comprobar si responde a la petición, si está respaldada, si es coherente y si reconoce incertidumbre.

## Método de trabajo
Crea preguntas de prueba; define criterios; incluye preguntas no respondibles; mide precisión y cobertura; inspecciona errores; repite tras cada cambio.

## Ejemplo explicado
Para una pregunta factual, una rúbrica puede puntuar exactitud, relevancia, claridad y trazabilidad a fuentes.

## Errores y límites
No evalúes solo por longitud o fluidez. Una respuesta convincente puede ser incorrecta.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de evaluación de respuestas?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
