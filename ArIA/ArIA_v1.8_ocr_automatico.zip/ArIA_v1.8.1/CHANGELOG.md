# ArIA v1.8.1

## Corrección del OCR en Windows

- `setup.bat` repara automáticamente los idiomas OCR `spa` y `eng` en vez de limitarse a avisar.
- Nuevo módulo `aria.instalar_ocr`: copia los modelos ya instalados y descarga los que falten desde el repositorio oficial `tessdata_fast`.
- Los modelos se almacenan en `%LOCALAPPDATA%\ArIA\tessdata`, evitando permisos de administrador.
- La captura de pantalla usa y valida ese directorio con `--tessdata-dir`.
- Suite de pruebas automatizadas: validación de descargas simuladas, rutas y comprobación de idiomas.
