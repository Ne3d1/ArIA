# Comprensió i redacció en català

## Definición
La comprensió lectora en català demana identificar el tema, la idea principal, les idees secundàries, els connectors i la intenció comunicativa.

## Método de trabajo
Llegeix el text sencer; marca els conceptes clau; separa dades i opinions; resumeix amb paraules pròpies; revisa que no hi hagi informació afegida.

## Ejemplo explicado
En un text argumentatiu, diferencia la tesi, els arguments, els exemples i la conclusió.

## Errores y límites
No tradueixis literalment expressions castellanes si en català hi ha una forma pròpia més natural.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de comprensió i redacció en català?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
