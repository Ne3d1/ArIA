#!/usr/bin/env bash
# Ejecuta ArIA en Linux/macOS, también desde USB sin soporte de enlaces simbólicos.
set -e
cd "$(dirname "$0")"
source ./aria_env.sh
aria_resolve_venv
VENV_PY="$ARIA_VENV_DIR/bin/python"
if [ ! -x "$VENV_PY" ] || ! "$VENV_PY" -c 'import requests, bs4, ddgs, sympy, pypdf, docx, mss, PIL, pytesseract, psutil, pygetwindow, rapidfuzz, torch' 2>/dev/null; then
  echo "Preparando o reparando el entorno en: $ARIA_VENV_DIR ..."
  bash ./setup.sh
  source ./aria_env.sh
  aria_resolve_venv
  VENV_PY="$ARIA_VENV_DIR/bin/python"
fi
exec "$VENV_PY" main.py "$@"
