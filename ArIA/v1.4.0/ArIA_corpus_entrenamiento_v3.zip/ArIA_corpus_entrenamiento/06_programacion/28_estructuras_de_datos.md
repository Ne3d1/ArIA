# Estructuras de datos

## Definición
Las estructuras de datos organizan valores para facilitar operaciones. Listas, pilas, colas, conjuntos, diccionarios, árboles y grafos tienen propiedades distintas.

## Método de trabajo
Elige según operaciones frecuentes: acceso por posición, búsqueda, inserción, eliminación, pertenencia o recorrido. Considera memoria y orden.

## Ejemplo explicado
Un diccionario es adecuado para asociar un identificador de usuario con su perfil; un conjunto sirve para evitar elementos duplicados.

## Errores y límites
No existe una estructura mejor para todo. La elección depende de datos, operaciones y restricciones.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de estructuras de datos?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
