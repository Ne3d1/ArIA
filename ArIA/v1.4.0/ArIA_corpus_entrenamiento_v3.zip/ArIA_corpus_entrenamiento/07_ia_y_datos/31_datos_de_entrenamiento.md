# Datos de entrenamiento

## Definición
Un corpus es una colección de materiales usados para enseñar o evaluar un sistema. Su utilidad depende de cobertura, precisión, diversidad, estructura y licencias.

## Método de trabajo
Elimina duplicados; separa temas; conserva metadatos; incluye ejemplos y contraejemplos; registra procedencia; evita datos privados; crea conjuntos de evaluación separados.

## Ejemplo explicado
Un corpus de programación puede incluir conceptos, ejemplos correctos, errores frecuentes, explicaciones y pruebas pequeñas.

## Errores y límites
Más texto no siempre significa más aprendizaje. Datos repetidos, contradictorios o de baja calidad pueden empeorar resultados.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de datos de entrenamiento?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
