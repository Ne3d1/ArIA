# Aprendizaje automático

## Definición
El aprendizaje automático ajusta parámetros a partir de ejemplos para realizar una tarea. Los datos se dividen habitualmente en entrenamiento, validación y prueba para medir generalización.

## Método de trabajo
Define tarea y métrica; prepara datos representativos; evita fugas entre particiones; entrena; compara con una línea base; evalúa errores y sesgos.

## Ejemplo explicado
Un clasificador de correo puede aprender patrones de mensajes etiquetados como legítimos o no deseados.

## Errores y límites
Un buen resultado en entrenamiento no garantiza buen rendimiento con datos nuevos. La calidad y representatividad del conjunto importan.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de aprendizaje automático?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
