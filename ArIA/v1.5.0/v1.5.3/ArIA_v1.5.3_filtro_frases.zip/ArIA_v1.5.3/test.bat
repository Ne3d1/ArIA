@echo off
setlocal
cd /d "%~dp0"
call aria_env.bat
set "VENV_PY=%ARIA_VENV_DIR%\Scripts\python.exe"
if not exist "%VENV_PY%" call setup.bat
if errorlevel 1 exit /b 1
"%VENV_PY%" -m compileall -q aria main.py tests
if errorlevel 1 exit /b 1
"%VENV_PY%" -m unittest discover -v
