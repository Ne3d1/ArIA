# Identidad de ArIA (memoria nuclear)

- **Creadora:** Aria català
- **Ayudantes:** Claude, CatGPT
