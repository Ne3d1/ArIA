#!/usr/bin/env bash
# Selecciona un entorno virtual compatible con el sistema de archivos.
# En USB FAT/exFAT sin enlaces simbólicos usa la caché del usuario.
aria_resolve_venv() {
  if [ -n "${ARIA_VENV_DIR:-}" ]; then
    export ARIA_VENV_DIR
    return 0
  fi
  local probe="$PWD/.aria_symlink_probe_$$"
  local target="$PWD/.aria_symlink_target_$$"
  : > "$target" 2>/dev/null || true
  if [ -e "$target" ] && ln -s "$(basename "$target")" "$probe" 2>/dev/null; then
    rm -f "$probe" "$target"
    ARIA_VENV_DIR="$PWD/.venv"
  else
    rm -f "$probe" "$target" 2>/dev/null || true
    local root="${XDG_CACHE_HOME:-$HOME/.cache}/aria/venvs"
    local key
    key=$(printf '%s' "$(pwd -P)" | sha256sum 2>/dev/null | cut -c1-16)
    if [ -z "$key" ]; then key=$(printf '%s' "$(pwd -P)" | cksum | awk '{print $1}'); fi
    ARIA_VENV_DIR="$root/$key"
  fi
  export ARIA_VENV_DIR
}
