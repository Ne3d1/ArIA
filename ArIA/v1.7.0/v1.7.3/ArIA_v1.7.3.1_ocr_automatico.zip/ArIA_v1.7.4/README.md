# ArIA v1.7.4 — Corrección de instalación OCR en Windows

Esta versión corrige un fallo detectado al preguntar «¿Qué es la computación cuántica?»: una página institucional que solo mencionaba el Instituto de Computación Cuántica podía desplazar a páginas que sí explicaban los qubits y el funcionamiento.

Cambios de v1.5.2:
- La puntuación de fuentes tiene en cuenta el título y penaliza menciones incidentales.
- Se descartan páginas con pertinencia insuficiente antes de redactar y guardar.
- La investigación web ya no recurre a un resumen arbitrario si el constructor no encuentra evidencias adecuadas.
- Si los resultados solo mencionan el tema, ArIA lo reconoce en vez de fingir una explicación.
- Se mantienen las URL y los títulos como procedencia del conocimiento guardado.

Las puntuaciones son heurísticas de pertinencia, no verificaciones de verdad. Las pruebas automatizadas no sustituyen una comprobación de búsqueda real en Internet.

---

# ArIA 🤖

**Versión del proyecto: 1.7.4**

Asistente de chat local en español, con ventana sencilla (Tkinter), mensajes en **Markdown**, memoria que
aprende, búsqueda en internet, matemáticas, programación básica y acceso a archivos con permiso.

## Instalación y arranque

| | Linux / macOS | Windows |
|---|---|---|
| **Montar el proyecto** (una vez) | `./setup.sh` | doble clic en `setup.bat` |
| **Ejecutar** | `./run.sh` | doble clic en `run.bat` |
| **Ejecutar pruebas** | `./test.sh` | doble clic en `test.bat` |

- Necesitas **Python 3.9+**. `setup.bat` / `setup.sh` instala todas las dependencias declaradas en `requirements.txt`, verifica los módulos y comprueba conflictos con `pip check`. En Linux, si el proyecto está en un USB que no admite enlaces simbólicos, el entorno se crea en `~/.cache/aria/venvs/`; en Windows se crea en `%LOCALAPPDATA%\ArIA\venvs\`. Los datos del proyecto siguen en su carpeta. Cada sistema operativo mantiene su propio entorno Python. `run.bat` y `run.sh` también detectan un entorno incompleto y reparan la instalación automáticamente. Si falta Tesseract OCR, el instalador pregunta si quieres instalarlo (winget en Windows; apt/dnf/pacman/brew en sistemas compatibles). En Windows, ArIA busca también en las rutas habituales de instalación aunque el PATH no se haya actualizado; puedes indicar otra ruta con `TESSERACT_CMD`. El OCR de pantalla requiere los idiomas español (`spa`) e inglés (`eng`): `setup.bat` los prepara automáticamente, copiando los modelos existentes o descargando los que falten desde `tessdata_fast`. Se guardan en `%LOCALAPPDATA%\ArIA\tessdata`, sin modificar `Program Files` ni requerir permisos de administrador.
- El generador estadístico usa Python estándar y SQLite. Para entrenar el GPT pequeño desde cero se instala **PyTorch** (`torch`); el paquete es un framework de cálculo, no un modelo. ArIA no descarga pesos ni checkpoints preentrenados.
- En Linux, la ventana necesita Tkinter: `sudo apt install python3-tk` (Fedora: `python3-tkinter`, Arch: `tk`).
- El proyecto puede ejecutarse instalado en el disco del PC o desde una memoria USB. No se comparte un entorno virtual entre Windows y Linux: cada sistema crea el suyo en una ubicación compatible.
- Modo texto (sin ventana): `./run.sh --cli` / `run.bat --cli`. Otra carpeta de datos: `--datos RUTA`.

## Qué sabe hacer

| Área | Ejemplos |
|---|---|
| **Aprender** | `Aprender` o `/aprender` para ver ejemplos · `aprende que mi gato se llama Mou` · `cuando te pregunte X, responde Y` · `aprende que si algo es mamífero, entonces es vertebrado` · `aprende que un perro es mamífero` · guarda patrones de programación · 👍/👎 |
| **Internet** | `busca en internet qué es la fotosíntesis` · `dame el enlace de la web oficial de Python`. Solo busca cuando se lo pides expresamente; guarda resultados y cita fuentes |
| **Matemáticas** | `quanto es 2 por 4` · `me puedes calcular 3 por 7` · `haz la cuenta de 12 entre 3` · `50 más 30` · `2+3*4` · `calcula sqrt(81)` · `15% de 200` · `5!` · `resuelve x^2-5x+6=0` · `deriva x^3` · `integra sin(x)` · aprende y aplica la propiedad distributiva |
| **Programación** | `escribe un programa de fibonacci en python` · `escribe fizzbuzz y ejecútalo` · `ejecuta` + bloque ```` ``` ```` |
| **Pantalla y programas** | Botón `🪟 Programas` para consultar nombres de procesos/ventanas con permiso · `👁 Analizar pantalla` para capturar el monitor principal y extraer texto con OCR local; muestra una vista previa y pide confirmación antes del análisis. No guarda capturas ni OCR automáticamente. |
| **Generación local** | `/generar una historia sobre ...` · `inventa una historia sobre ...` · `/modelo` para consultar el entrenamiento |
| **Análisis** | `analiza este texto: ...` · `analiza el archivo ruta` (con permiso) · extrae ideas centrales, cifras, razones y conclusiones expresadas |
| **Archivos** | `lee el archivo ruta` · `resume el archivo ruta` · `aprende del archivo ruta` · `aprende de la carpeta ruta` · `lista la carpeta ruta` · botones 📎 y 📁 |
| **Comandos** | `/ayuda` · `/aprender` · `/memoria` · `/reglas` · `/fuentes` · `/perfil` · `/personas` · `/olvidar` · `/olvidar texto` |

Lee `.txt .md .py .json .csv .html … .pdf .docx`.

## Recuerda quién eres (perfil)

ArIA guarda en `data/memoria.db` un perfil por persona y lo recuerda entre sesiones (castellano y catalán):

| Qué | Ejemplos |
|---|---|
| **Con quién habla** | `me llamo Ana` · `em dic Pau` · `soy Marta` (cambia de persona) · `quién soy` · `a quién conoces` |
| **Gustos** | `me gusta el té y las motos` · `no me gusta el frío` · `qué me gusta` · `ya no me gusta el té` |
| **Datos** | `vivo en Girona` · `tengo 25 años` · `trabajo de…` · `mi cumpleaños es…` · `mi gato se llama Mou` · `mi color favorito es el verde` |
| **Preferencias** | `sé más breve` / `sé más detallado` (cambia la longitud de mis respuestas) · `respóndeme en catalán` (se guarda como preferencia; las respuestas integradas se adaptan cuando hay traducción local) |
| **Consultar / borrar** | `qué sabes de mí` · `cuál es mi color favorito` · `/perfil` · `/personas` · `olvida mi gato` · `olvídame` |

Cada persona tiene su propio perfil. Al abrir ArIA recuerda la última persona y te lo avisa; si eres otra, di `soy …`.
`/olvidar` borra el conocimiento aprendido, pero **no** los perfiles (para eso, `olvídame`).

## Memoria intocable 🔒

ArIA tiene una identidad nuclear integrada en el código: **creadora: Aria català; ayudantes: Claude y CatGPT**.
Pregúntale `quién te creó`, `quién es tu creadora`, `quién te ayudó a crearte` o `háblame de tu creadora`.

- Vive en `aria/nucleo.py`, no en la base de datos: `/olvidar` o borrar `data/` no la eliminan.
- Se consulta antes que el corpus y la memoria recuperada, para evitar que documentos de entrenamiento sustituyan estos datos.
- `aria/identidad.md` es una copia legible para personas; la fuente de verdad es el módulo nuclear.
- Los intentos de sustituir esta identidad mediante instrucciones del chat se rechazan.

## Cómo "aprende"

ArIA mantiene una **memoria propia** en SQLite (`data/memoria.db`) con búsqueda por relevancia (BM25). Todo lo que le enseñas, lee de archivos o encuentra en internet se guarda en fragmentos y se recupera al preguntar; las respuestas informativas se construyen combinando esas evidencias mediante un motor local de composición y razonamiento. Los pares pregunta→respuesta que le enseñas o que valoras con 👍 tienen prioridad. No inicia búsquedas web automáticamente: primero consulta la memoria y solo consulta internet ante una orden explícita.

### Generación de texto local

ArIA incluye ahora `aria/generador.py`, un **modelo estadístico de lenguaje de n-gramas con backoff** (trigramas, bigramas y unigramas), muestreo por temperatura, penalización de repeticiones y entrenamiento incremental. Aprende transiciones lingüísticas de los textos que incorporas con `aprende que ...`, `aprende del archivo ...` y `aprende de la carpeta ...`, además de ejemplos pregunta→respuesta. El entrenamiento se guarda en SQLite y persiste entre sesiones.

- `/generar una historia sobre dragones` o `inventa una historia sobre dragones`: busca fragmentos relacionados y crea una continuación estadística a partir de ellos.
- `/modelo`: muestra documentos, tokens, transiciones y el estado del GPT.
- `/entrenar-modelo` o `/entrenar-modelo 500`: entrena desde cero un pequeño GPT de caracteres con PyTorch. El valor indica pasos de optimización; empieza con 100 y aumenta si tienes un corpus grande y paciencia.
- `/olvidar`: borra las transiciones aprendidas y el checkpoint GPT; al olvidar una fuente concreta, reconstruye el modelo estadístico con lo que queda y elimina el GPT para que no conserve datos olvidados.

El GPT es una **red neuronal causal tipo Transformer** (4 bloques, 6 cabezas de atención y dimensión 192), con embeddings, atención causal multi-cabeza y bloques MLP. Su vocabulario de caracteres y todos sus pesos se inicializan aleatoriamente y se entrenan con la memoria local. No es un modelo preentrenado: con corpus pequeño y pocas iteraciones generará texto imperfecto; necesita muchos textos variados y entrenamiento sostenido para mejorar. El instalador selecciona la compilación CPU de PyTorch en Windows/Linux para no descargar bibliotecas CUDA. Al incorporar nuevos textos, el GPT se marca como desactualizado y ArIA vuelve al n-grama hasta que lo reentrenes. El generador estadístico n-grama queda como respaldo si aún no hay un GPT actualizado. Ambos pueden repetir frases, mezclar contextos o cometer errores; por eso se limitan a peticiones creativas explícitas y marcan sus textos como no verificados. Las preguntas factuales siguen usando recuperación de evidencias y razonamiento, no texto estadístico como si fueran hechos.

### Aprendizaje de reglas matemáticas

Además de guardar ejemplos literales, ArIA reconoce algunos patrones matemáticos. Por ejemplo, al enseñarle
`aprende que (2+2)*5=20`, detecta que el ejemplo demuestra la **propiedad distributiva**, guarda la regla en
SQLite y puede aplicarla a cálculos nuevos como `(3+4)*6` o `8*(10-3)`, mostrando el desarrollo. Consulta lo
aprendido con `/reglas`. Este aprendizaje de reglas es explícito y ampliable: no significa que ArIA pueda deducir
automáticamente cualquier ley a partir de cualquier frase o ejemplo. También puede encadenar reglas lógicas
que le enseñes (por ejemplo, mamífero → vertebrado → animal) sobre hechos concretos guardados en su memoria.

La interpretación del lenguaje combina normalización de tildes, expansión local de sinónimos, tolerancia a errores de escritura y similitud difusa (RapidFuzz). Las respuestas que le enseñas se pueden recuperar aunque cambies la redacción. El motor `razonamiento.py` identifica si preguntas por definiciones, causas, procesos, comparaciones, ventajas, desventajas o ejemplos; descompone algunas preguntas compuestas, busca evidencias para cada parte, elimina repeticiones y redacta una respuesta estructurada. También puede mantener el tema en preguntas de seguimiento como «¿y por qué?» o «ponme ejemplos».

La composición informativa selecciona y reorganiza evidencias, combina varias frases, adapta la introducción al tipo de pregunta y estima cuánto encajan las fuentes con la consulta. Esa cifra es una medida heurística, no una garantía de verdad. El módulo `analisis.py` separa definiciones, razones, consecuencias, contrastes, secuencias, recomendaciones, cifras, conclusiones y expresiones de incertidumbre u opinión. La memoria prioriza lo que enseña el usuario y puede reutilizar reglas lógicas encadenadas y patrones de programación guardados.

**Límite importante:** el generador estadístico local no tiene la comprensión ni la fluidez de un LLM moderno. No voy a añadir modelos externos ni disfrazar el n-grama como una red neuronal. La forma de mejorarlo sin IA externa es alimentarlo con un corpus amplio, limpio, variado y con permisos de uso adecuados, y evaluar sus resultados con pruebas.

**Modelos externos prohibidos por diseño:** ArIA no ofrece campos para Ollama, OpenAI ni otros proveedores. Las configuraciones antiguas se eliminan al cargar Ajustes y el módulo de compatibilidad rechaza cualquier intento de conexión. El razonamiento, la recuperación de memoria, los resúmenes y el análisis OCR se realizan localmente. La búsqueda web solo se activa cuando se solicita expresamente y no es una llamada a un modelo de IA.

**Contenido adulto (+18):** no he encontrado en el código un filtro general que bloquee conversaciones por mencionar sexo, desnudez o temas adultos; no se añade ninguno. El GPT local es pequeño y se entrena desde cero con el corpus disponible; no tiene la amplitud ni la comprensión de un LLM moderno y no garantiza una generación libre y coherente de cualquier petición. Las protecciones de archivos y permisos son independientes del contenido adulto.

## Análisis de pantalla y privacidad

- La consulta de programas/ventanas y cada captura requieren permiso explícito.
- La captura se procesa en memoria; ArIA no guarda la imagen. El OCR se muestra para revisión antes de analizarlo.
- El OCR y su análisis se realizan localmente. ArIA no envía texto ni imágenes a modelos externos.
- La función no controla el ratón ni el teclado, no hace clic y no modifica programas.

## Privacidad y seguridad

- Nunca lee archivos fuera de las carpetas permitidas sin preguntarte (*Denegar / Solo esta vez / Permitir siempre*).
- Se niega a leer archivos que parecen sensibles (`.env`, claves SSH, contraseñas…).
- Ejecutar código **siempre pide confirmación**, tiene límite de 10 s y se puede desactivar en ⚙ Ajustes.
- Los datos (memoria, chats `.md`, ajustes) están en `data/`. Bórrala para empezar de cero.

## Estructura

```
main.py            punto de entrada
aria/cerebro.py    decide cómo responder
aria/memoria.py    memoria y aprendizaje (SQLite + BM25 + similitud difusa)
aria/analisis.py   análisis textual estructurado y explicable local
aria/razonamiento.py motor de intención, recuperación y composición de respuestas
aria/generador.py  modelo estadístico local de lenguaje (n-gramas) y generación
aria/transformer_local.py GPT causal pequeño entrenado desde cero con PyTorch
aria/web.py        Wikipedia, DuckDuckGo y lectura de páginas
aria/mate.py       aritmética segura + álgebra (sympy)
aria/codigo.py     plantillas de código y ejecución
aria/archivos.py   lectura de archivos con permisos
aria/llm.py        bloqueo de compatibilidad (modelos externos desactivados)
aria/gui.py        ventana Tkinter + render Markdown + permisos de pantalla
aria/pantalla.py   consulta de procesos/ventanas y OCR local
```


## Corpus de entrenamiento ampliado

El proyecto incorpora el corpus v3 (137 documentos, español y catalán) en `recursos/ArIA_corpus_entrenamiento_v3.zip`. Para importarlo usa `./importar_corpus.sh` en Linux o `importar_corpus.bat` en Windows. El importador procesa el ZIP directamente, incorpora ejemplos JSONL como pares pregunta→respuesta y evita almacenar las líneas JSON como texto crudo.

## Independencia de modelos externos

ArIA no importa ni llama a OpenAI, Claude, CatGPT, Ollama, Hugging Face ni a otros proveedores de modelos. `torch` es únicamente una biblioteca local de cálculo con la que ArIA entrena sus propios pesos desde cero; no descarga ni carga modelos preentrenados. La búsqueda web, cuando el usuario la solicita expresamente, recupera páginas y no utiliza otra IA para generar respuestas.

## Importar el corpus de entrenamiento v3

El proyecto incluye `recursos/ArIA_corpus_entrenamiento_v3.zip` (137 documentos, aproximadamente 231.000 caracteres de texto). Para incorporarlo a la memoria documental local:

- Linux: `./importar_corpus.sh`
- Windows: `importar_corpus.bat`
- También puedes indicar otro ZIP: `./importar_corpus.sh /ruta/al/corpus.zip`

La importación es incremental: los fragmentos ya guardados no se duplican. Lee TXT, Markdown, RST, CSV, TSV, XML y HTML directamente desde el ZIP, sin extraerlo entero; convierte los JSONL de ejemplos y diálogos en pares pregunta→respuesta en vez de guardar JSON crudo. Los manifiestos JSON se omiten. No tiene un límite artificial por tamaño de archivo; procesa los contenidos por bloques. La lectura de archivos sueltos y carpetas también se hace por bloques o páginas, sin el antiguo tope de 30 MB ni el límite de 300 documentos por carpeta. La importación alimenta la memoria recuperable, pero **no equivale a entrenar el Transformer**. Después puedes usar `/entrenar-modelo`.

### Calidad de respuesta y generación

- Las respuestas informativas solo se construyen cuando hay evidencias con cobertura suficiente de la pregunta original; los sinónimos ya no inflan artificialmente esa cobertura.
- Si las coincidencias son débiles, ArIA reconoce que no tiene información suficiente en vez de presentar una ruta o un fragmento irrelevante.
- El compositor filtra rutas absolutas y ruido de indexación.
- El GPT de caracteres exige al menos 10.000 caracteres limpios antes de entrenar. Los checkpoints antiguos entrenados con corpus diminutos se consideran no aptos y deben reentrenarse.
- El texto generado se somete a controles básicos de calidad. Si parece una ruta, una repetición o una secuencia sin suficiente contenido lingüístico, no se presenta como una generación válida.

Pruebas: `./test.sh` o `test.bat`.

### Constructor de respuestas (v1.4.1)

El compositor ahora limpia encabezados Markdown que pueden quedar unidos al texto al trocear documentos, elimina etiquetas editoriales del glosario y reconstruye explicaciones con varias evidencias relacionadas. En preguntas definitorias puede combinar la definición, los componentes y un ejemplo del mismo material, manteniendo el texto respaldado por las fuentes. También corrige la detección de idioma que confundía «explícame» en castellano con una forma catalana. La composición es simbólica y extractiva: no se presenta como generación neuronal ni inventa contenido que no esté respaldado.


## Investigación y aprendizaje desde Internet (v1.5.1)

ArIA incorpora un flujo de investigación web sin modelos generativos externos:

- `investiga tema`, `busca en internet tema`, `/investiga tema` y `/buscar tema` lanzan una búsqueda explícita.
- `aprende de internet sobre tema` busca, sintetiza con el constructor local y guarda los fragmentos extraídos en la memoria SQLite.
- Si está activada la opción **Buscar automáticamente si no encuentro respuesta en mi memoria**, ArIA consulta la web solo después de no encontrar una respuesta local adecuada.
- **Guardar en mi memoria lo que encuentre en Internet** controla la persistencia de los textos.
- Consulta fuentes y enlaces al final de la respuesta; `/fuentes` y `/olvidar <dominio o URL>` permiten revisar o retirar información aprendida.
- Puede extraer páginas HTML y PDF públicos que permitan acceso.
- La selección de fuentes ahora puntúa la relación entre consulta y contenido, favorece páginas explicativas con prosa suficiente y evita priorizar titulares promocionales o preguntas de marketing.
- Deduplica tanto URLs como textos casi idénticos y procura diversidad de dominios para no contar una misma explicación varias veces.
- La composición web ya no muestra un porcentaje de coincidencia como si fuera una señal de confianza. El ajuste léxico interno no demuestra veracidad.
- El mensaje de aprendizaje distingue explícitamente entre guardar fragmentos extraídos y verificar hechos: guardar texto no significa que cada afirmación sea cierta ni que el Transformer haya sido entrenado.
- El buscador consulta DuckDuckGo y Wikipedia; no utiliza APIs de LLM, pesos preentrenados ni servicios de generación externos.

**Privacidad:** al realizar una búsqueda, el texto de la consulta se envía al proveedor de búsqueda y las páginas seleccionadas se solicitan directamente. El contenido se procesa en el equipo y solo se conserva en memoria local si el ajuste de aprendizaje web está activado. Desactivar la búsqueda automática evita consultas inesperadas; las peticiones explícitas siguen funcionando mientras Internet esté habilitado.

**Seguridad y límites:** se bloquean direcciones privadas/locales, puertos no estándar y redirecciones hacia destinos no públicos; se limitan bytes, páginas y caracteres extraídos. Los sitios pueden bloquear el acceso, requerir JavaScript, autenticar usuarios o presentar contenido dinámico; en esos casos ArIA puede no leerlos. Los documentos web son datos no confiables: no pueden cambiar instrucciones ni configuración de ArIA. La extracción de PDF depende de que el documento contenga texto seleccionable; OCR de PDF escaneados no está integrado en este módulo.

Pruebas: `./test.sh` o `test.bat`. La suite incluye controles de calidad textual, penalización de contenido promocional, deduplicación de contenido, comandos, almacenamiento local y validación de URLs/redirecciones.


## Investigación web y filtro de evidencias (v1.5.3)

La v1.5.3 añade un segundo filtro, frase por frase, después de seleccionar las páginas: descarta llamadas a escuchar podcasts, suscripciones y promoción; exige relación léxica directa con el tema; y, ante preguntas «qué es», exige al menos una frase definitoria antes de responder o guardar contenido. La memoria web recibe solo las frases seleccionadas, no el texto completo de cada página. Si no aparece una definición directa, ArIA reconoce que no tiene evidencia suficiente en vez de improvisar una explicación con frases sueltas.

Este filtro es heurístico: mejora la pertinencia, pero no verifica la verdad de las afirmaciones. Las pruebas automatizadas usan datos simulados y no sustituyen una validación con búsquedas reales.


## Validación estricta de definiciones (v1.5.4)

La v1.5.4 corrige un falso positivo del filtro anterior: una frase sobre una subcategoría (por ejemplo, «computación cuántica óptica») o una mención incidental («es de interés para…») ya no cuenta como definición del concepto general. Para preguntas «qué es», la frase debe comenzar por el sujeto exacto consultado y definirlo mediante una estructura explícita («es un tipo…», «es el proceso…», «consiste en…», etc.). Además, solo se conservan y guardan las evidencias de las fuentes que contienen esa definición directa. Si no existe, la búsqueda falla de forma conservadora y no añade fragmentos a la memoria.

Las 68 pruebas automatizadas incluyen el caso de regresión de la computación cuántica óptica y la biografía de Román Orús. Son pruebas con datos simulados; no equivalen a una comprobación de buscadores y páginas en directo.


## Síntesis general de evidencias (v1.6.0)

La v1.6.0 añade una capa de síntesis multi-fuente diseñada para preguntas de cualquier disciplina, no para un tema concreto:

- Extrae afirmaciones completas y conserva la relación con la fuente de origen.
- Consolida definiciones equivalentes para evitar repetir la misma idea con distintas palabras.
- Usa conceptos de afirmaciones relevantes como anclas para recuperar detalles complementarios que no repiten literalmente el tema.
- Selecciona aportaciones distintas en lugar de acumular frases con alto solapamiento léxico.
- Cuenta dominios distintos que respaldan una misma formulación y lo presenta como coincidencia entre fuentes, nunca como prueba de verdad.
- Elimina el porcentaje de «ajuste temático» de la respuesta visible: una puntuación léxica no es una probabilidad de exactitud.
- Mantiene el constructor local de memoria y los seguimientos contextuales; la nueva síntesis multi-fuente se aplica a resultados web identificados.

El filtro de definiciones ya no depende de una lista de alias específica de computación cuántica: utiliza las definiciones encontradas como anclas conceptuales y propaga relaciones entre frases dentro de las fuentes y entre ellas. La memoria solo recibe las afirmaciones seleccionadas.

**Límites de esta versión:** la coincidencia entre dominios no demuestra independencia editorial ni veracidad; todavía no existe un detector semántico fiable de contradicciones ni una base de datos de afirmaciones verificadas. Tampoco se ha validado una búsqueda en directo durante la preparación de este ZIP. La suite automatizada usa páginas simuladas.

La versión incluye pruebas de síntesis multi-fuente y de generalización a fotosíntesis y memoria RAM, además de las regresiones previas.


## Investigación por subtareas (v1.7.0)

La v1.7.0 corrige el rechazo de preguntas complejas cuando ninguna página individual contiene toda la respuesta. El planificador conserva la pregunta original y, cuando detecta varias entidades versionadas o varias dimensiones explícitas, genera búsquedas más específicas. Por ejemplo, una comparación entre PCIe 3.0, 4.0, 5.0 y 6.0 con velocidades y fechas produce una búsqueda general y búsquedas por cada generación. También reconoce listas abreviadas que heredan el prefijo ("PCIe 3.0, 4.0, 5.0 y 6.0").

- Se agregan resultados de las distintas búsquedas y se deduplican por URL.
- Cada fuente se examina frente a la pregunta y frente a las entidades concretas detectadas.
- Se combinan evidencias parciales de fuentes diferentes antes de construir la respuesta.
- Si faltan evidencias para alguna entidad, ArIA debe indicarlo y responder solo sobre los elementos respaldados.
- Las preguntas sencillas mantienen una sola búsqueda; no se multiplican peticiones innecesariamente.

**Límites:** el planificador es heurístico y léxico, no un LLM ni un parser semántico universal. La detección de entidades versionadas funciona mejor con nombres y números explícitos. La presencia de una afirmación en una fuente no la convierte en verdadera. Las pruebas de esta versión simulan las respuestas de los buscadores; no se ha ejecutado una investigación web real durante la construcción.


## Evidencia estructurada y aislamiento temático (v1.7.1)

La v1.7.1 corrige los fallos observados al probar comparaciones técnicas e investigación histórica. La búsqueda deja de tratar una página relacionada como si todo su contenido respondiera a la pregunta.

- **Planificación por intención y atributos:** detecta comparaciones, cronologías y preguntas causales. En comparaciones genera consultas por elemento y por dimensión solicitada. Reconoce estándares versionados (PCIe 3.0–6.0) y familias de producto (Intel Core i5/i7/i9, entre otras formas equivalentes).
- **Extracción más estricta:** cada frase debe conectar con varias señales de la consulta o con el título de la misma página. Se evita propagar anclas entre dominios, y se filtran menús comerciales, catálogos y frases promocionales. Los decimales se conservan como una sola unidad al segmentar frases (por ejemplo, `3.0`).
- **Comparaciones estructuradas:** las respuestas pueden producir tablas por entidad y atributo (velocidad, fecha, arquitectura, núcleos, consumo o rendimiento). Cada celda necesita evidencia propia y enlaza a la fuente que la respalda; no se copia una cifra de un modelo o generación a otro.
- **Cronologías:** los acontecimientos que contienen fechas se ordenan cronológicamente. Las causas se presentan como evidencias documentadas, no como una lista causal inventada.
- **Aislamiento temático:** cuando se pide investigar, ArIA no completa una búsqueda fallida con recuerdos locales de otro tema. Si faltan evidencias, lo indica.
- **Cobertura honesta:** diferencia páginas leídas, dominios representados y fragmentos guardados. Guardar un fragmento no equivale a verificarlo ni a entrenar los pesos del Transformer.

**Edad y contenido:** ArIA no incorpora un filtro general basado en la edad ni bloqueos arbitrarios por tratar temas adultos o delicados con fines informativos. Se mantienen las protecciones técnicas independientes del contenido (permisos para acciones locales, validación de URLs y prevención de acceso a redes privadas). No se presenta como un sistema sin límites de seguridad frente a instrucciones que faciliten daños reales.

**Tamaño y procesamiento:** no se impone un límite artificial al tamaño del corpus local ni al tamaño del ZIP de distribución. La importación y el entrenamiento siguen utilizando procesamiento por bloques y recursos del equipo. Las salvaguardas de descarga web (tamaño de respuesta, páginas y tiempo de espera) son límites operativos de red, no límites al tamaño del proyecto ni de los archivos locales.

**Pruebas añadidas:** regresiones para PCIe 3.0–6.0, Intel Core i5/i7/i9, causas de la Segunda Guerra Mundial ordenadas por fecha, rechazo de frases irrelevantes y aislamiento frente a recuerdos de RAM. La suite completa tiene 85 pruebas y se ha ejecutado correctamente. Usa buscadores y páginas simulados: no demuestra que los resultados reales de Internet siempre contengan todos los datos solicitados.

## Cambios de la versión 1.7.4

- El instalador de Windows repara automáticamente los modelos OCR Spanish (`spa`) e English (`eng`) que falten, descargándolos desde `tessdata_fast`.
- Los modelos se guardan en `%LOCALAPPDATA%\ArIA\tessdata`, sin permisos de administrador, y se validan con Tesseract.
