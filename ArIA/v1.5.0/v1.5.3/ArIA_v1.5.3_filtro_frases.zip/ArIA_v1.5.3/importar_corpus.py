#!/usr/bin/env python3
"""Importa el corpus ZIP a la memoria documental local de ArIA.

La importación es incremental e idempotente: los fragmentos ya presentes no se
vuelven a duplicar. No entrena automáticamente el Transformer; primero añade
conocimiento recuperable y permite inspeccionar las estadísticas.
"""
from __future__ import annotations

import argparse
import io
import json
import sys
import zipfile
from pathlib import Path

from aria.memoria import Memoria

FORMATOS = {".txt", ".md", ".rst", ".json", ".jsonl", ".csv", ".tsv", ".xml", ".html", ".htm"}


def _importar_jsonl(texto: str, memoria: Memoria, fuente: str, titulo: str) -> tuple[int, int]:
    """Convierte ejemplos estructurados y diálogos en pares QA, nunca en JSON crudo."""
    pares = fragmentos = 0
    for linea in texto.splitlines():
        if not linea.strip():
            continue
        try:
            dato = json.loads(linea)
        except json.JSONDecodeError:
            continue
        if isinstance(dato, dict) and isinstance(dato.get("prompt"), str) and isinstance(dato.get("response"), str):
            pregunta, respuesta = dato["prompt"].strip(), dato["response"].strip()
            if pregunta and respuesta:
                memoria.aprender_qa(pregunta, respuesta)
                fragmentos += memoria.aprender_texto(respuesta, fuente=fuente, titulo=titulo)
                pares += 1
        turnos = dato.get("turns", []) if isinstance(dato, dict) else []
        anterior = None
        for turno in turnos:
            if not isinstance(turno, dict):
                continue
            rol, contenido = turno.get("role"), turno.get("text", "")
            if rol == "user" and isinstance(contenido, str):
                anterior = contenido.strip()
            elif rol == "assistant" and anterior and isinstance(contenido, str):
                respuesta = contenido.strip()
                if respuesta:
                    memoria.aprender_qa(anterior, respuesta)
                    fragmentos += memoria.aprender_texto(respuesta, fuente=fuente, titulo=titulo)
                    pares += 1
                anterior = None
    return pares, fragmentos


def importar_zip(ruta: Path, memoria: Memoria) -> dict:
    archivos = fragmentos = caracteres = errores = omitidos = pares_qa = 0
    with zipfile.ZipFile(ruta) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            nombre = info.filename
            p = Path(nombre)
            if p.suffix.lower() not in FORMATOS or any(x.startswith(".") for x in p.parts):
                omitidos += 1
                continue
            try:
                fuente = f"corpus:{ruta.name}:{nombre}"
                if p.suffix.lower() == ".jsonl":
                    with zf.open(info, "r") as binario:
                        texto = io.TextIOWrapper(binario, encoding="utf-8", errors="replace").read()
                    caracteres += len(texto)
                    nuevos_qa, nuevos_fragmentos = _importar_jsonl(texto, memoria, fuente, p.name)
                    pares_qa += nuevos_qa
                    fragmentos += nuevos_fragmentos
                elif p.suffix.lower() == ".json":
                    # Los manifiestos describen el corpus, pero no son material lingüístico útil.
                    omitidos += 1
                    continue
                else:
                    with zf.open(info, "r") as binario:
                        texto = io.TextIOWrapper(binario, encoding="utf-8", errors="replace")
                        parte_num = 0
                        while True:
                            bloque = texto.read(256_000)
                            if not bloque:
                                break
                            caracteres += len(bloque)
                            n = memoria.aprender_texto(
                                bloque,
                                fuente=fuente,
                                titulo=p.name if parte_num == 0 else f"{p.name} (parte {parte_num + 1})",
                            )
                            fragmentos += n
                            parte_num += 1
                archivos += 1
            except Exception as exc:
                errores += 1
                print(f"[AVISO] No se pudo importar {nombre}: {exc}", file=sys.stderr)
    return {"archivos": archivos, "fragmentos": fragmentos, "caracteres": caracteres,
            "errores": errores, "omitidos": omitidos, "qa": pares_qa}


def main() -> int:
    parser = argparse.ArgumentParser(description="Importa documentos a la memoria de ArIA")
    parser.add_argument("ruta", nargs="?", default="recursos/ArIA_corpus_entrenamiento_v3.zip",
                        help="ZIP del corpus o paquete compatible")
    args = parser.parse_args()
    ruta = Path(args.ruta).expanduser().resolve()
    if not ruta.is_file():
        print(f"No encuentro el corpus: {ruta}", file=sys.stderr)
        return 2
    memoria = Memoria()
    try:
        resultado = importar_zip(ruta, memoria)
        estado = memoria.estadisticas()
        print("\n=== IMPORTACIÓN DEL CORPUS DE ARIA ===")
        print(f"Archivo: {ruta.name}")
        print(f"Documentos procesados: {resultado['archivos']:,}")
        print(f"Caracteres leídos: {resultado['caracteres']:,}")
        print(f"Fragmentos nuevos: {resultado['fragmentos']:,}")
        print(f"Pares pregunta-respuesta procesados: {resultado['qa']:,}")
        print(f"Pares QA únicos en memoria: {estado['qa']:,}")
        print(f"Archivos con errores: {resultado['errores']:,}")
        print(f"Archivos omitidos por formato: {resultado['omitidos']:,}")
        print(f"Total de fragmentos en memoria: {estado['trozos']:,}")
        print(f"Pares de preguntas y respuestas: {estado['qa']:,}")
        print("\nLa memoria documental está actualizada. Para entrenar el GPT local usa /entrenar-modelo.")
        return 0 if resultado["errores"] == 0 else 1
    finally:
        memoria.bd.close()


if __name__ == "__main__":
    raise SystemExit(main())
