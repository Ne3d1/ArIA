"""Pequeño GPT de caracteres entrenado desde cero con PyTorch.

No descarga checkpoints, tokenizadores ni pesos. El vocabulario y todos los
parámetros se aprenden desde el corpus local de ArIA. Si PyTorch no está
instalado, el módulo se desactiva limpiamente y queda el generador n-grama.
"""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Optional


class TransformerLocal:
    def __init__(self, bd: sqlite3.Connection, ruta_modelo: Optional[Path] = None):
        self.bd = bd
        self.error = ""
        self.torch = None
        try:
            import torch
            self.torch = torch
        except Exception as exc:  # instalación opcional / entorno incompatible
            self.error = f"PyTorch no está disponible: {exc}"
        if ruta_modelo is None:
            fila = bd.execute("PRAGMA database_list").fetchone()
            db_path = fila[2] if fila and len(fila) > 2 else ""
            base = Path(db_path).parent if db_path else Path.cwd() / "data"
            ruta_modelo = base / "modelo_transformer.pt"
        self.ruta = Path(ruta_modelo)
        self._modelo = None
        self._vocabulario = None
        self._stoi = None
        self._config = None
        self._metadatos = {}
        with self.bd:
            self.bd.execute("CREATE TABLE IF NOT EXISTS transformer_meta (clave TEXT PRIMARY KEY, valor TEXT NOT NULL)")
        fila_dirty = self.bd.execute("SELECT valor FROM transformer_meta WHERE clave='desactualizado'").fetchone()
        self._desactualizado = bool(fila_dirty and fila_dirty[0] == "1")
        if self.torch and self.ruta.is_file() and not self._desactualizado:
            try:
                self._cargar()
            except Exception as exc:
                self.error = f"No pude cargar el modelo local: {exc}"

    def disponible(self) -> bool:
        return bool(self.torch and self._modelo is not None and not self._desactualizado)

    def marcar_desactualizado(self):
        """Evita generar con pesos que no incluyen los últimos textos aprendidos."""
        self._desactualizado = True
        with self.bd:
            self.bd.execute("INSERT OR REPLACE INTO transformer_meta(clave,valor) VALUES('desactualizado','1')")

    def invalidar(self):
        """Elimina pesos derivados de datos que el usuario acaba de olvidar."""
        self._modelo = None
        self._vocabulario = None
        self._stoi = None
        self._config = None
        self._metadatos = {}
        self._desactualizado = True
        with self.bd:
            self.bd.execute("INSERT OR REPLACE INTO transformer_meta(clave,valor) VALUES('desactualizado','1')")
        try:
            if self.ruta.exists():
                self.ruta.unlink()
        except OSError as exc:
            self.error = f"No pude borrar el modelo local: {exc}"

    def estado(self) -> dict:
        return {
            "instalado": bool(self.torch),
            "disponible": self.disponible(),
            "desactualizado": self._desactualizado,
            "caracteres": int(self._metadatos.get("caracteres", 0)),
            "pasos": int(self._metadatos.get("pasos", 0)),
            "dispositivo": self._metadatos.get("dispositivo", "no entrenado"),
            "ruta": str(self.ruta),
            "error": self.error,
        }

    def _clases(self):
        torch = self.torch
        nn, F = torch.nn, torch.nn.functional

        class AtencionCausal(nn.Module):
            def __init__(self, dim, cabezas, bloque, dropout):
                super().__init__()
                self.cabezas = cabezas
                self.cabeza_dim = dim // cabezas
                self.qkv = nn.Linear(dim, dim * 3)
                self.proyeccion = nn.Linear(dim, dim)
                self.dropout = nn.Dropout(dropout)
                self.register_buffer("mascara", torch.tril(torch.ones(bloque, bloque)))

            def forward(self, x):
                b, t, c = x.shape
                q, k, v = self.qkv(x).chunk(3, dim=-1)
                q = q.view(b, t, self.cabezas, self.cabeza_dim).transpose(1, 2)
                k = k.view(b, t, self.cabezas, self.cabeza_dim).transpose(1, 2)
                v = v.view(b, t, self.cabezas, self.cabeza_dim).transpose(1, 2)
                pesos = (q @ k.transpose(-2, -1)) * (self.cabeza_dim ** -0.5)
                pesos = pesos.masked_fill(self.mascara[:t, :t] == 0, float("-inf"))
                pesos = self.dropout(F.softmax(pesos, dim=-1))
                salida = (pesos @ v).transpose(1, 2).contiguous().view(b, t, c)
                return self.dropout(self.proyeccion(salida))

        class Bloque(nn.Module):
            def __init__(self, dim, cabezas, bloque, dropout):
                super().__init__()
                self.norma1 = nn.LayerNorm(dim)
                self.atencion = AtencionCausal(dim, cabezas, bloque, dropout)
                self.norma2 = nn.LayerNorm(dim)
                self.mlp = nn.Sequential(
                    nn.Linear(dim, dim * 4), nn.GELU(), nn.Linear(dim * 4, dim), nn.Dropout(dropout)
                )

            def forward(self, x):
                x = x + self.atencion(self.norma1(x))
                return x + self.mlp(self.norma2(x))

        class GPTCaracteres(nn.Module):
            def __init__(self, vocab, bloque=128, dim=128, cabezas=4, capas=3, dropout=0.1):
                super().__init__()
                self.bloque = bloque
                self.token = nn.Embedding(vocab, dim)
                self.posicion = nn.Embedding(bloque, dim)
                self.capas = nn.Sequential(*[Bloque(dim, cabezas, bloque, dropout) for _ in range(capas)])
                self.norma = nn.LayerNorm(dim)
                self.salida = nn.Linear(dim, vocab, bias=False)
                self.salida.weight = self.token.weight

            def forward(self, indices, objetivos=None):
                b, t = indices.shape
                posiciones = torch.arange(t, device=indices.device)
                x = self.token(indices) + self.posicion(posiciones)[None, :, :]
                logits = self.salida(self.norma(self.capas(x)))
                perdida = None
                if objetivos is not None:
                    perdida = F.cross_entropy(logits.reshape(-1, logits.size(-1)), objetivos.reshape(-1))
                return logits, perdida

        return GPTCaracteres

    def _corpus(self, limite=20_000_000) -> str:
        partes, total = [], 0
        for (texto,) in self.bd.execute("SELECT texto FROM trozos ORDER BY id"):
            if total >= limite:
                break
            pieza = (texto or "")[:limite - total]
            if pieza:
                partes.append(pieza)
                total += len(pieza)
        for pregunta, respuesta in self.bd.execute("SELECT pregunta, respuesta FROM qa"):
            if total >= limite:
                break
            pieza = f"\n{pregunta}\n{respuesta}\n"[:limite - total]
            partes.append(pieza)
            total += len(pieza)
        return "\n".join(partes)

    def entrenar(self, pasos: int = 100, batch_size: int = 8, bloque: int = 192,
                 limite_caracteres: int = 50_000_000) -> dict:
        if not self.torch:
            return {"ok": False, "error": self.error or "Instala PyTorch para entrenar el Transformer local."}
        torch = self.torch
        corpus = self._corpus(limite_caracteres)
        if len(corpus) < max(2000, bloque * 8):
            return {"ok": False, "error": f"El corpus tiene {len(corpus):,} caracteres; necesito al menos {max(2000, bloque * 8):,}. Enseña más textos y vuelve a entrenar."}
        vocabulario = sorted(set(corpus))
        stoi = {c: i for i, c in enumerate(vocabulario)}
        datos = torch.tensor([stoi[c] for c in corpus], dtype=torch.long)
        device = "cuda" if torch.cuda.is_available() else ("mps" if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available() else "cpu")
        torch.set_num_threads(max(1, min(8, os.cpu_count() or 1)))
        modelo_cfg = {"bloque": int(bloque), "dim": 192, "cabezas": 6, "capas": 4, "dropout": 0.1}
        Modelo = self._clases()
        modelo = Modelo(len(vocabulario), **modelo_cfg).to(device)
        optimizador = torch.optim.AdamW(modelo.parameters(), lr=3e-4, weight_decay=0.01)
        datos = datos.to(device)
        pasos = max(1, min(int(pasos), 10000))
        batch_size = max(4, min(int(batch_size), 128))
        modelo.train()
        ultima_perdida = 0.0
        for _ in range(pasos):
            inicios = torch.randint(0, len(datos) - bloque - 1, (batch_size,), device=device)
            offsets = torch.arange(bloque, device=device)
            x = datos[inicios[:, None] + offsets]
            y = datos[inicios[:, None] + offsets + 1]
            _, perdida = modelo(x, y)
            optimizador.zero_grad(set_to_none=True)
            perdida.backward()
            torch.nn.utils.clip_grad_norm_(modelo.parameters(), 1.0)
            optimizador.step()
            ultima_perdida = float(perdida.detach().cpu())
        self.ruta.parent.mkdir(parents=True, exist_ok=True)
        temporal = self.ruta.with_suffix(self.ruta.suffix + ".tmp")
        paquete = {
            "state_dict": modelo.cpu().state_dict(),
            "vocabulario": vocabulario,
            "config": modelo_cfg,
            "metadatos": {"caracteres": len(corpus), "pasos": pasos, "perdida": ultima_perdida, "dispositivo": device},
        }
        torch.save(paquete, temporal)
        temporal.replace(self.ruta)
        self._cargar()
        return {"ok": True, **self._metadatos, "perdida": round(ultima_perdida, 4), "ruta": str(self.ruta)}

    def _cargar(self):
        torch = self.torch
        paquete = torch.load(self.ruta, map_location="cpu", weights_only=True)
        self._vocabulario = paquete["vocabulario"]
        self._stoi = {c: i for i, c in enumerate(self._vocabulario)}
        self._config = paquete["config"]
        Modelo = self._clases()
        self._modelo = Modelo(len(self._vocabulario), **self._config)
        self._modelo.load_state_dict(paquete["state_dict"])
        self._modelo.eval()
        self._metadatos = paquete.get("metadatos", {})
        self._desactualizado = False
        with self.bd:
            self.bd.execute("INSERT OR REPLACE INTO transformer_meta(clave,valor) VALUES('desactualizado','0')")

    def generar(self, prompt: str, max_caracteres: int = 700, temperatura: float = 0.85,
                top_k: int = 24, semilla: Optional[int] = None) -> str:
        if not self.disponible():
            return ""
        torch = self.torch
        vocabulario = self._vocabulario
        stoi = self._stoi
        desconocido = stoi.get(" ", 0)
        indices = [stoi.get(c, desconocido) for c in (prompt or "")]
        if not indices:
            indices = [desconocido]
        dispositivo = "cpu"
        entrada = torch.tensor([indices[-self._config["bloque"]:]], dtype=torch.long, device=dispositivo)
        rng = None
        if semilla is not None:
            rng = torch.Generator(device=dispositivo).manual_seed(int(semilla))
        salida = []
        with torch.no_grad():
            for _ in range(max(1, min(int(max_caracteres), 3000))):
                logits, _ = self._modelo(entrada[:, -self._config["bloque"]:])
                logits = logits[:, -1, :] / max(0.2, min(float(temperatura), 1.5))
                k = max(1, min(int(top_k), logits.size(-1)))
                valores, indices_top = torch.topk(logits, k)
                probs = torch.softmax(valores, dim=-1)
                elegido = torch.multinomial(probs, 1, generator=rng)
                siguiente = indices_top.gather(-1, elegido)
                token = int(siguiente.item())
                salida.append(vocabulario[token])
                entrada = torch.cat((entrada, siguiente), dim=1)
                if len(salida) >= 160 and salida[-1] in ".!?" and "\n" in salida:
                    break
        return "".join(salida).strip()
