#!/usr/bin/env bash
# Instala todas las dependencias Python declaradas y comprueba las funciones opcionales.
set -e
cd "$(dirname "$0")"
source ./aria_env.sh
aria_resolve_venv
VENV_PY="$ARIA_VENV_DIR/bin/python"

PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
    PY="$c"; break
  fi
done
if [ -z "$PY" ]; then
  echo "[ERROR] Necesito Python 3.9 o superior. Instálalo (p. ej. sudo apt install python3 python3-venv python3-tk)."
  exit 1
fi
echo "[1/4] Usando $($PY --version)"

if [ ! -x "$VENV_PY" ]; then
  echo "[2/4] Creando entorno virtual en: $ARIA_VENV_DIR ..."
  mkdir -p "$(dirname "$ARIA_VENV_DIR")"
  "$PY" -m venv "$ARIA_VENV_DIR" || { echo "[ERROR] No pude crear el entorno virtual. En Debian/Ubuntu instala python3-venv."; exit 1; }
fi
echo "[3/4] Instalando dependencias de requirements.txt ..."
"$VENV_PY" -m pip install --upgrade pip
if [ "$(uname -s)" = "Darwin" ]; then
  "$VENV_PY" -m pip install -r requirements.txt
else
  # Preferimos la compilación CPU oficial de PyTorch para evitar descargar CUDA.
  "$VENV_PY" -m pip install -r requirements.txt --extra-index-url https://download.pytorch.org/whl/cpu
fi
"$VENV_PY" -m pip check
"$VENV_PY" - <<'PY'
import importlib.util, sys
modulos = {
    "requests": "requests", "beautifulsoup4": "bs4", "ddgs": "ddgs",
    "sympy": "sympy", "pypdf": "pypdf", "python-docx": "docx",
    "mss": "mss", "Pillow": "PIL", "pytesseract": "pytesseract",
    "psutil": "psutil", "pygetwindow": "pygetwindow", "rapidfuzz": "rapidfuzz", "torch": "torch",
}
faltan = [paquete for paquete, modulo in modulos.items() if importlib.util.find_spec(modulo) is None]
if faltan:
    print("[ERROR] No se han instalado estos paquetes: " + ", ".join(faltan))
    sys.exit(1)
print("[OK] Todas las dependencias Python están instaladas.")
PY

# Tesseract es un ejecutable del sistema, no una dependencia pip.
if ! command -v tesseract >/dev/null 2>&1; then
  echo
  echo "[AVISO] Tesseract OCR no está instalado. Solo afecta a la lectura de pantalla/capturas."
  RESPUESTA="n"
  read -r -p "¿Intento instalarlo con el gestor del sistema? [S/n] " RESPUESTA || RESPUESTA="n"
  RESPUESTA=${RESPUESTA:-S}
  if [[ "$RESPUESTA" =~ ^[sS]([iI])?$ ]]; then
    if command -v apt-get >/dev/null 2>&1; then
      if command -v sudo >/dev/null 2>&1; then
        sudo apt-get update && sudo apt-get install -y tesseract-ocr tesseract-ocr-spa tesseract-ocr-eng || true
      else
        echo "Instálalo como administrador: apt install tesseract-ocr tesseract-ocr-spa tesseract-ocr-eng"
      fi
    elif command -v dnf >/dev/null 2>&1; then
      if command -v sudo >/dev/null 2>&1; then sudo dnf install -y tesseract tesseract-langpack-spa tesseract-langpack-eng || true
      else echo "Instálalo como administrador: dnf install tesseract tesseract-langpack-spa tesseract-langpack-eng"; fi
    elif command -v pacman >/dev/null 2>&1; then
      if command -v sudo >/dev/null 2>&1; then sudo pacman -Sy --needed tesseract tesseract-data-spa tesseract-data-eng || true
      else echo "Instálalo como administrador: pacman -S tesseract tesseract-data-spa tesseract-data-eng"; fi
    elif command -v brew >/dev/null 2>&1; then
      brew install tesseract || true
    else
      echo "Instala Tesseract desde https://tesseract-ocr.github.io/"
    fi
  fi
fi

if command -v tesseract >/dev/null 2>&1; then
  LANGS=$(tesseract --list-langs 2>/dev/null || true)
  for lang in spa eng; do
    if ! printf '%s\n' "$LANGS" | grep -qx "$lang"; then
      echo "[AVISO] Falta el idioma OCR '$lang'. Instala el paquete de idioma correspondiente."
    fi
  done
else
  echo "[AVISO] OCR no disponible; el resto de ArIA funciona normalmente."
fi

if ! "$VENV_PY" -c 'import tkinter' 2>/dev/null; then
  echo "[AVISO] Tkinter no está disponible. En Debian/Ubuntu: sudo apt install python3-tk; Fedora: sudo dnf install python3-tkinter; Arch: sudo pacman -S tk."
fi

chmod +x run.sh test.sh 2>/dev/null || true
echo "[4/4] Preparación terminada. Entorno: $ARIA_VENV_DIR"
echo "Ejecuta ./run.sh o ./run.sh --cli."
