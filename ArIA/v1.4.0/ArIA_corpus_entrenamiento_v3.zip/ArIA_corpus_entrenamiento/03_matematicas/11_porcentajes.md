# Porcentajes

## Definición
Un porcentaje expresa una cantidad por cada cien. Para calcular p por ciento de una cantidad x, se multiplica x por p/100.

## Método de trabajo
Distingue porcentaje de puntos porcentuales. Para un aumento, multiplica por 1 + p/100; para una reducción, por 1 − p/100. Para recuperar el valor inicial, divide por el factor aplicado.

## Ejemplo explicado
Un precio de 80 euros que aumenta un 10 % pasa a 88 euros. Si después baja un 10 %, queda en 79,20 euros, no vuelve a 80.

## Errores y límites
Los aumentos y reducciones sucesivos se aplican sobre bases distintas. No sumes porcentajes sin comprobar la base.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de porcentajes?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
