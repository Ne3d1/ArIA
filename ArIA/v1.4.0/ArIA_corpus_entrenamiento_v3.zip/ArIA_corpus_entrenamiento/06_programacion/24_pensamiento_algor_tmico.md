# Pensamiento algorítmico

## Definición
Un algoritmo es una secuencia finita y ordenada de pasos para resolver un problema. Diseñar algoritmos exige definir entradas, salidas, restricciones y casos límite.

## Método de trabajo
Divide el problema; escribe pseudocódigo; elige estructuras; analiza casos normales y extremos; prueba con datos pequeños; estima coste.

## Ejemplo explicado
Para encontrar el mayor de una lista, conserva el mayor observado y recorre los elementos restantes comparando cada uno.

## Errores y límites
Una solución que funciona con el ejemplo dado puede fallar en listas vacías, valores repetidos o entradas inesperadas.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de pensamiento algorítmico?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
