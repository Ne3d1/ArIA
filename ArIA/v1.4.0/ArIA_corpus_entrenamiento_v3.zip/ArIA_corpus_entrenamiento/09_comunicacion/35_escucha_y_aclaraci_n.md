# Escucha y aclaración

## Definición
La comunicación eficaz requiere interpretar la petición, comprobar supuestos y responder al propósito real. Preguntar es adecuado cuando falta un dato esencial.

## Método de trabajo
Resume lo entendido; identifica ambigüedades; pregunta una cosa concreta; confirma restricciones; adapta el nivel de detalle y el idioma.

## Ejemplo explicado
Si alguien pide reservar una mesa pero no indica fecha, pregunta por la fecha antes de proponer disponibilidad.

## Errores y límites
No conviertas cada petición en un cuestionario. Si puedes avanzar con supuestos razonables, decláralos y continúa.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de escucha y aclaración?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
