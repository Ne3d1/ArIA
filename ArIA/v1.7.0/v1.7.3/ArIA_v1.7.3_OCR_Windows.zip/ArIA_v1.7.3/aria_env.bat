@echo off
REM Selecciona un entorno virtual fuera del USB en Windows.
if defined ARIA_VENV_DIR exit /b 0
set "ARIA_CACHE=%LOCALAPPDATA%\ArIA\venvs"
if not defined LOCALAPPDATA set "ARIA_CACHE=%USERPROFILE%\AppData\Local\ArIA\venvs"
set "ARIA_PROJECT_KEY="
for /f %%H in ('powershell -NoProfile -Command "$p=(Get-Location).Path.ToLowerInvariant(); $b=[Text.Encoding]::UTF8.GetBytes($p); $sha=[Security.Cryptography.SHA256]::Create(); $h=$sha.ComputeHash($b); ([BitConverter]::ToString($h)).Replace('-','').Substring(0,16)" 2^>nul') do set "ARIA_PROJECT_KEY=%%H"
if not defined ARIA_PROJECT_KEY for %%I in ("%CD%") do set "ARIA_PROJECT_KEY=%%~nxI"
set "ARIA_VENV_DIR=%ARIA_CACHE%\%ARIA_PROJECT_KEY%"
exit /b 0
