"""Interfaz gráfica de ArIA (Tkinter) con mensajes renderizados en Markdown."""
import datetime
import queue
import re
import shutil
import threading
import tkinter as tk
import tkinter.font as tkfont
import webbrowser
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from . import __version__, config
from .cerebro import Cerebro, Respuesta
from .memoria import Memoria
from . import pantalla

TEMAS = {
    "claro": dict(bg="#f6f7fb", panel="#ffffff", fg="#1f2430", muted="#7a8194", accent="#6c4cf1",
                  user="#e9e4ff", code="#eef0f6", link="#2b6cdf", quote="#6b7280", btn="#e4e7f0", btnfg="#1f2430"),
    "oscuro": dict(bg="#171923", panel="#1f2230", fg="#e6e8f0", muted="#8a90a6", accent="#9d86ff",
                   user="#2d2a4a", code="#2a2e40", link="#7ab0ff", quote="#a0a6bb", btn="#2c3046", btnfg="#e6e8f0"),
}

INLINE = re.compile(
    r"(\*\*.+?\*\*|`[^`\n]+`|\[[^\]\n]+\]\([^)\s]+\)|(?<![\w*])\*[^*\n]+?\*(?![\w*])|(?<!\w)_[^_\n]+?_(?!\w))"
)

BIENVENIDA = (
    "## ¡Hola! Soy ArIA 👋\n"
    "Aprendo de lo que me cuentas, de tus archivos y de internet. También sé de **matemáticas** y "
    "**programación** básica.\n\n"
    "Prueba con:\n"
    "- `qué es la fotosíntesis`\n"
    "- `resuelve x^2 - 5x + 6 = 0`\n"
    "- `escribe un programa de fibonacci en python`\n"
    "- `me llamo Ana` · `me gusta el té` (lo recordaré siempre)\n\n"
    "Escribe `ayuda` para ver todo."
)


class App:
    def __init__(self):
        self.cfg = config.cargar()
        self.mem = Memoria()
        self.cola = queue.Queue()
        self.ocupado = False
        self.registro = []
        self.n_enlaces = 0
        self.archivo_chat = self._nuevo_archivo_chat()

        self.root = tk.Tk()
        self.root.title(f"ArIA {__version__}")
        self.root.geometry("920x720")
        self.root.minsize(560, 460)

        self.cerebro = Cerebro(
            self.cfg, self.mem,
            permiso=lambda ruta: self.en_gui(lambda: self.dialogo_permiso(ruta)) or "no",
            confirmar=lambda msg: bool(self.en_gui(lambda: messagebox.askyesno("ArIA", msg, parent=self.root))),
            estado=lambda m: self.cola.put(("estado", m)),
        )
        self._construir()
        self.aplicar_tema()
        self.mensaje("aria", self._bienvenida(), registrar=False)
        self.root.after(80, self._poll)
        self.entrada.focus_set()

    # ------------------------------------------------------------------ UI
    def _construir(self):
        fam = set(tkfont.families())
        self.fuente = next((f for f in ("Segoe UI", "Helvetica Neue", "DejaVu Sans", "Arial") if f in fam), "TkDefaultFont")
        self.mono = next((f for f in ("Consolas", "Menlo", "DejaVu Sans Mono", "Courier New") if f in fam), "TkFixedFont")

        self.barra = tk.Frame(self.root)
        self.barra.pack(fill="x", padx=10, pady=(10, 4))
        self.botones = []
        for texto, cmd in [("➕ Nuevo", self.nuevo_chat), ("📎 Archivo", self.adjuntar_archivos),
                           ("📁 Carpeta", self.adjuntar_carpeta), ("💾 Guardar .md", self.guardar_chat),
                           ("🧠 Memoria", self.ver_memoria), ("🪟 Programas", self.ver_programas),
                           ("👁 Analizar pantalla", self.analizar_pantalla), ("⚙ Ajustes", self.ajustes)]:
            b = tk.Button(self.barra, text=texto, command=cmd, relief="flat", padx=10, pady=4, cursor="hand2", bd=0)
            b.pack(side="left", padx=(0, 6))
            self.botones.append(b)

        self.marco_chat = tk.Frame(self.root)
        self.marco_chat.pack(fill="both", expand=True, padx=10, pady=4)
        self.chat = tk.Text(self.marco_chat, wrap="word", state="disabled", relief="flat", padx=16, pady=12,
                            font=(self.fuente, 11), cursor="arrow", spacing1=1, spacing3=2, bd=0, highlightthickness=0)
        sb = ttk.Scrollbar(self.marco_chat, command=self.chat.yview)
        self.chat.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.chat.pack(side="left", fill="both", expand=True)

        self.estado_lbl = tk.Label(self.root, text="", anchor="w", font=(self.fuente, 9))
        self.estado_lbl.pack(fill="x", padx=14)

        self.pie = tk.Frame(self.root)
        self.pie.pack(fill="x", padx=10, pady=(2, 10))
        self.entrada = tk.Text(self.pie, height=3, wrap="word", relief="flat", padx=10, pady=8,
                               font=(self.fuente, 11), bd=0, highlightthickness=1)
        self.entrada.pack(side="left", fill="both", expand=True)
        self.entrada.bind("<Return>", self.enviar)
        self.entrada.bind("<Shift-Return>", lambda e: None)
        lateral = tk.Frame(self.pie)
        lateral.pack(side="left", padx=(8, 0), fill="y")
        self.btn_enviar = tk.Button(lateral, text="Enviar ➤", command=self.enviar, relief="flat", padx=14, pady=6,
                                    cursor="hand2", bd=0, font=(self.fuente, 10, "bold"))
        self.btn_enviar.pack(fill="x")
        fila = tk.Frame(lateral)
        fila.pack(fill="x", pady=(6, 0))
        self.btn_up = tk.Button(fila, text="👍", command=lambda: self.valorar(True), relief="flat", bd=0, cursor="hand2")
        self.btn_down = tk.Button(fila, text="👎", command=lambda: self.valorar(False), relief="flat", bd=0, cursor="hand2")
        self.btn_up.pack(side="left", expand=True, fill="x", padx=(0, 3))
        self.btn_down.pack(side="left", expand=True, fill="x")
        self.botones += [self.btn_up, self.btn_down]
        self.marco_lateral = lateral
        self.marco_fila = fila

    def aplicar_tema(self):
        c = TEMAS.get(self.cfg.get("tema"), TEMAS["claro"])
        self.c = c
        self.root.configure(bg=c["bg"])
        for w in (self.barra, self.marco_chat, self.pie, self.marco_lateral, self.marco_fila):
            w.configure(bg=c["bg"])
        for b in self.botones:
            b.configure(bg=c["btn"], fg=c["btnfg"], activebackground=c["accent"], activeforeground="#ffffff")
        self.btn_enviar.configure(bg=c["accent"], fg="#ffffff", activebackground=c["accent"], activeforeground="#ffffff")
        self.chat.configure(bg=c["panel"], fg=c["fg"], selectbackground=c["accent"], selectforeground="#ffffff")
        self.entrada.configure(bg=c["panel"], fg=c["fg"], insertbackground=c["fg"], highlightbackground=c["btn"],
                               highlightcolor=c["accent"])
        self.estado_lbl.configure(bg=c["bg"], fg=c["muted"])

        f, m = self.fuente, self.mono
        t = self.chat.tag_configure
        t("h_user", font=(f, 9, "bold"), foreground=c["accent"], spacing1=10)
        t("h_aria", font=(f, 9, "bold"), foreground=c["accent"], spacing1=10)
        t("usuario", background=c["user"], lmargin1=10, lmargin2=10, rmargin=10)
        t("h1", font=(f, 17, "bold"), spacing1=8, spacing3=4)
        t("h2", font=(f, 14, "bold"), spacing1=8, spacing3=3)
        t("h3", font=(f, 12, "bold"), spacing1=6, spacing3=2)
        t("h4", font=(f, 11, "bold"), spacing1=4)
        t("bold", font=(f, 11, "bold"))
        t("italic", font=(f, 11, "italic"))
        t("code", font=(m, 10), background=c["code"])
        t("codeblock", font=(m, 10), background=c["code"], lmargin1=14, lmargin2=14, rmargin=14, spacing1=0, spacing3=0)
        t("table", font=(m, 10), lmargin1=10, lmargin2=10)
        t("quote", foreground=c["quote"], lmargin1=18, lmargin2=18, font=(f, 11, "italic"))
        t("li", lmargin1=18, lmargin2=34)
        t("hr", foreground=c["muted"])
        t("enlace", foreground=c["link"], underline=True)
        t("muted", foreground=c["muted"], font=(f, 9))
        self.chat.tag_raise("code")
        self.chat.tag_raise("enlace")
        self.chat.tag_raise("sel")

    # ------------------------------------------------------------------ Markdown
    def _inline(self, texto, tags=()):
        w = self.chat
        for trozo in INLINE.split(texto):
            if not trozo:
                continue
            if trozo.startswith("**") and trozo.endswith("**") and len(trozo) > 4:
                self._inline(trozo[2:-2], tags + ("bold",))
            elif trozo.startswith("`") and trozo.endswith("`") and len(trozo) > 2:
                w.insert("end", trozo[1:-1], tags + ("code",))
            elif trozo.startswith("[") and "](" in trozo and trozo.endswith(")"):
                etiqueta, _, url = trozo[1:-1].partition("](")
                self.n_enlaces += 1
                tag = f"enlace{self.n_enlaces}"
                w.insert("end", etiqueta, tags + ("enlace", tag))
                w.tag_bind(tag, "<Button-1>", lambda e, u=url: webbrowser.open(u))
                w.tag_bind(tag, "<Enter>", lambda e: w.configure(cursor="hand2"))
                w.tag_bind(tag, "<Leave>", lambda e: w.configure(cursor="arrow"))
            elif len(trozo) > 2 and trozo[0] in "*_" and trozo[-1] == trozo[0]:
                w.insert("end", trozo[1:-1], tags + ("italic",))
            else:
                w.insert("end", trozo, tags)

    def render_markdown(self, md, base=()):
        w = self.chat
        lineas, i = md.split("\n"), 0
        while i < len(lineas):
            ln = lineas[i]
            if ln.strip().startswith("```"):
                i += 1
                bloque = []
                while i < len(lineas) and not lineas[i].strip().startswith("```"):
                    bloque.append(lineas[i])
                    i += 1
                i += 1
                w.insert("end", "\n".join(bloque) + "\n", base + ("codeblock",))
                continue
            m = re.match(r"^(#{1,4})\s+(.*)$", ln)
            if m:
                limpio = re.sub(r"[*`]", "", m.group(2))
                w.insert("end", limpio + "\n", base + (f"h{len(m.group(1))}",))
            elif re.match(r"^\s*([-*_])(\s*\1){2,}\s*$", ln):
                w.insert("end", "─" * 48 + "\n", base + ("hr",))
            elif ln.lstrip().startswith(">"):
                self._inline(ln.lstrip()[1:].strip(), base + ("quote",))
                w.insert("end", "\n")
            elif ln.strip().startswith("|") and ln.strip().endswith("|"):
                filas = []
                while i < len(lineas) and lineas[i].strip().startswith("|"):
                    celdas = [c.strip() for c in lineas[i].strip().strip("|").split("|")]
                    if not all(re.fullmatch(r":?-{2,}:?", c) for c in celdas if c):
                        filas.append([re.sub(r"[*`]", "", c) for c in celdas])
                    i += 1
                anchos = [max(len(f[j]) if j < len(f) else 0 for f in filas) for j in range(max(map(len, filas)))]
                for k, f in enumerate(filas):
                    w.insert("end", "  ".join((f[j] if j < len(f) else "").ljust(anchos[j]) for j in range(len(anchos))) + "\n", base + ("table",))
                    if k == 0:
                        w.insert("end", "  ".join("─" * a for a in anchos) + "\n", base + ("table",))
                continue
            else:
                m = re.match(r"^(\s*)([-*+]|\d+[.)])\s+(.*)$", ln)
                if m:
                    marca = "•" if m.group(2) in "-*+" else m.group(2)
                    w.insert("end", "  " * (len(m.group(1)) // 2) + marca + " ", base + ("li",))
                    self._inline(m.group(3), base + ("li",))
                    w.insert("end", "\n")
                else:
                    self._inline(ln, base)
                    w.insert("end", "\n")
            i += 1

    # ------------------------------------------------------------------ mensajes
    def mensaje(self, rol, texto, registrar=True):
        w = self.chat
        w.configure(state="normal")
        hora = datetime.datetime.now().strftime("%H:%M")
        if rol == "user":
            w.insert("end", f"👤 Tú · {hora}\n", ("h_user",))
            w.insert("end", texto.rstrip() + "\n", ("usuario",))
        else:
            w.insert("end", f"🤖 ArIA · {hora}\n", ("h_aria",))
            self.render_markdown(texto.rstrip())
        w.insert("end", "\n")
        w.configure(state="disabled")
        w.see("end")
        if registrar:
            self.registro.append((rol, texto))
            self._autoguardar()

    def _nuevo_archivo_chat(self):
        return config.CHATS_DIR / f"chat-{datetime.datetime.now():%Y%m%d-%H%M%S}.md"

    def _como_markdown(self):
        partes = []
        for rol, tx in self.registro:
            partes.append(("**Tú:** " if rol == "user" else "**ArIA:**\n\n") + tx)
        return "# Chat con ArIA\n\n" + "\n\n---\n\n".join(partes) + "\n"

    def _autoguardar(self):
        try:
            config.CHATS_DIR.mkdir(parents=True, exist_ok=True)
            self.archivo_chat.write_text(self._como_markdown(), encoding="utf-8")
        except OSError:
            pass

    # ------------------------------------------------------------------ hilos
    def en_gui(self, func):
        """Ejecuta func en el hilo de la interfaz y espera su resultado (para usar desde hilos de trabajo)."""
        if threading.current_thread() is threading.main_thread():
            return func()
        ev, caja = threading.Event(), []
        self.cola.put(("gui", func, ev, caja))
        ev.wait()
        return caja[0] if caja else None

    def _poll(self):
        while True:
            try:
                item = self.cola.get_nowait()
            except queue.Empty:
                break
            tipo = item[0]
            if tipo == "respuesta":
                self.mensaje("aria", item[1].texto)
                self._ocupado(False)
            elif tipo == "mensaje":
                self.mensaje("aria", item[1])
                self._ocupado(False)
            elif tipo == "estado":
                self.estado_lbl.configure(text=item[1])
            elif tipo == "gui":
                _, func, ev, caja = item
                try:
                    caja.append(func())
                except Exception:
                    pass
                finally:
                    ev.set()
        self.root.after(80, self._poll)

    def _ocupado(self, si):
        self.ocupado = si
        self.btn_enviar.configure(state="disabled" if si else "normal")
        self.estado_lbl.configure(text="ArIA está pensando…" if si else "")

    def enviar(self, _evento=None):
        texto = self.entrada.get("1.0", "end").strip()
        if texto and not self.ocupado:
            self.entrada.delete("1.0", "end")
            self.mensaje("user", texto)
            self._ocupado(True)
            threading.Thread(target=self._trabajo, args=(texto,), daemon=True).start()
        return "break"

    def _trabajo(self, texto):
        try:
            r = self.cerebro.responder(texto)
        except Exception as e:
            r = Respuesta(f"⚠️ Ha ocurrido un error interno: `{e}`", "error")
        self.cola.put(("respuesta", r))

    def _en_hilo(self, func, *args):
        self._ocupado(True)

        def run():
            try:
                md = func(*args)
            except Exception as e:
                md = f"⚠️ Error: `{e}`"
            self.cola.put(("mensaje", md))
        threading.Thread(target=run, daemon=True).start()

    # ------------------------------------------------------------------ acciones
    def valorar(self, bueno):
        if self.ocupado:
            return
        self.mensaje("aria", self.cerebro.valorar(bueno), registrar=False)

    def nuevo_chat(self):
        if self.ocupado:
            return
        self.registro, self.cerebro.historial, self.cerebro.ultima = [], [], None
        self.archivo_chat = self._nuevo_archivo_chat()
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.configure(state="disabled")
        self.mensaje("aria", self._bienvenida(), registrar=False)

    def _bienvenida(self):
        nombre = self.cfg.get("nombre_usuario")
        if not nombre:
            return BIENVENIDA
        return BIENVENIDA.replace(
            "## ¡Hola! Soy ArIA 👋\n",
            f"## ¡Hola de nuevo, {nombre}! Soy ArIA 👋\n> ¿No eres {nombre}? Dime *«soy …»* y cambio de persona.\n\n", 1)

    def adjuntar_archivos(self):
        rutas = filedialog.askopenfilenames(parent=self.root, title="Elige archivos para que ArIA los aprenda")
        if rutas:
            self.mensaje("user", "📎 " + ", ".join(Path(r).name for r in rutas))
            self._en_hilo(lambda: "\n\n".join(self.cerebro.aprender_ruta(r) for r in rutas))

    def adjuntar_carpeta(self):
        ruta = filedialog.askdirectory(parent=self.root, title="Elige una carpeta para que ArIA la aprenda")
        if ruta:
            self.mensaje("user", f"📁 {ruta}")
            self._en_hilo(self.cerebro.aprender_ruta, ruta)

    def guardar_chat(self):
        if not self.registro:
            messagebox.showinfo("ArIA", "Todavía no hay nada que guardar.", parent=self.root)
            return
        destino = filedialog.asksaveasfilename(parent=self.root, defaultextension=".md", initialfile="chat-aria.md",
                                               filetypes=[("Markdown", "*.md")])
        if destino:
            Path(destino).write_text(self._como_markdown(), encoding="utf-8")
            self.mensaje("aria", f"💾 Chat guardado en `{destino}`", registrar=False)

    def ver_memoria(self):
        self.mensaje("aria", self.cerebro.resumen_memoria(True), registrar=False)

    def ver_programas(self):
        """Muestra procesos y títulos de ventanas; solicita permiso antes de consultar."""
        if not messagebox.askyesno("Privacidad", "¿Permites que ArIA consulte los nombres de los programas y ventanas abiertos?\n\nNo leerá documentos ni contraseñas.", parent=self.root):
            return
        self._ocupado(True)
        def trabajo():
            procesos, error = pantalla.programas_abiertos()
            ventanas, aviso = pantalla.ventanas_abiertas()
            partes = ["## 🪟 Programas detectados"]
            if ventanas:
                partes += ["**Ventanas:**", *[f"- {x}" for x in ventanas[:30]]]
            if procesos:
                partes += ["**Procesos:**", *[f"- `{x}`" for x in procesos]]
            if error:
                partes.append("⚠️ " + error)
            if aviso:
                partes.append("_" + aviso + "_")
            partes.append("\n*Solo he consultado nombres. No he leído el contenido de ninguna aplicación.*")
            return "\n".join(partes)
        self._en_hilo(trabajo)

    def analizar_pantalla(self):
        """Hace OCR local y analiza el texto sin modelos externos."""
        if not messagebox.askyesno(
            "Permiso para analizar la pantalla",
            "ArIA capturará el monitor principal y leerá el texto visible mediante OCR.\n\n"
            "La captura se procesa en memoria y no se guarda. Cierra antes ventanas con información privada. ¿Continuar?",
            parent=self.root,
        ):
            return
        self._ocupado(True)
        def trabajo():
            try:
                texto, tam = pantalla.leer_pantalla()
            except Exception as e:
                self.cola.put(("mensaje", f"⚠️ No pude analizar la pantalla: {e}"))
                return
            if not texto:
                self.cola.put(("mensaje", "No he podido reconocer texto en la pantalla. Puedes probar con mayor zoom o más contraste."))
                return
            # Vista previa antes de que el contenido salga del equipo.
            vista = texto[:10000]
            def confirmar_lectura():
                return messagebox.askyesno(
                    "Texto detectado — confirmar",
                    f"He detectado texto en una captura de {tam[0]}×{tam[1]}.\n\n"
                    "¿Quieres que ArIA lo analice? Revisa el texto antes de continuar.\n\n"
                    + vista[:1800] + ("\n…" if len(vista) > 1800 else ""), parent=self.root)
            if not self.en_gui(confirmar_lectura):
                self.cola.put(("mensaje", "De acuerdo. He descartado el texto detectado."))
                return
            self.cola.put(("estado", "Analizando el texto de la pantalla…"))
            try:
                respuesta = self.cerebro.analizar_contexto_pantalla(vista)
            except Exception as e:
                respuesta = f"⚠️ No pude analizar el contenido: {e}"
            self.cola.put(("mensaje", respuesta))
            guardar = self.en_gui(lambda: messagebox.askyesno(
                "¿Aprender de esta pantalla?",
                "¿Quieres guardar el texto reconocido en la memoria de ArIA para poder consultarlo más adelante?\n\n"
                "No lo guardaremos si eliges No.", parent=self.root))
            if guardar:
                n = self.mem.aprender_texto(vista, fuente="pantalla:captura autorizada", titulo="Texto de pantalla")
                self.cola.put(("mensaje", f"🧠 He guardado el texto de esta captura en memoria ({n} fragmentos). Puedes consultarlo o borrarlo con `/olvidar pantalla:captura autorizada`."))
        threading.Thread(target=trabajo, daemon=True).start()

    # ------------------------------------------------------------------ diálogos
    def dialogo_permiso(self, ruta):
        win = tk.Toplevel(self.root)
        win.title("Permiso de acceso")
        win.transient(self.root)
        win.configure(bg=self.c["panel"], padx=20, pady=16)
        resultado = {"v": "no"}
        tk.Label(win, text="🔒 ArIA quiere acceder a:", bg=self.c["panel"], fg=self.c["fg"],
                 font=(self.fuente, 11, "bold")).pack(anchor="w")
        tk.Label(win, text=ruta, bg=self.c["panel"], fg=self.c["accent"], wraplength=420, justify="left").pack(anchor="w", pady=8)

        def elegir(v):
            resultado["v"] = v
            win.destroy()
        fila = tk.Frame(win, bg=self.c["panel"])
        fila.pack(anchor="e", pady=(8, 0))
        for texto, v in (("Denegar", "no"), ("Solo esta vez", "una"), ("Permitir siempre en esta carpeta", "siempre")):
            tk.Button(fila, text=texto, command=lambda v=v: elegir(v), relief="flat", padx=10, pady=4,
                      bg=self.c["accent"] if v == "una" else self.c["btn"],
                      fg="#ffffff" if v == "una" else self.c["btnfg"], cursor="hand2").pack(side="left", padx=4)
        win.protocol("WM_DELETE_WINDOW", lambda: elegir("no"))
        win.update_idletasks()
        win.grab_set()
        self.root.wait_window(win)
        return resultado["v"]

    def ajustes(self):
        win = tk.Toplevel(self.root)
        win.title("Ajustes de ArIA")
        win.transient(self.root)
        win.configure(bg=self.c["panel"], padx=18, pady=14)
        c = self.c
        v_nombre = tk.StringVar(value=self.cfg.get("nombre_usuario", ""))
        v_tema = tk.StringVar(value=self.cfg.get("tema", "claro"))
        v_web = tk.BooleanVar(value=self.cfg.get("buscar_en_internet", True))
        v_aprende = tk.BooleanVar(value=self.cfg.get("aprender_de_internet", True))
        v_code = tk.BooleanVar(value=self.cfg.get("ejecutar_codigo", True))

        def fila(r, etiqueta, widget):
            tk.Label(win, text=etiqueta, bg=c["panel"], fg=c["fg"]).grid(row=r, column=0, sticky="w", pady=3, padx=(0, 10))
            widget.grid(row=r, column=1, sticky="ew", pady=3)

        def entry(var, **kw):
            return tk.Entry(win, textvariable=var, width=34, relief="flat", bg=c["bg"], fg=c["fg"], insertbackground=c["fg"], **kw)

        def check(texto, var):
            return tk.Checkbutton(win, text=texto, variable=var, bg=c["panel"], fg=c["fg"], selectcolor=c["bg"],
                                  activebackground=c["panel"], activeforeground=c["fg"], anchor="w")
        fila(0, "Tu nombre", entry(v_nombre))
        fila(1, "Tema", ttk.Combobox(win, textvariable=v_tema, values=["claro", "oscuro"], state="readonly"))
        fila(2, "Internet", check("Permitir búsquedas web cuando las pida", v_web))
        fila(3, "", check("Aprender automáticamente de lo que encuentro", v_aprende))
        fila(4, "Código", check("Permitir ejecutar código (siempre pide confirmación)", v_code))
        tk.Label(win, text="ArIA trabaja solo con razonamiento local: no usa modelos externos ni envía tus conversaciones a servicios de IA.",
                 bg=c["panel"], fg=c["muted"], wraplength=420, justify="left",
                 font=(self.fuente, 9)).grid(row=5, column=0, columnspan=2, sticky="w", pady=(10, 0))
        tk.Label(win, text="Carpetas con acceso permitido", bg=c["panel"], fg=c["muted"],
                 font=(self.fuente, 9)).grid(row=6, column=0, columnspan=2, sticky="w", pady=(10, 0))
        lista = tk.Listbox(win, height=4, bg=c["bg"], fg=c["fg"], relief="flat", selectbackground=c["accent"])
        for carpeta in self.cfg.get("carpetas_permitidas", []):
            lista.insert("end", carpeta)
        lista.grid(row=7, column=0, columnspan=2, sticky="ew")
        fb = tk.Frame(win, bg=c["panel"])
        fb.grid(row=8, column=0, columnspan=2, sticky="w", pady=4)

        def añadir():
            d = filedialog.askdirectory(parent=win)
            if d:
                lista.insert("end", d)

        def quitar():
            for i in reversed(lista.curselection()):
                lista.delete(i)
        for txt, cmd in (("Añadir carpeta", añadir), ("Quitar", quitar)):
            tk.Button(fb, text=txt, command=cmd, relief="flat", bg=c["btn"], fg=c["btnfg"], padx=8).pack(side="left", padx=(0, 6))

        def guardar():
            self.cfg.update(nombre_usuario=v_nombre.get().strip(), tema=v_tema.get(), buscar_en_internet=v_web.get(),
                            aprender_de_internet=v_aprende.get(), ejecutar_codigo=v_code.get(),
                            carpetas_permitidas=list(lista.get(0, "end")))
            # Compatibilidad: elimina configuraciones antiguas de proveedores de IA.
            self.cfg.pop("llm", None)
            config.guardar(self.cfg)
            self.aplicar_tema()
            win.destroy()
        tk.Button(win, text="Guardar", command=guardar, relief="flat", bg=c["accent"], fg="#ffffff", padx=16, pady=4
                  ).grid(row=9, column=1, sticky="e", pady=(10, 0))
        win.columnconfigure(1, weight=1)
        win.grab_set()

    def ejecutar(self):
        self.root.mainloop()


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    App().ejecutar()
