@echo off
setlocal
cd /d "%~dp0"
set "PYTHON=python"
if defined ARIA_VENV_DIR if exist "%ARIA_VENV_DIR%\Scripts\python.exe" set "PYTHON=%ARIA_VENV_DIR%\Scripts\python.exe"
"%PYTHON%" "%~dp0importar_corpus.py" %*
exit /b %errorlevel%
