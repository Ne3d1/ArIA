# Estudio activo y transferencia

Aprender no consiste solo en leer. Alterna explicación, recuperación de memoria, práctica, corrección y aplicación en situaciones nuevas.

Después de estudiar un concepto, cierra el material e intenta explicarlo. Resuelve un ejemplo sin mirar. Compara con la solución, identifica el error y vuelve a practicar días después.

La transferencia ocurre cuando aplicas una idea en un contexto distinto. Para favorecerla, compara ejemplos, identifica la estructura común y también las diferencias que limitan la analogía.
