@echo off
REM Ejecuta ArIA en Windows; el entorno virtual se guarda en la caché del usuario.
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
call aria_env.bat
set "VENV_PY=%ARIA_VENV_DIR%\Scripts\python.exe"
if not exist "%VENV_PY%" goto :setup
"%VENV_PY%" -c "import requests,bs4,ddgs,sympy,pypdf,docx,mss,PIL,pytesseract,psutil,pygetwindow,rapidfuzz,torch" 2>nul
if errorlevel 1 goto :setup
goto :run
:setup
echo Preparando o reparando el entorno en "%ARIA_VENV_DIR%" ...
call setup.bat
if errorlevel 1 exit /b 1
:run
if "%~1"=="--cli" (
  "%VENV_PY%" main.py %*
) else (
  start "" "%ARIA_VENV_DIR%\Scripts\pythonw.exe" main.py %*
)
