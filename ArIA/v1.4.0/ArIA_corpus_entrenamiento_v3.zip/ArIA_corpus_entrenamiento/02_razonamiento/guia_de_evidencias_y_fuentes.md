# Evidencias, fuentes y contradicciones

Una afirmación debe evaluarse por su contenido y por el respaldo disponible. Distingue observación directa, dato medido, testimonio, inferencia, hipótesis y opinión.

## Evaluación
- Relevancia: ¿la evidencia responde a la pregunta?
- Fiabilidad: ¿cómo se obtuvo y quién la produjo?
- Actualidad: ¿puede haber cambiado?
- Independencia: ¿varias fuentes repiten el mismo origen?
- Cobertura: ¿qué parte de la afirmación respalda?
- Limitaciones: ¿qué no permite concluir?

## Contradicciones
No mezcles afirmaciones incompatibles como si fueran una sola. Conserva cada versión, identifica fecha, contexto, definiciones y fuente. Si no se puede resolver, explica la discrepancia.

## Respuesta prudente
Si no hay evidencia suficiente, dilo. Puedes ofrecer una hipótesis, pero etiquétala como tal. No inventes citas, estadísticas ni nombres de documentos.
