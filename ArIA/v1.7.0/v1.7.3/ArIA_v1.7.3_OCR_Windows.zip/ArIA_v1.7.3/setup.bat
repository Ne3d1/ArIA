@echo off
REM Instala todas las dependencias Python y comprueba OCR/Tkinter en Windows.
setlocal EnableExtensions
cd /d "%~dp0"
call aria_env.bat
set "VENV_PY=%ARIA_VENV_DIR%\Scripts\python.exe"
chcp 65001 >nul

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo [ERROR] No encuentro Python. Instálalo desde https://www.python.org/downloads/ marcando "Add Python to PATH".
  pause
  exit /b 1
)
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)"
if errorlevel 1 (
  echo [ERROR] Necesito Python 3.9 o superior.
  pause
  exit /b 1
)

if not exist "%VENV_PY%" (
  echo [1/4] Creando entorno virtual en "%ARIA_VENV_DIR%" ...
  if not exist "%ARIA_VENV_DIR%" mkdir "%ARIA_VENV_DIR%"
  %PY% -m venv "%ARIA_VENV_DIR%"
  if errorlevel 1 (
    echo [ERROR] No pude crear el entorno virtual.
    pause
    exit /b 1
  )
)

echo [2/4] Instalando dependencias de requirements.txt ...
"%VENV_PY%" -m pip install --upgrade pip
if errorlevel 1 goto :error
"%VENV_PY%" -m pip install -r requirements.txt --extra-index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto :error
"%VENV_PY%" -m pip check
if errorlevel 1 goto :error

"%VENV_PY%" -c "import importlib.util,sys; mods=['requests','bs4','ddgs','sympy','pypdf','docx','mss','PIL','pytesseract','psutil','pygetwindow','rapidfuzz','torch']; missing=[m for m in mods if importlib.util.find_spec(m) is None]; print('[ERROR] Faltan: '+', '.join(missing)) if missing else print('[OK] Todas las dependencias Python están instaladas.'); sys.exit(bool(missing))"
if errorlevel 1 goto :error

echo [3/4] Comprobando Tesseract OCR ...
call :refresh_tesseract_path
where tesseract >nul 2>nul
if errorlevel 1 (
  echo [AVISO] Tesseract no esta instalado o no se encuentra.
  where winget >nul 2>nul
  if not errorlevel 1 (
    choice /C SN /N /M "¿Quieres instalar Tesseract OCR con winget? [S/N] "
    if errorlevel 2 goto :ocr_done
    winget install --id UB-Mannheim.TesseractOCR --exact --accept-package-agreements --accept-source-agreements
    if errorlevel 1 echo [AVISO] La instalacion automatica no se completo.
    call :refresh_tesseract_path
  ) else (
    echo Instálalo desde https://github.com/UB-Mannheim/tesseract/wiki
  )
)
where tesseract >nul 2>nul
if errorlevel 1 (
  echo [AVISO] OCR de pantalla no disponible hasta instalar Tesseract.
) else (
  echo [OK] Tesseract detectado.
  tesseract --list-langs 2>nul | findstr /X /C:"spa" >nul
  if errorlevel 1 echo [AVISO] Falta el idioma Spanish (spa) en Tesseract.
  tesseract --list-langs 2>nul | findstr /X /C:"eng" >nul
  if errorlevel 1 echo [AVISO] Falta el idioma English (eng) en Tesseract.
)
:ocr_done

echo [4/4] Comprobando Tkinter ...
"%VENV_PY%" -c "import tkinter" 2>nul
if errorlevel 1 echo [AVISO] Falta Tkinter/Tcl-Tk. Repara la instalación de Python incluyendo Tcl/Tk.
echo.
echo Preparación terminada. Entorno: "%ARIA_VENV_DIR%"
echo Ejecuta run.bat (ventana) o run.bat --cli (terminal).
pause
exit /b 0

:error
echo [ERROR] Falló la instalación o comprobación de dependencias. Revisa la conexión y vuelve a ejecutar setup.bat.
pause
exit /b 1

:refresh_tesseract_path
if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" set "PATH=%ProgramFiles%\Tesseract-OCR;%PATH%"
if exist "%ProgramFiles(x86)%\Tesseract-OCR\tesseract.exe" set "PATH=%ProgramFiles(x86)%\Tesseract-OCR;%PATH%"
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" set "PATH=%LOCALAPPDATA%\Programs\Tesseract-OCR;%PATH%"
exit /b 0
