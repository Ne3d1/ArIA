# Razonamiento deductivo

## Definición
La deducción aplica premisas generales a un caso. Si la forma del argumento es válida y las premisas son verdaderas, la conclusión se sigue necesariamente.

## Método de trabajo
Explicita cada premisa, identifica la regla aplicada y comprueba si la conclusión introduce algo que no estaba implicado. Distingue validez lógica de verdad factual.

## Ejemplo explicado
Premisa 1: todos los mamíferos son vertebrados. Premisa 2: los delfines son mamíferos. Conclusión: los delfines son vertebrados.

## Errores y límites
Afirmar el consecuente y negar el antecedente son formas inválidas. Una conclusión válida desde premisas falsas no garantiza una descripción verdadera del mundo.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de razonamiento deductivo?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
