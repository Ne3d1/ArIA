#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
if [[ -f "$SCRIPT_DIR/aria_env.sh" ]]; then
  # shellcheck source=/dev/null
  source "$SCRIPT_DIR/aria_env.sh"
fi
PYTHON_BIN="${ARIA_PYTHON:-python3}"
if [[ -n "${ARIA_VENV_DIR:-}" && -x "$ARIA_VENV_DIR/bin/python" ]]; then PYTHON_BIN="$ARIA_VENV_DIR/bin/python"; fi
exec "$PYTHON_BIN" "$SCRIPT_DIR/importar_corpus.py" "$@"
