#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
source ./aria_env.sh
aria_resolve_venv
VENV_PY="$ARIA_VENV_DIR/bin/python"
if [ ! -x "$VENV_PY" ]; then bash ./setup.sh; fi
"$VENV_PY" -m compileall -q aria main.py tests
"$VENV_PY" -m unittest discover -v
