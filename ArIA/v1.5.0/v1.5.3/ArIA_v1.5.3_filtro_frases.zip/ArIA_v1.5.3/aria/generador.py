"""Generador estadístico local de texto basado en n-gramas adaptativos.

No descarga ni carga modelos preentrenados. Aprende transiciones de palabras de
los textos que el usuario enseña y genera continuaciones mediante muestreo con
backoff. Es un generador clásico: puede producir texto plausible, no garantizar
hechos ni comprensión semántica.
"""
from __future__ import annotations

import hashlib
import random
import re
import sqlite3
import threading
from collections import Counter
from typing import Optional

_TOKEN = re.compile(r"[\wáéíóúñü]+|[.,;:!?¿¡()—-]", re.UNICODE)
_STOP = {"el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "al", "a", "en", "y", "o", "que", "se", "su", "por", "con", "para", "como", "es", "son", "ser", "esta", "este", "esto", "lo", "me", "mi", "tu", "the", "of", "and", "to", "in", "is", "are", "for", "on", "with"}
_END = {".", "!", "?", "</s>"}


def _tokenizar(texto: str) -> list[str]:
    return [x.lower() if x[0].isalnum() or x[0] == "_" else x for x in _TOKEN.findall(texto or "")]


def _frases(texto: str) -> list[str]:
    return [x.strip() for x in re.split(r"(?<=[.!?])\s+|\n+", texto or "") if len(x.strip()) >= 20]


class GeneradorLocal:
    """Modelo de lenguaje n-grama incremental persistido en SQLite."""

    def __init__(self, bd: sqlite3.Connection, cerrojo: threading.RLock):
        self.bd, self.cerrojo = bd, cerrojo
        with self.cerrojo:
            self.bd.executescript("""
                CREATE TABLE IF NOT EXISTS generador_aportes (
                    fuente TEXT NOT NULL, contexto TEXT NOT NULL,
                    siguiente TEXT NOT NULL, cuenta INTEGER NOT NULL,
                    PRIMARY KEY (fuente, contexto, siguiente));
                CREATE INDEX IF NOT EXISTS idx_generador_contexto
                    ON generador_aportes(contexto);
                CREATE TABLE IF NOT EXISTS generador_fuentes (
                    fuente TEXT PRIMARY KEY, tokens INTEGER NOT NULL DEFAULT 0);
            """)
            self.bd.commit()

    @staticmethod
    def _aportes(texto: str) -> tuple[Counter, int]:
        aportes = Counter()
        total = 0
        palabras = ["<s>", "<s>"]
        for indice, frase in enumerate(_frases(texto)):
            if indice:
                palabras.extend(["</s>", "<s>"])
            palabras.extend(_tokenizar(frase))
        palabras.append("</s>")
        total = max(0, len(palabras) - 3)
        for i in range(2, len(palabras)):
            siguiente = palabras[i]
            if i >= 3:
                aportes[("3:" + "\x1f".join(palabras[i - 3:i]), siguiente)] += 1
            aportes[("2:" + "\x1f".join(palabras[i - 2:i]), siguiente)] += 1
            aportes[("1:" + palabras[i - 1], siguiente)] += 1
        return aportes, total

    def aprender(self, texto: str, fuente: str, reemplazar: bool = False) -> bool:
        return bool(self.aprender_muchos([(texto, fuente, reemplazar)]))

    def aprender_muchos(self, documentos) -> int:
        """Entrena varios fragmentos en una transacción para importar corpus grandes."""
        filas, fuentes = [], []
        with self.cerrojo:
            for texto, fuente, reemplazar in documentos:
                if not texto or not texto.strip() or not fuente:
                    continue
                aportes, total = self._aportes(texto)
                if not aportes:
                    continue
                if reemplazar:
                    self.bd.execute("DELETE FROM generador_aportes WHERE fuente=?", (fuente,))
                    self.bd.execute("DELETE FROM generador_fuentes WHERE fuente=?", (fuente,))
                elif self.bd.execute("SELECT 1 FROM generador_fuentes WHERE fuente=?", (fuente,)).fetchone():
                    continue
                filas.extend((fuente, contexto, siguiente, cuenta)
                             for (contexto, siguiente), cuenta in aportes.items())
                fuentes.append((fuente, total))
            if filas:
                self.bd.executemany(
                    "INSERT OR REPLACE INTO generador_aportes(fuente,contexto,siguiente,cuenta) VALUES(?,?,?,?)",
                    filas,
                )
                self.bd.executemany(
                    "INSERT OR REPLACE INTO generador_fuentes(fuente,tokens) VALUES(?,?)", fuentes
                )
                self.bd.commit()
        return len(fuentes)

    def reconstruir(self, documentos) -> int:
        """Reconstruye el modelo desde pares (clave, texto), útil al borrar memoria."""
        with self.cerrojo:
            self.bd.execute("DELETE FROM generador_aportes")
            self.bd.execute("DELETE FROM generador_fuentes")
            self.bd.commit()
        total = 0
        lote = []
        for clave, texto in documentos:
            lote.append((texto, str(clave), False))
            if len(lote) >= 250:
                total += self.aprender_muchos(lote)
                lote.clear()
        if lote:
            total += self.aprender_muchos(lote)
        return total

    def estadisticas(self) -> dict:
        with self.cerrojo:
            fuentes, tokens = self.bd.execute(
                "SELECT COUNT(*), COALESCE(SUM(tokens),0) FROM generador_fuentes"
            ).fetchone()
            transiciones = self.bd.execute("SELECT COUNT(*) FROM generador_aportes").fetchone()[0]
        return {"documentos": fuentes, "tokens": tokens, "transiciones": transiciones}

    def _opciones(self, contexto: str):
        with self.cerrojo:
            return self.bd.execute(
                "SELECT siguiente, SUM(cuenta) FROM generador_aportes WHERE contexto=? "
                "GROUP BY siguiente ORDER BY SUM(cuenta) DESC LIMIT 40", (contexto,)
            ).fetchall()

    def _siguiente(self, anterior: list[str], rng: random.Random, temperatura: float, vistos: Counter, usados=None):
        opciones = []
        if len(anterior) >= 3:
            opciones = self._opciones("3:" + "\x1f".join(anterior[-3:]))
        if not opciones and len(anterior) >= 2:
            opciones = self._opciones("2:" + "\x1f".join(anterior[-2:]))
        if not opciones and anterior:
            opciones = self._opciones("1:" + anterior[-1])
        if not opciones:
            return None
        # Top-k y temperatura: variación controlada sin depender de modelos neuronales.
        opciones = opciones[:20]
        if usados:
            filtradas = [x for x in opciones if tuple((anterior[-2:] + [x[0]])[-3:]) not in usados]
            if filtradas:
                opciones = filtradas
        puntuaciones = []
        for palabra, cuenta in opciones:
            penalizacion = 1.0 / (1.0 + min(vistos[palabra], 4) * 0.9)
            puntuaciones.append(max(0.001, float(cuenta) ** (1.0 / temperatura) * penalizacion))
        return rng.choices([x[0] for x in opciones], weights=puntuaciones, k=1)[0]

    def generar(self, consulta: str, textos_semilla=None, max_tokens: int = 90,
                temperatura: float = 0.82, semilla: Optional[int] = None) -> dict:
        """Genera una continuación contextual desde el fragmento más pertinente."""
        stats = self.estadisticas()
        if stats["tokens"] < 80:
            return {"texto": "", "motivo": "Necesito más material para aprender a redactar. Enséñame documentos o textos con `aprende del archivo ruta`.", "tokens": stats["tokens"]}
        consulta_tokens = {t for t in _tokenizar(consulta) if t.isalnum() and t not in _STOP}
        candidatos = []
        for texto in (textos_semilla or []):
            for frase in _frases(texto):
                ts = _tokenizar(frase)
                contenido = {t for t in ts if t.isalnum() and t not in _STOP}
                if not contenido:
                    continue
                cobertura = len(consulta_tokens & contenido) / max(1, len(consulta_tokens))
                precision = len(consulta_tokens & contenido) / max(1, len(contenido))
                score = 0.75 * cobertura + 0.25 * precision
                if score:
                    candidatos.append((score, frase, ts))
        if not candidatos:
            return {"texto": "", "motivo": "No encuentro textos aprendidos relacionados con ese tema. Enséñame material relacionado para poder generar una continuación contextual.", "tokens": stats["tokens"]}
        candidatos.sort(key=lambda x: (x[0], len(x[2])), reverse=True)
        score, frase, tokens_frase = candidatos[0]
        # Toma un prefijo de la frase más pertinente y continúa desde un punto
        # intermedio, no desde el punto final (donde el modelo suele detenerse).
        tokens_frase = [x for x in tokens_frase if x not in {"</s>"}]
        while tokens_frase and tokens_frase[-1] in _END:
            tokens_frase.pop()
        posiciones = [i for i, token in enumerate(tokens_frase) if token in consulta_tokens]
        centro = posiciones[0] if posiciones else 0
        inicio = max(0, centro - 2)
        fin = min(len(tokens_frase), max(inicio + 7, centro + 5))
        if fin - inicio < 3:
            inicio = 0
            fin = len(tokens_frase)
        prefijo = tokens_frase[inicio:fin]
        base = self._formatear(prefijo).strip()
        palabras_base = list(prefijo)
        contexto = palabras_base[-2:]
        if len(contexto) < 2:
            return {"texto": base, "motivo": "El fragmento aprendido es demasiado corto para continuarlo.", "tokens": stats["tokens"]}
        rng = random.Random(semilla)
        salida = []
        vistos = Counter(palabras_base)
        usados = set()
        for _ in range(max(10, min(int(max_tokens), 180))):
            siguiente = self._siguiente(contexto, rng, max(0.35, min(float(temperatura), 1.5)), vistos, usados)
            if siguiente is None:
                break
            if siguiente in ("</s>", "<s>"):
                contexto.append(siguiente)
                contexto = contexto[-2:]
                continue
            salida.append(siguiente)
            vistos[siguiente] += 1
            usados.add(tuple((contexto[-2:] + [siguiente])[-3:]))
            contexto.append(siguiente)
            contexto = contexto[-2:]
            if len(salida) >= 42 and siguiente in _END:
                break
        continuacion = self._formatear(salida, capitalizar=False)
        texto = base + (" " + continuacion if continuacion else "")
        return {"texto": texto, "motivo": "", "tokens": stats["tokens"], "coincidencia": round(score, 3)}

    @staticmethod
    def _formatear(tokens: list[str], capitalizar: bool = True) -> str:
        if not tokens:
            return ""
        s = ""
        mayuscula = capitalizar
        pegados = {".", ",", ";", ":", "!", "?", ")", "—", "-"}
        for token in tokens:
            es_signo = token in pegados or token in {"¿", "¡", "("}
            if not s or token in pegados or s.endswith(("¿", "¡", "(")):
                s += token
            else:
                s += " " + token
            if token in {".", "!", "?"}:
                mayuscula = True
            elif not es_signo:
                if mayuscula and token and token[0].isalpha():
                    # Capitaliza únicamente el inicio del texto o de una oración.
                    inicio = len(s) - len(token)
                    s = s[:inicio] + token[0].upper() + token[1:]
                mayuscula = False
        return s
