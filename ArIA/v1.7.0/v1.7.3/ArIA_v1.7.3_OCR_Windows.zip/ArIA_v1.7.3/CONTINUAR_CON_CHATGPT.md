# Continuidad del proyecto — ArIA v1.7.1

## Estado

La v1.7.1 parte del ZIP v1.7.0. Su objetivo es corregir los fallos observados por el usuario en tres consultas reales: comparación de PCIe 3.0–6.0, comparación Intel Core i5/i7/i9 y causas de la Segunda Guerra Mundial en orden cronológico.

## Cambios técnicos

- `aria/razonamiento.py`
  - Nuevo `planificar_investigacion_detallada`: devuelve intención, entidades, dimensiones y subconsultas.
  - Reconoce intenciones de comparación, causas, cronología y causas ordenadas cronológicamente.
  - Detecta versiones numéricas y familias como Intel Core i5/i7/i9 y Ryzen.
  - `planificar_investigacion` conserva compatibilidad y devuelve la lista de subconsultas.
- `aria/web.py`
  - El segmentador ya no parte decimales como `3.0` en dos frases.
  - La extracción exige varias señales léxicas para preguntas compuestas.
  - Las evidencias complementarias solo pueden conectarse dentro de una misma página; no se comparten anclas entre dominios.
  - El título de la misma página puede aportar contexto, pero no se usa como afirmación factual.
  - Filtra menús, catálogos de productos y promoción.
  - User-Agent actualizado a 1.7.1.
- `aria/cerebro.py`
  - Búsqueda por entidad y atributo, agregación por URL y extracción por subconsulta.
  - Comparaciones en tablas por entidad y dimensión, con fuente enlazada en cada celda.
  - Las celdas sin evidencia quedan vacías de contenido factual: no se rellenan por deducción.
  - Cronologías ordenadas por año; causas históricas presentadas como evidencias documentadas.
  - Una investigación explícita fallida no usa RAG local para rellenar huecos con información ajena.
  - Cabecera distingue páginas leídas, dominios y fragmentos guardados.
- `tests/test_investigacion_v171.py`
  - PCIe: tabla, fechas, velocidades y no transferencia de cifras entre generaciones.
  - Intel: núcleos, consumo y rendimiento por familia.
  - Historia: orden cronológico de fechas.
  - Aislamiento: una búsqueda histórica fallida no devuelve información de RAM.
  - Extracción: una palabra genérica compartida no basta para seleccionar evidencia.

## Edad, contenido y protecciones

No se incorpora un filtro general de edad ni bloqueos arbitrarios de temas adultos/informativos. Se mantienen las protecciones técnicas independientes del contenido: permiso antes de ejecutar acciones locales, validación de URLs públicas y bloqueo de destinos privados/locales. No confundir la ausencia de un filtro de edad con la promesa de un sistema sin salvaguardas ante cualquier uso dañino.

## Tamaño y recursos

No hay un límite artificial de tamaño para el corpus local ni para el ZIP del proyecto. El procesamiento debe seguir siendo por bloques para no cargar archivos completos innecesariamente. Los límites de bytes/páginas en el lector web son salvaguardas operativas de red; no limitan los archivos locales ni el tamaño del repositorio.

## Validación

Validación ejecutada en el árbol de trabajo antes del empaquetado:

- `python -m compileall -q aria main.py tests`: correcto.
- `python -m unittest discover -v`: 85 pruebas superadas.
- `bash -n setup.sh run.sh test.sh aria_env.sh importar_corpus.sh`: correcto.
- Permisos ejecutables comprobados en los cinco scripts `.sh`.
- La integridad y las pruebas sobre el ZIP extraído se verifican después de crear el archivo final.

Las pruebas de Internet están simuladas. No afirmar que se ha validado una búsqueda en directo, Windows o una unidad USB FAT/exFAT sin ejecutarlas realmente.

## Requisitos que siguen vigentes

- Aplicación local, sin APIs de LLM externos.
- Windows y Linux, también en USB con entorno virtual por equipo en disco local.
- Mantener la identidad nuclear de ArIA: creadora Aria català; ayudantes Claude y CatGPT.
- Diferenciar RAG/importación de documentos del entrenamiento neuronal real.
- No eliminar memoria antigua ni modificar datos del usuario sin autorización.
- Entregar ZIP verificable y conservar permisos ejecutables de scripts Linux.


## v1.7.3 — Corrección OCR Windows

- `aria/pantalla.py` localiza Tesseract mediante `TESSERACT_CMD`, PATH y rutas estándar de Windows (Program Files, Program Files (x86), LocalAppData).
- Comprueba que estén instalados los idiomas `spa` y `eng` antes de capturar la pantalla y devuelve instrucciones específicas si faltan.
- `setup.bat` refresca PATH en la sesión actual tras la instalación con winget y comprueba los idiomas.
- Pruebas unitarias nuevas: variable personalizada, PATH, ruta estándar Windows y configuración de pytesseract.
- Pendiente de prueba real en Windows: confirmar instalación winget y OCR con Tesseract/idiomas presentes.
