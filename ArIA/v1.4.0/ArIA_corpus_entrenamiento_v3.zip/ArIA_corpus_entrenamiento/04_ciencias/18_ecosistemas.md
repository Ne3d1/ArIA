# Ecosistemas

## Definición
Un ecosistema incluye organismos, ambiente físico e interacciones. La materia circula y la energía fluye a través de productores, consumidores y descomponedores.

## Método de trabajo
Identifica factores bióticos y abióticos; construye cadenas y redes tróficas; analiza competencia, depredación y mutualismo; considera cambios y resiliencia.

## Ejemplo explicado
Las plantas captan energía luminosa; los herbívoros consumen productores; los depredadores consumen otros animales; los descomponedores reciclan nutrientes.

## Errores y límites
Una cadena trófica es una simplificación. En la naturaleza, muchas especies tienen dietas variadas y forman redes complejas.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de ecosistemas?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
