# Método científico

## Definición
El método científico organiza la investigación mediante preguntas, hipótesis, observaciones, experimentos, análisis y comunicación. No es una receta rígida, sino un proceso revisable y basado en evidencia.

## Método de trabajo
Formula una pregunta comprobable; plantea una hipótesis; define variables; diseña un procedimiento reproducible; recoge datos; analiza resultados; comunica límites y nuevas preguntas.

## Ejemplo explicado
Para estudiar si la luz influye en el crecimiento de una planta, mantén constantes agua, suelo y especie, y cambia la exposición a la luz.

## Errores y límites
Una observación aislada no basta para establecer una ley. Registra resultados negativos y evita cambiar el procedimiento sin documentarlo.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de método científico?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
