import copy
import tempfile
import unittest
from unittest.mock import patch

from aria import web
from aria.cerebro import Cerebro
from aria.config import DEFAULTS
from aria.memoria import Memoria
from aria.razonamiento import planificar_investigacion_detallada


class PlanificacionV171(unittest.TestCase):
    def test_comparacion_intel_desglosa_nucleos_rendimiento_y_consumo(self):
        plan = planificar_investigacion_detallada(
            "Compara los procesadores Intel Core i5, i7 e i9. Explica diferencias de rendimiento, núcleos y consumo.")
        self.assertEqual(plan["intencion"], "comparacion")
        self.assertEqual(plan["entidades"], ["Intel Core i5", "Intel Core i7", "Intel Core i9"])
        joined = " ".join(plan["dimensiones"])
        self.assertIn("núcleos", joined)
        self.assertIn("consumo", joined)
        self.assertIn("rendimiento", joined)
        for entidad in plan["entidades"]:
            self.assertTrue(any(entidad in q for q in plan["subconsultas"]))

    def test_causas_historicas_genera_busquedas_de_contexto_y_cronologia(self):
        plan = planificar_investigacion_detallada(
            "¿Cuáles fueron las principales causas de la Segunda Guerra Mundial? Ordénalas cronológicamente.")
        self.assertEqual(plan["intencion"], "causas_cronologia")
        self.assertTrue(any("antecedentes" in q for q in plan["subconsultas"]))
        self.assertTrue(any("fechas" in q or "cronológico" in q for q in plan["subconsultas"]))


class AislamientoTematicoV171(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = copy.deepcopy(DEFAULTS)
        self.cfg["buscar_en_internet"] = True
        self.cfg["aprender_de_internet"] = False
        self.mem = Memoria(ruta=f"{self.tmp.name}/memoria.db")
        self.cerebro = Cerebro(self.cfg, self.mem)

    def tearDown(self):
        self.mem.bd.close()
        self.tmp.cleanup()

    @patch("aria.cerebro.web.buscar")
    def test_busqueda_fallida_no_recurre_a_recuerdos_de_ram(self, buscar):
        self.mem.aprender_texto(
            "La memoria RAM almacena temporalmente datos e instrucciones del procesador.",
            fuente="usuario:nota", titulo="Memoria RAM")
        buscar.return_value = [{
            "titulo": "Historia europea", "url": "https://example.org/europa",
            "texto": "La historia europea incluye distintos acontecimientos políticos y sociales del siglo XX. " * 4,
            "calidad": 0.8,
        }]
        r = self.cerebro.responder(
            "investiga las causas de la Segunda Guerra Mundial y ordénalas cronológicamente")
        self.assertEqual(r.origen, "nada")
        self.assertNotIn("memoria RAM", r.texto)
        self.assertNotIn("procesador", r.texto)

    @patch("aria.cerebro.web.buscar")
    def test_comparacion_pcie_crea_tabla_y_no_traspasa_cifras(self, buscar):
        datos = {
            "PCIe 3.0": ("8 GT/s", "2010", "codificación 128b/130b"),
            "PCIe 4.0": ("16 GT/s", "2017", "codificación 128b/130b"),
            "PCIe 5.0": ("32 GT/s", "2019", "codificación 128b/130b"),
            "PCIe 6.0": ("64 GT/s", "2022", "señalización PAM4 y corrección FEC"),
        }
        def fake(q, paginas):
            import re
            m = re.search(r"PCIe [3456]\.0", q)
            if not m:
                return []
            version = m.group(0)
            velocidad, fecha, tecnica = datos[version]
            return [{"titulo": f"Especificaciones {version}",
                     "url": f"https://example.org/{version.replace(' ', '-').replace('.', '-')}",
                     "texto": (f"{version} alcanza {velocidad} por carril en cada dirección. "
                               f"La especificación {version} fue publicada en {fecha}. "
                               f"{version} utiliza {tecnica} para transmitir datos correctamente."),
                     "calidad": 0.9}]
        buscar.side_effect = fake
        r = self.cerebro.responder(
            "investiga diferencias entre PCIe 3.0, 4.0, 5.0 y 6.0; incluye velocidades, fechas de lanzamiento y diferencias técnicas")
        self.assertEqual(r.origen, "web")
        self.assertIn("| Elemento |", r.texto)
        for version in datos:
            self.assertIn(version, r.texto)
        self.assertIn("64 GT/s", r.texto)
        self.assertIn("PAM4", r.texto)
        self.assertIn("2010", r.texto)
        # La cifra de PCIe 6.0 no debe aparecer en la fila de PCIe 3.0.
        fila3 = next(line for line in r.texto.splitlines() if "PCIe 3.0**" in line)
        self.assertNotIn("64 GT/s", fila3)


    @patch("aria.cerebro.web.buscar")
    def test_comparacion_intel_separa_nucleos_consumo_y_rendimiento(self, buscar):
        datos = {
            "Intel Core i5": ("6 núcleos y 12 hilos", "65 W TDP", "rendimiento equilibrado en tareas generales"),
            "Intel Core i7": ("8 núcleos y 16 hilos", "125 W TDP", "mayor rendimiento en cargas exigentes"),
            "Intel Core i9": ("16 núcleos y 24 hilos", "253 W TDP", "rendimiento alto en cargas paralelas"),
        }
        def fake(q, paginas):
            entidad = next((e for e in datos if e in q), None)
            if not entidad:
                return []
            nucleos, consumo, rendimiento = datos[entidad]
            return [{"titulo": f"Especificaciones {entidad}",
                     "url": "https://example.org/" + entidad.lower().replace(" ", "-"),
                     "texto": (f"{entidad} dispone de {nucleos} en esta familia de procesadores. "
                               f"Su consumo indicado es {consumo} según el modelo concreto. "
                               f"Su {rendimiento} dependiendo de la generación y configuración."),
                     "calidad": 0.9}]
        buscar.side_effect = fake
        r = self.cerebro.responder(
            "investiga y compara los procesadores Intel Core i5, i7 e i9: rendimiento, núcleos y consumo")
        self.assertEqual(r.origen, "web")
        self.assertIn("Intel Core i5", r.texto)
        self.assertIn("Intel Core i7", r.texto)
        self.assertIn("Intel Core i9", r.texto)
        self.assertIn("núcleos", r.texto)
        self.assertIn("253 W", r.texto)

    @patch("aria.cerebro.web.buscar")
    def test_causas_de_guerra_se_presentan_ordenadas_por_fecha(self, buscar):
        texto = (
            "El Tratado de Versalles de 1919 impuso duras condiciones económicas y territoriales a Alemania. "
            "La crisis económica mundial de 1929 provocó desempleo, inestabilidad y tensiones políticas. "
            "En 1933 Adolf Hitler llegó al poder y consolidó un régimen totalitario expansionista. "
            "El 1 de septiembre de 1939 Alemania invadió Polonia y comenzó la guerra en Europa.")
        buscar.return_value = [{"titulo": "Causas de la Segunda Guerra Mundial",
                               "url": "https://example.org/segunda-guerra",
                               "texto": texto, "calidad": 0.9}]
        r = self.cerebro.responder(
            "investiga las causas de la Segunda Guerra Mundial y ordénalas cronológicamente")
        self.assertEqual(r.origen, "web")
        self.assertIn("orden cronológico", r.texto.lower())
        self.assertLess(r.texto.index("1919"), r.texto.index("1929"))
        self.assertLess(r.texto.index("1929"), r.texto.index("1933"))
        self.assertLess(r.texto.index("1933"), r.texto.index("1939"))

    def test_extractor_no_acepta_frase_por_una_palabra_generica(self):
        texto = (
            "La memoria RAM almacena temporalmente datos e instrucciones que utiliza el procesador. "
            "La historia de la guerra incluye causas políticas y sociales de distintos países. "
        )
        frases, _ = web.extraer_evidencias(texto, "causas de la Segunda Guerra Mundial")
        self.assertFalse(any("memoria RAM" in f for f in frases))


if __name__ == "__main__":
    unittest.main()
