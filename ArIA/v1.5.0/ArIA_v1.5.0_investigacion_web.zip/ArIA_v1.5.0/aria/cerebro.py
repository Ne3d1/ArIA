"""El cerebro de ArIA: decide cómo responder a cada mensaje."""
import datetime
import re
from pathlib import Path

from . import analisis, archivos, codigo, config, entrada, mate, nucleo, razonamiento, web
from .memoria import normalizar, resumen_general, resumir
from .perfil import Perfil

AYUDA = """## Lo que sé hacer 🤖

- **Aprender**: `Aprender` o `/aprender` para ver ejemplos · `aprende que mi gato se llama Mou` · `cuando te pregunte X, responde Y` · `la respuesta es ...` (para corregirme)
- **Sobre ti** (lo recuerdo siempre): `me llamo Ana` · `soy Pau` (cambio de persona) · `me gusta el té` · `vivo en Girona` · `mi color favorito es el verde` · `sé más breve` · `qué sabes de mí` · `olvídame`
- **Internet**: `busca en internet …` · `investiga …` · `aprende de internet sobre …` · `/buscar tema` · `/investiga tema`. Puedo leer páginas y PDF públicos, comparar fuentes y guardar el conocimiento localmente. Si no encuentro respuesta local, puedo buscar automáticamente (configurable en Ajustes).
- **Matemáticas**: `2+3*4` · `calcula sqrt(81)` · `15% de 200` · `resuelve x^2-5x+6=0` · `deriva x^3` · `integra sin(x)`
- **Programación**: `escribe un programa de fibonacci en python` · `ejecuta` + bloque de código (te pedirá permiso)
- **Generación local**: `/generar tema` · `/entrenar-modelo` entrena un GPT pequeño desde cero · `/modelo` muestra lo aprendido
- **Análisis y razonamiento**: `analiza este texto: ...` · `analiza el archivo ruta` (con permiso) · puedo explicar causas, procesos, comparaciones y seguimientos usando evidencias de mi memoria
- **Archivos** (siempre pidiendo permiso): `lee el archivo ruta` · `resume el archivo ruta` · `aprende del archivo ruta` · `aprende de la carpeta ruta` · `lista la carpeta ruta` · o usa los botones 📎 y 📁
- **Comandos**: `/ayuda` · `/aprender` · `/memoria` · `/reglas` · `/fuentes` · `/perfil` · `/personas` · `/olvidar` (todo) · `/olvidar texto` (por fuente)
- Pulsa 👍 / 👎 para decirme si una respuesta fue buena
"""

QUIENES = (
    "Soy **ArIA**, una asistente que vive en tu ordenador 💻. Aprendo de lo que me enseñas, de tus archivos y de "
    "internet, y sé algo de matemáticas y programación. Escribe `ayuda` para ver todo lo que puedo hacer."
)

DIAS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
         "septiembre", "octubre", "noviembre", "diciembre"]


class Respuesta:
    def __init__(self, texto, origen="ia", pregunta=None):
        self.texto, self.origen, self.pregunta = texto, origen, pregunta


def limpiar_consulta(t):
    s = t.strip().strip("¿?¡!.").strip()
    s = re.sub(
        r"^(?:por favor[, ]+)?(?:busca(?:me)?|investiga|googlea|consulta)(?:\s+(?:en\s+(?:internet|la web|google|la red)))?"
        r"(?:\s+(?:sobre|acerca de|de))?\s+", "", s, flags=re.I)
    s = re.sub(
        r"^(?:aprende|estudia)\s+(?:de\s+internet\s+)?(?:sobre|acerca de)\s+", "", s, flags=re.I)
    s = re.sub(
        r"^(?:qu[ée] (?:es|son|significa|fue|era)|qui[ée]n(?:es)? (?:es|son|fue|fueron|era)|h[áa]blame de|"
        r"cu[ée]ntame (?:sobre|de)|dime (?:qu[ée]|algo) (?:sobre|de)|explica(?:me)?)\s+(?:el |la |los |las |un |una )?",
        "", s, flags=re.I)
    return s.strip() or t


def _fmt_fuente(fuente, titulo=""):
    if fuente.startswith("http"):
        return f"[{titulo or fuente}]({fuente})"
    if fuente.startswith("archivo:"):
        return f"📄 `{fuente[8:]}`"
    if fuente.startswith("usuario"):
        return "📝 lo que me enseñaste"
    return fuente



def palabras_para_tema(texto):
    return [w for w in re.findall(r"[a-z0-9]+", normalizar(texto)) if len(w) > 2]

def quiere_busqueda_web(texto):
    """Detecta una petición explícita de búsqueda o de enlace web."""
    n = normalizar(texto).lower().strip()
    patrones = (
        r"^(?:por favor[, ]+)?(?:busca(?:me)?|investiga|googlea|consulta)(?:\s+(?:en\s+(?:internet|la web|google|la red)))?\b",
        r"\b(?:busca|encuentra|dame|pasame|p[aá]same|env[ií]ame|necesito)\b.{0,50}\b(?:link|enlace|url|pagina web|web oficial)\b",
        r"^(?:cual es|dime|dame|pasame|p[aá]same)\s+(?:el\s+)?(?:link|enlace|url|web oficial)\b",
        r"\b(?:link|enlace|url)\s+(?:de|a|para)\b",
        r"^(?:la\s+)?web(?:\s+oficial)?\s+de\b",
        r"^(?:pagina\s+web|sitio\s+web)\s+de\b",
        r"\b(?:web|pagina web|sitio web)\s+de\b",
    )
    return any(re.search(p, n, re.I) for p in patrones)


class Cerebro:
    def __init__(self, cfg, memoria, permiso=None, confirmar=None, estado=None):
        self.cfg, self.mem = cfg, memoria
        self.permiso = permiso or (lambda ruta: "no")      # -> "una" | "siempre" | "no"
        self.confirmar = confirmar or (lambda msg: False)  # -> bool
        self.estado = estado or (lambda msg: None)
        self.historial = []
        self.ultima = None
        self.tema_actual = ""
        nucleo.verificar()
        self.perfil = Perfil(memoria, cfg, confirmar=lambda msg: self.confirmar(msg))

    # ---------------- entrada principal ----------------
    def responder(self, texto):
        # Limpieza Unicode conservadora: elimina caracteres invisibles que rompen
        # comandos/copias de prompts, pero conserva saltos de línea y código.
        t = entrada.limpiar_entrada(texto)
        if not t:
            return Respuesta("Escribe algo y te ayudo 🙂")
        t = self._resolver_seguimiento(t)
        r = self._procesar(t)
        self.historial += [("user", t), ("assistant", r.texto)]
        self.historial = self.historial[-12:]
        if r.pregunta:
            self.ultima = (r.pregunta, r.texto)
        return r

    def _resolver_seguimiento(self, texto):
        """Recupera el tema anterior en seguimientos breves de conversación."""
        n = normalizar(texto).strip(" ¿?¡!.,")
        if not self.tema_actual:
            return texto
        patrones = (
            (r"^(?:y )?por que$", "por qué"),
            (r"^(?:y )?como$", "cómo funciona"),
            (r"^(?:y )?como funciona$", "cómo funciona"),
            (r"^(?:y )?para que$", "para qué sirve"),
            (r"^(?:ponme )?ejemplos?$", "ejemplos de"),
            (r"^(?:mas|mas detalles|explica mas|amplia|continua)$", "amplía la explicación de"),
            (r"^(?:y las )?ventajas$", "ventajas de"),
            (r"^(?:y las )?desventajas$", "desventajas de"),
        )
        for patron, prefijo in patrones:
            if re.match(patron, n):
                return f"{prefijo} {self.tema_actual}"
        return texto

    def _procesar(self, t):
        if t.startswith("/"):
            return self._comando(t)
        m = re.match(r"^(?:hola|buenas|hey|ola|buenos d[ií]as|buenas tardes|buenas noches)[,!. ]+(.{3,})$", t, re.I | re.S)
        if m:
            return self._procesar(m.group(1).strip())
        for paso in (self._nucleo, self._archivos, self._perfil, self._ensenar, self._hora, self._ejecutar, self._mates,
                     self._codigo, self._analizar, self._generar, self._social):
            r = paso(t)
            if r:
                return r
        return self._conocimiento(t)

    # ---------------- comandos ----------------
    def _comando(self, t):
        # Separar por cualquier espacio en blanco (también tabuladores y saltos de línea)
        # y normalizar el nombre para que /Aprender y /aprender sean equivalentes.
        m = re.match(r"^/([^\s]+)(?:\s+(.*))?$", t.strip(), re.S)
        if not m:
            return Respuesta("Escribe `/ayuda` para ver los comandos disponibles.")
        cmd, arg = m.group(1).lower().strip(), (m.group(2) or "").strip()
        if cmd in ("ayuda", "help", "comandos"):
            if arg in ("aprender", "aprendizaje", "ensenar", "enseñar"):
                return Respuesta(self._ayuda_aprender())
            return Respuesta(AYUDA)
        if cmd in ("aprender", "aprendizaje", "ensenar", "enseñar", "learn"):
            if not arg:
                return Respuesta(self._ayuda_aprender())
            # Permite usar /aprender como alias de «aprende ...».
            return self._ensenar("aprende " + arg)
        if cmd == "memoria":
            return Respuesta(self.resumen_memoria())
        if cmd == "reglas":
            reglas = self.mem.reglas_aprendidas()
            logicas = self.mem.reglas_logicas()
            if not reglas and not logicas:
                return Respuesta("Todavía no he aprendido reglas generales. Enséñame matemáticas con `aprende que (2+2)*5=20` o lógica con `aprende que si algo es mamífero, entonces es vertebrado`.")
            bloques = ["## 🧠 Reglas que he aprendido"]
            bloques += [f"- **{r['nombre']}**: {r['explicacion']}\n  - Ejemplo: `{r['ejemplo']}`" for r in reglas]
            bloques += [f"- **Regla lógica:** si algo es **{r['antecedente']}**, también es **{r['consecuente']}**." for r in logicas]
            return Respuesta("\n\n".join(bloques))
        if cmd in ("buscar", "investiga", "investigar", "web"):
            if not arg:
                return Respuesta("Indica un tema. Ejemplo: `/investiga cómo funciona un procesador`.")
            return self._conocimiento("investiga " + arg, forzar_web=True)
        if cmd == "generar":
            return self._generar(arg, forzado=True)
        if cmd in ("entrenar-modelo", "entrenar", "train"):
            pasos = 100
            if arg:
                try:
                    pasos = max(1, min(10000, int(arg)))
                except ValueError:
                    return Respuesta("Indica un número de pasos, por ejemplo `/entrenar-modelo 500`.")
            self.estado("Entrenando un GPT local desde cero. Esto puede tardar…")
            resultado = self.mem.transformer.entrenar(pasos=pasos)
            if not resultado.get("ok"):
                return Respuesta("No he podido entrenar el GPT local: " + resultado.get("error", "error desconocido"), "generador")
            return Respuesta("## 🧠 Entrenamiento terminado\n\n"
                             f"- Caracteres de corpus: **{resultado['caracteres']:,}**\n"
                             f"- Pasos de entrenamiento: **{resultado['pasos']:,}**\n"
                             f"- Pérdida final: **{resultado['perdida']}**\n"
                             f"- Dispositivo: **{resultado['dispositivo']}**\n\n"
                             "He creado mis propios pesos desde cero y los he guardado localmente. No he descargado ningún modelo preentrenado.", "generador")
        if cmd in ("modelo", "generador", "estadisticas-modelo"):
            g = self.mem.generador.estadisticas()
            t = self.mem.transformer.estado()
            if t["disponible"]:
                estado_gpt = f"Entrenado y actualizado: **sí** · {t['caracteres']:,} caracteres · {t['pasos']:,} pasos · {t['dispositivo']}"
            elif t.get("desactualizado") and t["caracteres"]:
                estado_gpt = "Hay un GPT guardado, pero está desactualizado por nuevos datos; vuelve a usar `/entrenar-modelo`."
            elif not t.get("instalado"):
                estado_gpt = "PyTorch no está instalado; funciona el generador estadístico. Ejecuta `setup.sh` o `setup.bat`."
            else:
                estado_gpt = "Entrenado: **no** (usa el generador estadístico hasta entrenarlo)"
            return Respuesta("## Modelo de lenguaje local\n\n"
                             f"- Documentos aprendidos: **{g['documentos']}**\n"
                             f"- Tokens de entrenamiento n-grama: **{g['tokens']:,}**\n"
                             f"- Transiciones lingüísticas: **{g['transiciones']:,}**\n"
                             f"- GPT pequeño desde cero: {estado_gpt}\n\n"
                             "No descarga pesos ni envía datos fuera del equipo. Usa `/entrenar-modelo` para entrenar el GPT con tu memoria.")
        if cmd == "fuentes":
            return Respuesta(self.resumen_memoria(True))
        if cmd == "perfil":
            return Respuesta(self.perfil.resumen())
        if cmd == "personas":
            ps = self.perfil.personas()
            return Respuesta("👥 Conozco a: " + ", ".join(f"**{p}**" for p in ps) if ps else "Todavía no conozco a nadie.")
        if cmd == "olvidar":
            return self._olvidar(arg or None)
        return Respuesta("No conozco ese comando. Escribe `/ayuda` para ver los comandos disponibles.")

    @staticmethod
    def _ayuda_aprender():
        return ("## 🧠 Cómo enseñarme cosas\n\n"
                "- `aprende que mi gato se llama Mou` — guardar un dato.\n"
                "- `aprende que (2+2)*5=20` — detectar reglas matemáticas reutilizables.\n"
                "- `aprende que si algo es mamífero, entonces es vertebrado` — guardar reglas lógicas.\n"
                "- `aprende que un perro es mamífero` — guardar hechos para aplicar esas reglas.\n"
                "- `aprende que en Python ...` — guardar conocimientos y ejemplos de programación para recuperarlos después.\n"
                "- `cuando te pregunte X, responde Y` — guardar una respuesta.\n"
                "- `la respuesta es Y` — corregir mi última respuesta.\n"
                "- `aprende del archivo ruta` — aprender de un archivo (con permiso).\n\n"
                "También puedes usar `/aprender` para ver esta ayuda o `/aprender que ...` para guardar una nota.")

    def resumen_memoria(self, fuentes=False):
        e = self.mem.estadisticas()
        n_reglas = len(self.mem.reglas_aprendidas()) + len(self.mem.reglas_logicas())
        md = f"## 🧠 Mi memoria\n- **{e['trozos']}** fragmentos de conocimiento\n- **{e['qa']}** respuestas que me enseñaste\n- **{n_reglas}** reglas generales aprendidas\n"
        if fuentes or e["trozos"]:
            filas = self.mem.fuentes(15 if fuentes else 5)
            if filas:
                md += "\n**Fuentes recientes:**\n" + "\n".join(
                    f"- {_fmt_fuente(f)} ({n} fragmentos)" for f, n in filas)
        if fuentes:
            md += "\n\n" + self.perfil.resumen()
        return md

    def _olvidar(self, fuente):
        que = f"lo aprendido de «{fuente}»" if fuente else "TODO lo que he aprendido"
        if not self.confirmar(f"¿Seguro que quieres que olvide {que}?"):
            return Respuesta("Vale, no olvido nada 🙂")
        n = self.mem.olvidar(fuente)
        return Respuesta(f"🗑️ Hecho. He olvidado {n} fragmentos.")

    def valorar(self, bueno):
        if not self.ultima:
            return "Todavía no he respondido nada que valorar."
        preg, resp = self.ultima
        if bueno:
            self.mem.aprender_qa(preg, resp)
            self.mem.valorar(preg, 1)
            return "¡Gracias! 👍 Me quedo con esta respuesta para la próxima vez."
        self.mem.valorar(preg, -1)
        return "Gracias por avisar 👎. Si quieres, dime la buena con *«la respuesta es …»* y la aprenderé."

    # ---------------- aprender ----------------
    def _ensenar(self, t):
        # «Aprender» sin contenido es una petición de ayuda, no una pregunta para el modelo.
        n = normalizar(t).strip(" ¿?¡!.,")
        if n in ("aprender", "quiero aprender", "como aprendo", "como puedo aprender",
                 "ensenar", "quiero ensenarte", "como te enseno", "como puedo ensenarte"):
            return Respuesta(self._ayuda_aprender())

        m = re.match(
            r"^cuando (?:te )?(?:pregunte|diga|escriba)\s+(.+?)[,;:]?\s+(?:responde|contesta|di|dime)\s*[:,]?\s+(.+)$",
            t, re.I | re.S)
        if m:
            p, r = (x.strip(" \"'“”«»") for x in m.groups())
            self.mem.aprender_qa(p, r)
            return Respuesta(f"Apuntado ✅ Cuando me pregunten *«{p}»* responderé: {r}")

        m = re.match(
            r"^(?:no[,.!]?\s*)?(?:la respuesta (?:correcta )?es|deber[ií]as (?:responder|decir)|lo correcto es)\s*[:,]?\s+(.+)$",
            t, re.I | re.S)
        if m:
            if not self.ultima:
                return Respuesta("¿Respuesta a qué? Todavía no me has preguntado nada.")
            self.mem.aprender_qa(self.ultima[0], m.group(1).strip())
            self.mem.valorar(self.ultima[0], 1)
            return Respuesta(f"Gracias por corregirme 🙏 Cuando me pregunten *«{self.ultima[0]}»* responderé eso.")

        m = re.match(r"^(?:aprende|recuerda|memoriza|guarda|apunta)(?:\s+(?:que|esto|lo siguiente))?\s*[:,]?\s+(.+)$",
                     t, re.I | re.S)
        if m:
            cuerpo = m.group(1).strip()
            # Reglas lógicas reutilizables: «si algo es A, entonces también es B».
            logica = re.search(
                r"^si\s+(?:(?:un|una|todo|toda|cualquier|cualquiera)\s+)?(?:algo|alguien|ser|animal|objeto|elemento|persona|cosa)?\s*es\s+(.+?),\s*entonces\s+(?:tambien\s+)?(?:es|sera|se considera)\s+(.+)$",
                normalizar(cuerpo), re.I)
            if logica:
                ant, cons = (x.strip(" .") for x in logica.groups())
                if self.mem.aprender_regla_logica(ant, cons, cuerpo):
                    return Respuesta(f"He aprendido una regla lógica reutilizable 🧠: si algo es **{ant}**, puedo inferir que también es **{cons}**. La aplicaré a hechos que me enseñes.")
            hecho = re.match(r"^(?:un|una|el|la)\s+([\w áéíóúñ-]+?)\s+es\s+([\w áéíóúñ-]+)[.]?$", normalizar(cuerpo), re.I)
            if hecho:
                sujeto, predicado = hecho.groups()
                self.mem.aprender_hecho(sujeto, predicado)
                self.mem.aprender_texto(cuerpo, fuente="usuario:nota", titulo="Hecho")
                return Respuesta(f"He guardado el hecho: **{sujeto} es {predicado}**. Podré usarlo al aplicar reglas.")
            # Si la persona añade una explicación al ejemplo, extrae primero la igualdad numérica.
            ejemplo = re.search(r"([^=]{1,100}=\s*[-+]?\d+(?:[.,]\d+)?)", cuerpo)
            regla = mate.inferir_regla_ejemplo(ejemplo.group(1).strip() if ejemplo else cuerpo)
            if regla:
                self.mem.aprender_regla(**regla)
                return Respuesta(
                    f"He aprendido una regla reutilizable: **{regla['nombre']}** 🧠\n\n"
                    f"Tu ejemplo `{regla['ejemplo']}` demuestra que {regla['explicacion']}\n\n"
                    "Ahora puedo aplicarla a otros números, no solo recordar este resultado."
                )
            cuerpo_norm = normalizar(cuerpo)
            if ("propiedad distributiva" in cuerpo_norm or
                    ("multiplicar" in cuerpo_norm and "sum" in cuerpo_norm and "repart" in cuerpo_norm)):
                regla = {
                    "clave": "propiedad_distributiva",
                    "nombre": "Propiedad distributiva",
                    "explicacion": "La multiplicación se reparte entre los términos de una suma o resta: "
                                   "(a+b)×c = a×c+b×c y (a-b)×c = a×c-b×c.",
                    "ejemplo": cuerpo[:250],
                }
                self.mem.aprender_regla(**regla)
                return Respuesta("He aprendido la **propiedad distributiva** 🧠. Cuando multipliques una suma o resta "
                                 "por otro número, puedo repartir la multiplicación entre cada término y aplicar "
                                 "esa regla a nuevos cálculos.")
            sobre_ti = self.perfil.procesar(cuerpo)
            if sobre_ti:
                return Respuesta(sobre_ti, "perfil")
            if re.match(r"^(?:de\s+internet\s+)?(?:sobre|acerca de)\s+", cuerpo, re.I):
                r = self._conocimiento(limpiar_consulta(t), forzar_web=True)
                r.pregunta = None
                if r.origen == "web":
                    r.texto = "📚 He aprendido esto:\n\n" + r.texto
                return r
            n = self.mem.aprender_texto(cuerpo, fuente="usuario:nota", titulo="Nota")
            if not n:
                return Respuesta("Eso ya lo sabía 😉")
            return Respuesta(f"Apuntado ✅ Lo he guardado en mi memoria: *{cuerpo[:150]}*")
        return None

    # ---------------- perfil ----------------
    def _nucleo(self, t):
        r = nucleo.responder(t)
        return Respuesta(r, "nucleo") if r else None

    def _perfil(self, t):
        r = self.perfil.procesar(t)
        return Respuesta(r, "perfil") if r else None

    def _n_frases(self):
        return {"breve": 2, "detallado": 6}.get(self.perfil.pref("estilo"), 4)

    # ---------------- hora ----------------
    def _hora(self, t):
        n = normalizar(t).strip(" ¿?¡!.")
        ahora = datetime.datetime.now()
        if re.match(r"^(?:que hora es|dime la hora|hora actual|que hora tienes)$", n):
            return Respuesta(f"Son las **{ahora:%H:%M}** ⏰")
        if re.match(r"^(?:que dia es(?: hoy)?|que fecha es(?: hoy)?|fecha de hoy|a cuantos estamos)$", n):
            return Respuesta(f"Hoy es **{DIAS[ahora.weekday()]}, {ahora.day} de {MESES[ahora.month - 1]} de {ahora.year}** 📅")
        return None

    # ---------------- mates / código ----------------
    def _mates(self, t):
        reglas = [r["clave"] for r in self.mem.reglas_aprendidas()]
        r = mate.responder(t, reglas=reglas)
        return Respuesta(r, "mates") if r else None

    def _codigo(self, t):
        r = codigo.responder(t)
        md, cod, lang = r if r else (None, None, None)
        if not cod:
            # Recupera soluciones y patrones de programación que el usuario enseñó,
            # incluso cuando no existe una plantilla integrada para esa tarea.
            hallazgos = self.mem.buscar(t, k=4)
            aprendido = next((h for h in hallazgos
                              if h["fuente"].startswith("usuario") and h["cobertura"] >= 0.25
                              and ("```" in h["texto"] or "def " in h["texto"] or "python" in normalizar(h["texto"]))), None)
            if aprendido:
                return Respuesta("He recuperado un patrón de programación que me enseñaste. Lo uso como referencia; revisa los nombres y datos concretos antes de ejecutarlo:\n\n" + aprendido["texto"], "memoria", t)
            if not r:
                return None
            return Respuesta(md, "codigo")
        if cod and re.search(r"ejecut|corre|prueba|run\b", normalizar(t)):
            md += "\n\n" + self._correr(cod, lang)
        return Respuesta(md, "codigo")

    def _correr(self, cod, lang):
        if not self.cfg.get("ejecutar_codigo", True):
            return "🔒 La ejecución de código está desactivada en ⚙ Ajustes."
        if not self.confirmar(f"¿Permites que ejecute este código {lang} en tu ordenador?\n\n{cod[:500]}"):
            return "🔒 No lo he ejecutado (sin permiso)."
        salida, ok = codigo.ejecutar(cod, lang)
        return f"**{'▶️ Salida' if ok else '❌ Error'}:**\n```\n{salida}\n```"

    def _ejecutar(self, t):
        m = re.match(r"^(?:ejecuta|ejecutar|corre|run|prueba)\b[:\s]*(.*)$", t, re.I | re.S)
        if not m:
            return None
        resto = m.group(1).strip()
        if not resto:
            return Respuesta("Dime qué código ejecutar, por ejemplo:\n\n`ejecuta` seguido de un bloque ```` ```python ... ``` ````.")
        lang = "javascript" if re.match(r"^```(?:js|javascript|node)\b", resto) else "python"
        return Respuesta(self._correr(codigo.extraer(resto), lang), "codigo")

    # ---------------- análisis local ----------------
    def _analizar(self, t):
        m = re.match(r"^(?:analiza|analizar|examina|razona sobre)\s+(?:(?:este|el siguiente)\s+)?(?:texto\s*[:：]?\s*)?(.+)$", t, re.I | re.S)
        if not m:
            return None
        contenido = m.group(1).strip()
        if len(contenido) < 20:
            return Respuesta("Pásame el texto o los datos que quieres que analice. También puedes usar `analiza el archivo ruta`.")
        return Respuesta(analisis.analizar_texto(contenido), "analisis")

    def _generar(self, t, forzado=False):
        """Generación creativa explícita mediante el modelo estadístico entrenado localmente."""
        texto = (t or "").strip()
        if forzado:
            tema = re.sub(r"^(?:(?:un|una)\s+)?(?:(?:texto|historia|relato|cuento|parrafo)\s+)?(?:sobre|acerca de|de)\s+", "", texto, flags=re.I).strip()
        else:
            m = re.match(
                r"^(?:genera|generar|inventa|inventar|redacta|redactar|crea|crear|escribe|escribir)\s+"
                r"(?:(?:un|una)\s+)?(?:(?:texto|historia|relato|cuento|parrafo|continuacion)\s+)?"
                r"(?:sobre|acerca de|de)?\s*(.+)$", texto, re.I | re.S)
            if not m:
                return None
            tema = m.group(1).strip()
        if not tema:
            return Respuesta("Dime el tema. Ejemplo: `/generar una historia de ciencia ficción`.")
        hallazgos = self.mem.buscar(tema, k=12)
        semillas = [h["texto"] for h in hallazgos]
        generado = ""
        tipo = "generación estadística de n-gramas"
        if self.mem.transformer.disponible():
            base = semillas[0][:500] if semillas else tema
            continuacion = self.mem.transformer.generar(base + "\n", max_caracteres=900)
            if continuacion.strip():
                generado = (base + "\n" + continuacion).strip()
                tipo = "GPT pequeño entrenado desde cero con tu corpus local"
        if not generado:
            resultado = self.mem.generador.generar(tema, semillas, max_tokens=100)
            generado = resultado["texto"]
            if not generado:
                return Respuesta("Todavía no puedo generar una continuación útil. " + resultado["motivo"] +
                                  "\n\nCuando tengas suficiente material, puedes entrenar el GPT con `/entrenar-modelo`.", "generador")
        return Respuesta(
            "### ✍️ Texto generado localmente\n\n" + generado +
            f"\n\n---\n*{tipo}. Puede contener errores o mezclar contextos; no debe tratarse como información verificada.*",
            "generador", tema)

    # ---------------- social ----------------
    def _social(self, t):
        n = normalizar(t).strip(" ¿?¡!.,")
        nombre = self.cfg.get("nombre_usuario")
        if re.match(r"^(?:hola|buenas|hey|ola|buenos dias|buenas tardes|buenas noches|que tal|holi)$", n):
            return Respuesta(f"¡Hola{', ' + nombre if nombre else ''}! 👋 ¿En qué te ayudo?")
        if re.match(r"^(?:gracias|muchas gracias|mil gracias|genial|perfecto|vale gracias)$", n):
            return Respuesta("¡De nada! 😊")
        if re.match(r"^(?:adios|hasta luego|hasta pronto|chao|nos vemos|bye)$", n):
            return Respuesta("¡Hasta pronto! 👋")
        if re.match(r"^(?:como estas|que tal estas|como te va)$", n):
            return Respuesta("¡Muy bien, con ganas de aprender cosas nuevas! ¿Y tú?")
        if re.match(r"^(?:quien eres|como te llamas|que eres|presentate|tu nombre)$", n):
            return Respuesta(QUIENES + f" Mi creadora es **{nucleo.CREADORA}** 💜. Mis ayudantes son **{', '.join(nucleo.AYUDANTES)}**.")
        if re.match(r"^(?:ayuda|help|que sabes hacer|que puedes hacer|que haces|comandos)$", n):
            return Respuesta(AYUDA)
        return None

    # ---------------- archivos ----------------
    def _acceso(self, ruta_txt, carpeta=False):
        extra = self.cfg.get("carpetas_permitidas", [])
        p = archivos.resolver(ruta_txt, extra)
        if p is None:
            return None, Respuesta(f"No encuentro `{ruta_txt.strip()}`. Prueba con la ruta completa.", "error")
        if carpeta != p.is_dir():
            return None, Respuesta("Eso " + ("no es una carpeta." if carpeta else "es una carpeta, no un archivo."), "error")
        if archivos.es_sensible(p):
            return None, Respuesta("🔒 Ese archivo parece contener datos sensibles (claves, contraseñas…). No lo leo.", "error")
        if not archivos.esta_permitido(p, extra):
            decision = self.permiso(str(p))
            if decision == "no":
                return None, Respuesta(f"🔒 Sin permiso no puedo acceder a `{p}`.", "error")
            if decision == "siempre":
                base = p if p.is_dir() else p.parent
                self.cfg.setdefault("carpetas_permitidas", []).append(str(base))
                config.guardar(self.cfg)
        return p, None

    def _archivos(self, t):
        m = re.match(r"^(?:aprende|estudia|memoriza|incorpora)\s+(?:de\s+|del\s+|de\s+la\s+|la\s+)*(?:carpeta|directorio)\s+(.+)$", t, re.I)
        if m:
            p, err = self._acceso(m.group(1), carpeta=True)
            return err or Respuesta(self.aprender_ruta(p), "archivos")
        m = re.match(r"^(?:lista|listar|muestra|ver|qu[eé] hay en)\s+(?:el\s+contenido\s+de\s+)?(?:la\s+)?(?:carpeta|directorio)\s+(.+)$", t, re.I)
        if m:
            p, err = self._acceso(m.group(1), carpeta=True)
            if err:
                return err
            return Respuesta(f"### 📁 `{p}`\n\n" + "\n".join(f"- {x}" for x in archivos.listar(p)), "archivos")
        m = re.match(r"^(?:aprende|estudia|memoriza|incorpora)\s+(?:del?\s+|el\s+|este\s+)*(?:archivo|fichero|documento)\s+(.+)$", t, re.I)
        if m:
            p, err = self._acceso(m.group(1))
            return err or Respuesta(self.aprender_ruta(p), "archivos")
        m = re.match(r"^(?:analiza|analizar|examina)\s+(?:el\s+|este\s+)?(?:archivo|fichero|documento)\s+(.+)$", t, re.I)
        if m:
            p, err = self._acceso(m.group(1))
            if err:
                return err
            try:
                texto = archivos.leer(p)
            except archivos.ErrorArchivo as e:
                return Respuesta(f"⚠️ {e}", "error")
            return Respuesta(f"### Análisis de `{p.name}`\n\n" + analisis.analizar_texto(texto), "archivos")
        m = re.match(r"^(lee|leer|abre|abrir|muestra|mu[eé]strame|resume|resumir|resum[ií]me)\s+(?:el\s+|este\s+)?(?:archivo|fichero|documento)\s+(.+)$", t, re.I)
        if m:
            p, err = self._acceso(m.group(2))
            if err:
                return err
            return self._leer(p, resumir_=m.group(1).lower().startswith("resum"))
        return None

    def _leer(self, p, resumir_):
        try:
            texto = archivos.leer(p)
        except archivos.ErrorArchivo as e:
            return Respuesta(f"⚠️ {e}", "error")
        if not texto.strip():
            return Respuesta("El archivo está vacío (o es un PDF escaneado sin texto).", "archivos")
        if resumir_:
            res = resumen_general(texto)
            return Respuesta(f"### 📄 Resumen de `{p.name}`\n\n{res}\n\n*(Di «aprende del archivo {p.name}» y podré responder preguntas sobre él.)*", "archivos")
        corte = texto[:3000]
        extra = f"\n\n*… {len(texto) - 3000} caracteres más.*" if len(texto) > 3000 else ""
        return Respuesta(f"### 📄 `{p.name}`\n\n```\n{corte}\n```{extra}", "archivos")

    def aprender_ruta(self, p):
        """Aprende un archivo o carpeta (el permiso ya está dado). Devuelve Markdown."""
        p = Path(p)
        if archivos.es_sensible(p):
            return f"🔒 `{p.name}` parece contener datos sensibles; no lo aprendo."
        if p.is_dir():
            lista = archivos.archivos_de_carpeta(p)
            if not lista:
                return "No encontré archivos de texto, PDF o Word en esa carpeta."
            ok, trozos, fallos = 0, 0, 0
            for f in lista:
                try:
                    nuevos = 0
                    for bloque in archivos.iterar_texto(f):
                        nuevos += self.mem.aprender_texto(bloque, fuente=f"archivo:{f.name}", titulo=f.name)
                    ok, trozos = ok + 1, trozos + nuevos
                except archivos.ErrorArchivo:
                    fallos += 1
            return f"📚 He leído **{ok}** archivos de `{p.name}/` y guardado **{trozos}** fragmentos nuevos" + (f" ({fallos} no se pudieron leer)." if fallos else ".")
        try:
            n = 0
            caracteres = 0
            for bloque in archivos.iterar_texto(p):
                caracteres += len(bloque)
                n += self.mem.aprender_texto(bloque, fuente=f"archivo:{p.name}", titulo=p.name)
        except archivos.ErrorArchivo as e:
            return f"⚠️ {e}"
        if caracteres == 0:
            return f"`{p.name}` no tiene texto que aprender."
        return f"📚 He aprendido de `{p.name}`: **{n}** fragmentos nuevos. Ya puedes preguntarme sobre él."

    def analizar_contexto_pantalla(self, texto):
        """Analiza OCR localmente sin enviar contenido a modelos ni servicios externos."""
        texto = (texto or "").strip()[:10000]
        if not texto:
            return "No hay texto suficiente para analizar."
        n = normalizar(texto)
        indicios = []
        categorias = [
            (("def ", "class ", "import ", "function ", "console.log", "traceback"), "Parece que estás trabajando con código o un editor de programación."),
            (("http://", "https://", "buscar", "pestana", "direccion"), "Hay indicios de un navegador o una página web."),
            (("hoja de calculo", "celda", "formula", "sum(", "promedio"), "Parece contenido de una hoja de cálculo."),
            (("diapositiva", "presentacion", "powerpoint"), "Parece que estás preparando una presentación."),
            (("terminal", "bash", "powershell", "command not found", "python "), "Parece una terminal o consola."),
            (("bandeja de entrada", "para:", "asunto:", "correo"), "Parece una aplicación de correo."),
        ]
        for claves, descripcion in categorias:
            if any(k in n for k in claves):
                indicios.append(descripcion)
        resumen = analisis.analizar_texto(texto, max_frases=3)
        salida = ["## Análisis local de pantalla"]
        salida.extend(indicios or ["No puedo identificar con seguridad qué aplicación estás usando solo con este texto."])
        if resumen:
            salida += ["", resumen]
        salida += ["", "El análisis se ha hecho íntegramente en este equipo. No se ha enviado el OCR a ningún modelo ni servicio de IA."]
        return "\n".join(salida)

    def _componer(self, t, consulta, textos, fuentes, origen, nota_pre=""):
        generada = razonamiento.componer_respuesta(t or consulta, textos, max_frases=self._n_frases())
        resumen = generada["texto"] or resumir(consulta, textos, n=self._n_frases())
        if not resumen:
            return Respuesta("He encontrado coincidencias, pero no contienen una respuesta suficientemente relacionada. Necesito una fuente más específica.", "nada", t)
        md = nota_pre + resumen
        vistas, lineas = set(), []
        for f, titulo in fuentes:
            if f not in vistas:
                vistas.add(f)
                lineas.append(f"- {_fmt_fuente(f, titulo)}")
        if lineas:
            md += "\n\n**Fuentes:**\n" + "\n".join(lineas[:5])
        if generada["confianza"]:
            md += f"\n\n_Coincidencia de evidencias: {round(generada['confianza'] * 100)}% (no equivale a verificar la verdad)._"
        return Respuesta(md, origen, t)

    def _conocimiento(self, t, forzar_web=False):
        consulta = limpiar_consulta(t)
        if len(palabras_para_tema(consulta)) >= 1:
            self.tema_actual = consulta
        hecho_q = re.match(r"^(?:un|una|el|la)\s+([\w áéíóúñ-]+?)\s+es\s+([\w áéíóúñ-]+)[.?]?$", normalizar(consulta), re.I)
        if hecho_q:
            sujeto, predicado = hecho_q.groups()
            if self.mem.inferir_hecho(sujeto, predicado):
                return Respuesta(f"Sí. Puedo deducir que **{sujeto} es {predicado}** aplicando una regla que me enseñaste a un hecho que tengo guardado.", "razonamiento", t)
        forzar_web = forzar_web or quiere_busqueda_web(t)
        hallazgos = []
        if not forzar_web:
            qa = self.mem.mejor_qa(consulta)
            if qa:
                return Respuesta(qa["respuesta"] + "\n\n*(Esto ya lo había aprendido 🧠)*", "memoria", t)
            consultas = [consulta]
            consultas.extend(f"{consulta} {sub}" for sub in razonamiento.descomponer_pregunta(t))
            por_texto = {}
            for subconsulta in consultas:
                recuperados = self.mem.buscar(razonamiento.expandir_consulta(subconsulta), k=6)
                for h in recuperados:
                    previo = por_texto.get(h["texto"])
                    if previo is None or h["puntos"] > previo["puntos"]:
                        por_texto[h["texto"]] = h
            # La cobertura se calcula sobre las palabras de la pregunta original,
            # no sobre todos los sinónimos añadidos: así una expansión no falsea la relevancia.
            from .memoria import tokens as tokens_memoria
            terminos_originales = set(tokens_memoria(consulta))
            for h in por_texto.values():
                terminos_fragmento = set(tokens_memoria(h["texto"]))
                h["cobertura_original"] = (len(terminos_originales & terminos_fragmento) / len(terminos_originales)) if terminos_originales else 0.0
            hallazgos = sorted(por_texto.values(), key=lambda h: (h["cobertura_original"], h["puntos"]), reverse=True)[:10]
            umbral = float(self.cfg.get("umbral_cobertura", 0.6))
            relevantes = [h for h in hallazgos if h["cobertura_original"] >= umbral]
            if relevantes:
                return self._componer(t, consulta, [h["texto"] for h in relevantes[:8]],
                                      [(h["fuente"], h["titulo"]) for h in relevantes[:8]], "memoria")
        error_web = ""
        # Tras agotar la memoria local, la búsqueda automática es configurable.
        # Las consultas explícitas siempre prevalecen; nunca se busca en mitad de una respuesta local válida.
        forzar_web = forzar_web or bool(self.cfg.get("buscar_automaticamente_si_no_sabe", False))
        if forzar_web and self.cfg.get("buscar_en_internet", True):
            self.estado("Investigando en internet: buscando y leyendo varias fuentes…")
            try:
                fuentes = web.buscar(consulta, self.cfg.get("paginas_por_busqueda", 4))
            except web.ErrorWeb as e:
                fuentes, error_web = [], str(e)
            except Exception as e:
                fuentes, error_web = [], f"error inesperado ({str(e)[:120]})"
            if fuentes:
                nuevos = 0
                guardar_web = bool(self.cfg.get("aprender_de_internet", True))
                if guardar_web:
                    for f in fuentes:
                        # Guardamos solo texto extraído, con URL y título como procedencia.
                        nuevos += self.mem.aprender_texto(f["texto"], fuente=f["url"], titulo=f["titulo"])
                cabecera = (f"🔎 **Investigación web:** he consultado {len(fuentes)} fuentes. "
                            + (f"He incorporado {nuevos} fragmentos nuevos a mi memoria local.\n\n" if guardar_web
                               else "No he guardado los resultados porque el aprendizaje web está desactivado.\n\n"))
                respuesta = self._componer(t, consulta, [f["texto"] for f in fuentes],
                                           [(f["url"], f["titulo"]) for f in fuentes], "web", nota_pre=cabecera)
                return respuesta
        # No mostrar una coincidencia débil como si fuera una respuesta. Evita
        # listas de rutas, títulos o frases que solo comparten una palabra.
        if error_web:
            motivo = f"No he podido buscar en internet: {error_web}"
        elif forzar_web and not self.cfg.get("buscar_en_internet", True):
            motivo = "Las búsquedas web están desactivadas en ⚙ Ajustes."
        elif forzar_web:
            motivo = "No he encontrado resultados útiles en internet."
        else:
            motivo = "No tengo ese dato en mi memoria. Si quieres, pídeme expresamente que lo busque en internet."
        return Respuesta(
            f"No sé responder a eso todavía 😅. {motivo}\n\nPuedes **enseñármelo**: `aprende que …`, "
            "`cuando te pregunte X, responde Y`, o darme un archivo con 📎. Trabajo con razonamiento y memoria locales; no utilizo modelos externos.", "nada", t)
