# Comprensión lectora

## Definición
Comprender un texto consiste en construir una representación de lo que comunica, no solo reconocer palabras. Conviene identificar el tema, la idea principal, las ideas secundarias, la intención, el público y la relación entre las partes.

## Método de trabajo
Primero se lee el texto completo; después se localizan palabras clave y conectores; luego se separan afirmaciones, ejemplos y conclusiones. Finalmente se comprueba que el resumen conserve el sentido original sin añadir datos ajenos.

## Ejemplo explicado
Si un texto afirma que una medida redujo el consumo después de aplicarse, eso describe una secuencia temporal. No demuestra por sí solo que la medida fuera la causa: harían falta datos que descarten otras explicaciones.

## Errores y límites
Confundir tema con idea principal; copiar frases sin entenderlas; eliminar condiciones importantes; convertir una posibilidad en certeza.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de comprensión lectora?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
