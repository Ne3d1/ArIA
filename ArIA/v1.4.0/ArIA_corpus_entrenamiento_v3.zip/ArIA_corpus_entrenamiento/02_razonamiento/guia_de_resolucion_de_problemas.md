# Resolución general de problemas

1. Reformula el problema sin cambiar su sentido.
2. Identifica el resultado que se busca.
3. Separa datos conocidos, incógnitas y restricciones.
4. Divide el problema en partes pequeñas.
5. Elige un método y explica por qué.
6. Resuelve cada parte.
7. Comprueba unidades, límites y casos extremos.
8. Compara el resultado con el objetivo.
9. Comunica la solución y las incertidumbres.

Si el primer método falla, revisa los supuestos antes de repetirlo. Una solución válida debe responder al problema original, no solo producir un resultado numérico.
