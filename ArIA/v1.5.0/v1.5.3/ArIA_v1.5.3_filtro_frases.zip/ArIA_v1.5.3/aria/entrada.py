"""Preprocesamiento conservador de prompts para ArIA (sin modelos externos)."""
import unicodedata

_CARACTERES_INVISIBLES = "\ufeff\u200b\u200c\u200d\u2060"


def limpiar_entrada(texto: str) -> str:
    """Limpia ruido Unicode y finales de línea sin alterar bloques de código."""
    if texto is None:
        return ""
    texto = unicodedata.normalize("NFKC", str(texto))
    for caracter in _CARACTERES_INVISIBLES:
        texto = texto.replace(caracter, "")
    texto = texto.replace("\r\n", "\n").replace("\r", "\n")
    # Los espacios no separables suelen llegar al copiar prompts desde PDF/web.
    texto = texto.replace("\u00a0", " ").replace("\u202f", " ")
    return texto.strip()
