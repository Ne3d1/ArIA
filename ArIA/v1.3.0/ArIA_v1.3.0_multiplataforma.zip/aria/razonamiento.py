"""Motor de razonamiento y composición local de ArIA.

No usa redes neuronales, modelos descargados ni servicios remotos. Combina
recuperación léxica, expansión semántica explícita, análisis de intención,
selección de evidencias y composición por estructuras discursivas.
"""
from __future__ import annotations

import re
import unicodedata
from collections import Counter

try:
    from rapidfuzz import fuzz
except ImportError:  # pragma: no cover - fallback sin dependencia opcional
    fuzz = None

_STOP = set("""el la los las un una unos unas de del al a en y o u que se su sus por con para como es son ser
esta este esto estas estos ese esa eso lo le les me mi mis tu tus te nos si no mas pero ya muy sobre entre hay
fue ha han he era eran cual cuales quien quienes cuando donde cuanto cuantos dime explica explicame sabes puedes
podrias hablame cuentame the of and to in is are for on with it that this i you what who how amb per com""".split())

# Expansiones transparentes, pequeñas y editables. No son embeddings ni un modelo.
_SINONIMOS = {
    "ordenador": {"computadora", "pc", "equipo", "ordinador"}, "ordinador": {"ordenador", "computadora", "pc"}, "computadora": {"ordenador", "pc"},
    "movil": {"telefono", "celular", "smartphone"}, "telefono": {"movil", "celular"},
    "coche": {"auto", "automovil", "vehiculo", "cotxe"}, "cotxe": {"coche", "auto", "vehiculo"}, "auto": {"coche", "automovil"},
    "rapido": {"veloz", "rapidamente"}, "veloz": {"rapido"},
    "dinero": {"capital", "fondos"}, "trabajo": {"empleo", "labor"},
    "comprar": {"adquirir", "obtener"}, "adquirir": {"comprar"},
    "problema": {"dificultad", "inconveniente", "problema"}, "dificultad": {"problema"},
    "feina": {"trabajo", "empleo"}, "treball": {"trabajo", "empleo"},
    "avantatge": {"ventaja", "beneficio"}, "desavantatge": {"desventaja", "inconveniente"},
    "causa": {"motivo", "razon", "origen"}, "motivo": {"causa", "razon"},
    "ventaja": {"beneficio", "punto_fuerte"}, "desventaja": {"inconveniente", "limitacion", "riesgo", "problema", "dependencia"},
    "depende": {"limitacion", "condicion", "variable"}, "bajar": {"disminuir", "reducir", "descender"},
    "explicar": {"describir", "aclarar", "detallar"}, "definicion": {"significado", "concepto"},
    "crear": {"desarrollar", "construir", "producir"}, "desarrollar": {"crear", "construir"},
    "aumentar": {"incrementar", "crecer", "subir"}, "disminuir": {"reducir", "bajar"},
}

_INTENCIONES = {
    "causa": re.compile(r"\b(por que|porque|per que|perque|causa|motivo|razon|devido a|debido a|ja que)\b"),
    "proceso": re.compile(r"\b(como funciona|como se hace|com funciona|com es fa|com es|proceso|proces|pasos|passos|procedimiento|procediment)\b"),
    "comparacion": re.compile(r"\b(diferencia|diferencies|compar|versus|frente a|millor que|pitjor que|mejor que|peor que)\b"),
    "ventajas": re.compile(r"\b(ventajas|avantatges|beneficios|beneficis|puntos fuertes)\b"),
    "desventajas": re.compile(r"\b(desventajas|desavantatges|inconvenientes|limitaciones|limitacions|riesgos)\b"),
    "lista": re.compile(r"\b(tipos|tipus|clases|exemples|ejemplos|lista|llista|cuales son|quins son|quines son|menciona)\b"),
    "resumen": re.compile(r"\b(resumen|resume|resumeme|resumeix|resum|en pocas palabras|idea principal)\b"),
    "definicion": re.compile(r"\b(que es|que significa|què vol dir|define|definicion|definicio|concepte|concepto)\b"),
}


def normalizar(texto: str) -> str:
    texto = unicodedata.normalize("NFD", str(texto).lower())
    return "".join(c for c in texto if unicodedata.category(c) != "Mn")


def palabras(texto: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]+", normalizar(texto)) if w not in _STOP and len(w) > 1]


def expandir_consulta(texto: str) -> str:
    """Añade sinónimos acotados para recuperar documentos con otras palabras."""
    base = palabras(texto)
    ampliadas = list(base)
    for palabra in base:
        ampliadas.extend(sorted(_SINONIMOS.get(palabra, ()))[:2])
    return " ".join(dict.fromkeys(ampliadas))


def detectar_intencion(consulta: str) -> str:
    n = normalizar(consulta)
    # «por qué» se separa de «porque» para no confundir pregunta con explicación.
    if re.search(r"\b(por que|per que)\b", n):
        return "causa"
    for nombre, patron in _INTENCIONES.items():
        if patron.search(n):
            return nombre
    return "general"


def descomponer_pregunta(consulta: str) -> list[str]:
    """Descompone peticiones compuestas en subobjetivos interpretables."""
    n = normalizar(consulta)
    partes = []
    if re.search(r"\b(ventajas|avantatges|beneficios|beneficis)\b", n):
        partes.append("ventajas y beneficios")
    if re.search(r"\b(desventajas|desavantatges|inconvenientes|limitaciones|riesgos)\b", n):
        partes.append("desventajas, inconvenientes y riesgos")
    if re.search(r"\b(como funciona|com funciona|como se hace|com es fa|proceso|processos|pasos|passos)\b", n):
        partes.append("funcionamiento y pasos")
    if re.search(r"\b(ejemplos|por ejemplo)\b", n):
        partes.append("ejemplos")
    return partes


def _frases(textos):
    salida = []
    for origen, texto in enumerate(textos):
        for pos, frase in enumerate(re.split(r"(?<=[.!?])\s+|\n+", texto)):
            frase = frase.strip(" \t-*•")
            if len(frase) >= 24:
                salida.append((frase, origen, pos))
    return salida


def _similitud(consulta, frase):
    q, f = set(palabras(consulta)), set(palabras(frase))
    if not q or not f:
        return 0.0
    cobertura = len(q & f) / len(q)
    jaccard = len(q & f) / len(q | f)
    fuzzy = (fuzz.token_set_ratio(normalizar(consulta), normalizar(frase)) / 100) if fuzz else 0.0
    return min(1.0, 0.58 * cobertura + 0.22 * jaccard + 0.20 * fuzzy)


def _puntuacion(consulta, frase, intencion):
    n = normalizar(frase)
    score = _similitud(consulta, frase)
    if intencion == "causa" and re.search(r"\b(porque|debido a|ya que|puesto que|a causa de|por ello)\b", n):
        score += 0.16
    elif intencion == "proceso" and re.search(r"\b(primero|despues|luego|finalmente|consiste|proceso|mediante)\b", n):
        score += 0.12
    elif intencion == "ventajas" and re.search(r"\b(ventaja|beneficio|permite|mejora|facilita)\b", n):
        score += 0.14
    elif intencion == "desventajas" and re.search(r"\b(desventaja|riesgo|limita|problema|inconveniente|sin embargo|depende|puede bajar|puede disminuir|no obstante)\b", n):
        score += 0.14
    elif intencion == "definicion" and re.search(r"\b(es|significa|se define|consiste en|se trata de)\b", n):
        score += 0.10
    return min(1.0, score)


def _limpiar_repeticiones(frases):
    elegidas, vistos = [], set()
    for frase in frases:
        clave = " ".join(palabras(frase))
        if not clave or clave in vistos:
            continue
        if any(_similitud(frase, anterior) > 0.88 for anterior in elegidas):
            continue
        vistos.add(clave)
        elegidas.append(frase)
    return elegidas


def _es_catalan(consulta: str) -> bool:
    n = normalizar(consulta)
    indicios = ("com funciona", "per que", "perque", "quin ", "quina ",
                "quins ", "quines ", "explica'm", "explicam", "avantatges", "desavantatges",
                "resumeix", "diferencies", "amb ")
    return sum(1 for x in indicios if x in n) >= 1


def componer_respuesta(consulta: str, textos: list[str], max_frases: int = 4) -> dict:
    """Construye una respuesta nueva y estructurada usando solo evidencias recibidas.

    Devuelve texto, confianza heurística e indicios de qué subpreguntas se cubrieron.
    La confianza mide ajuste textual, no veracidad de la fuente.
    """
    if not textos:
        return {"texto": "", "confianza": 0.0, "cubierto": []}
    intencion = detectar_intencion(consulta)
    subobjetivos = descomponer_pregunta(consulta)
    candidatas = _frases(textos)
    puntuadas = sorted(
        ((_puntuacion(consulta, f, intencion), f, origen, pos) for f, origen, pos in candidatas),
        key=lambda x: (x[0], -x[2], -x[3]), reverse=True,
    )
    # Para peticiones compuestas, favorecer una evidencia distinta por objetivo.
    seleccion = []
    if subobjetivos:
        for objetivo in subobjetivos:
            mejor = max(candidatas, key=lambda x: _puntuacion(objetivo, x[0], detectar_intencion(objetivo)), default=None)
            if mejor and _puntuacion(objetivo, mejor[0], detectar_intencion(objetivo)) >= 0.12:
                seleccion.append(mejor[0])
    umbral = 0.10 if intencion == "general" else 0.12
    for score, frase, _, _ in puntuadas:
        if score >= umbral and len(seleccion) < max_frases:
            seleccion.append(frase)
    # Al preguntar por un proceso, la frase definitoria suele ir seguida de
    # los pasos. Recuperamos la frase contigua del mismo fragmento como contexto.
    if intencion == "proceso" and len(seleccion) < max_frases:
        posiciones = {(f, origen, pos) for f, origen, pos in candidatas if f in seleccion}
        for frase, origen, pos in candidatas:
            if len(seleccion) >= max_frases:
                break
            if any(o == origen and abs(p - pos) == 1 for _, o, p in posiciones):
                seleccion.append(frase)
    seleccion = _limpiar_repeticiones(seleccion)[:max_frases]
    if not seleccion:
        # No inventar respuesta si la coincidencia es débil.
        return {"texto": "", "confianza": puntuadas[0][0] if puntuadas else 0.0, "cubierto": []}

    mejor = puntuadas[0][0] if puntuadas else 0.0
    media = sum(_puntuacion(consulta, f, intencion) for f in seleccion) / len(seleccion)
    confianza = round(min(0.96, 0.55 * mejor + 0.45 * media), 2)

    if _es_catalan(consulta):
        inicios = {
            "causa": "L'explicació que trobo a les meves fonts és:",
            "proceso": "Així es descriu el funcionament a la informació que tinc:",
            "comparacion": "Aquests són els punts de comparació que apareixen a les meves fonts:",
            "ventajas": "Els avantatges que s'hi mencionen són:",
            "desventajas": "Les limitacions o desavantatges que hi apareixen són:",
            "definicion": "Amb la informació disponible, es pot explicar així:",
            "resumen": "En resum, les idees principals són:",
            "lista": "Això és el que he trobat:",
            "general": "Aquesta és la informació més rellevant que puc donar amb les fonts disponibles:",
        }
    else:
        inicios = {
            "causa": "La explicación que encuentro en mis fuentes es:",
            "proceso": "Así se describe el funcionamiento en la información que tengo:",
            "comparacion": "Estos son los puntos de comparación que aparecen en mis fuentes:",
            "ventajas": "Las ventajas que se mencionan son:",
            "desventajas": "Las limitaciones o desventajas que aparecen son:",
            "definicion": "Con la información disponible, se puede explicar así:",
            "resumen": "En resumen, las ideas principales son:",
            "lista": "Esto es lo que he encontrado:",
            "general": "Esto es lo más relevante que puedo responder con la información que tengo:",
        }
    inicio = inicios.get(intencion, inicios["general"])

    cuerpo = "\n\n".join(f"- {f}" for f in seleccion) if len(seleccion) > 1 else seleccion[0]
    aviso = ""
    if confianza < 0.22:
        aviso = "\n\n_No tengo evidencias suficientes para afirmarlo con seguridad; esto es una coincidencia parcial._"
    elif confianza < 0.38:
        aviso = "\n\n_La respuesta es provisional: convendría contrastarla con más información._"
    return {"texto": inicio + "\n\n" + cuerpo + aviso, "confianza": confianza, "cubierto": subobjetivos}
