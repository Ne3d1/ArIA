# Razonamiento inductivo

## Definición
La inducción generaliza a partir de observaciones. Sus conclusiones son probables y dependen de la calidad, cantidad y representatividad de los datos.

## Método de trabajo
Reúne observaciones independientes; busca contraejemplos; considera el tamaño de la muestra y los sesgos; expresa la conclusión con un grado de confianza proporcional a la evidencia.

## Ejemplo explicado
Observar que varias piezas de metal se dilatan al calentarse apoya una generalización, pero conviene estudiar distintos metales y condiciones.

## Errores y límites
Una muestra pequeña o sesgada no representa necesariamente a toda una población. La ausencia de contraejemplos observados no demuestra una regla universal.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de razonamiento inductivo?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
