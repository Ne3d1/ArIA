#!/usr/bin/env bash
# Ejecuta ArIA en Linux/macOS. Admite --cli y --datos CARPETA.
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ] || ! .venv/bin/python -c 'import requests, bs4, ddgs, sympy, pypdf, docx, mss, PIL, pytesseract, psutil, pygetwindow, rapidfuzz, torch' 2>/dev/null; then
  echo "Preparando o reparando el entorno ..."
  bash ./setup.sh || exit 1
fi
exec .venv/bin/python main.py "$@"
