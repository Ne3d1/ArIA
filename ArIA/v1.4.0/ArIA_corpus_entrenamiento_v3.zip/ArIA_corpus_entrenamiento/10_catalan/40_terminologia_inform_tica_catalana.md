# Terminologia informàtica catalana

## Definición
La terminologia tècnica ha de ser precisa i coherent. Quan hi ha diverses formes, convé mantenir la mateixa denominació dins d'un mateix document.

## Método de trabajo
Diferencia maquinari i programari; memòria i emmagatzematge; fitxer i carpeta; xarxa i Internet; procés i programa.

## Ejemplo explicado
«El sistema operatiu gestiona els processos i l'accés als dispositius».

## Errores y límites
Evita alternar termes diferents si no són sinònims exactes. Si un terme és ambigu, defineix-lo.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de terminologia informàtica catalana?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
