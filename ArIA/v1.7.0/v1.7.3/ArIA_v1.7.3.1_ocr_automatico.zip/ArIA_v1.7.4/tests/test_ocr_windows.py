import os
import unittest
import tempfile
from pathlib import Path
from unittest.mock import patch

from aria import pantalla


class DeteccionTesseract(unittest.TestCase):
    def test_prioriza_variable_tesseract_cmd(self):
        with patch.dict(os.environ, {"TESSERACT_CMD": r"C:\OCR\tesseract.exe"}, clear=False), \
             patch("aria.pantalla.Path.is_file", return_value=True), \
             patch("aria.pantalla.shutil.which", return_value=None):
            self.assertEqual(pantalla._buscar_ejecutable_tesseract(), r"C:\OCR\tesseract.exe")

    def test_usa_path_si_esta_disponible(self):
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("TESSERACT_CMD", None)
            with patch("aria.pantalla.shutil.which", return_value=r"C:\OCR\tesseract.exe"):
                self.assertEqual(pantalla._buscar_ejecutable_tesseract(), r"C:\OCR\tesseract.exe")

    def test_detecta_ruta_estandar_windows_sin_path(self):
        with patch("aria.pantalla.os.name", "nt"), \
             patch.dict(os.environ, {"TESSERACT_CMD": "", "ProgramFiles": r"C:\Program Files", "ProgramFiles(x86)": r"C:\Program Files (x86)"}, clear=False), \
             patch("aria.pantalla.shutil.which", return_value=None), \
             patch("aria.pantalla.Path.is_file", return_value=True):
            self.assertEqual(pantalla._buscar_ejecutable_tesseract(), r"C:\Program Files\Tesseract-OCR\tesseract.exe")

    def test_configura_directorio_privado_de_idiomas_si_esta_completo(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "ArIA" / "tessdata"
            root.mkdir(parents=True)
            (root / "spa.traineddata").write_bytes(b"spa")
            (root / "eng.traineddata").write_bytes(b"eng")
            with patch("aria.pantalla.platform.system", return_value="Windows"), \
                 patch.dict(os.environ, {"LOCALAPPDATA": tmp}, clear=False):
                config = pantalla._configuracion_tessdata()
            self.assertIn("--tessdata-dir", config)
            self.assertIn(str(root), config)

    def test_configura_pytesseract(self):
        class Modulo:
            class pytesseract:
                tesseract_cmd = "tesseract"
        with patch("aria.pantalla._buscar_ejecutable_tesseract", return_value=r"C:\OCR\tesseract.exe"):
            self.assertEqual(pantalla.configurar_tesseract(Modulo), r"C:\OCR\tesseract.exe")
            self.assertEqual(Modulo.pytesseract.tesseract_cmd, r"C:\OCR\tesseract.exe")


if __name__ == "__main__":
    unittest.main()
