"""Programación básica: plantillas de código y ejecución controlada."""
import re
import shutil
import subprocess
import sys
import tempfile

from .memoria import normalizar

# (palabras clave, título, explicación, código Python, código JavaScript o None)
PLANTILLAS = [
    (("hola mundo", "hello world"), "Hola mundo", "Muestra un texto por pantalla.",
     'print("¡Hola, mundo!")',
     'console.log("¡Hola, mundo!");'),
    (("factorial",), "Factorial", "Multiplica todos los enteros desde 1 hasta n.",
     '''def factorial(n):
    if n < 0:
        raise ValueError("n debe ser >= 0")
    resultado = 1
    for i in range(2, n + 1):
        resultado *= i
    return resultado

print(factorial(5))  # 120''',
     '''function factorial(n) {
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}
console.log(factorial(5)); // 120'''),
    (("fibonacci",), "Serie de Fibonacci", "Cada número es la suma de los dos anteriores.",
     '''def fibonacci(n):
    a, b = 0, 1
    serie = []
    for _ in range(n):
        serie.append(a)
        a, b = b, a + b
    return serie

print(fibonacci(10))  # [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]''',
     '''function fibonacci(n) {
  const serie = [];
  let [a, b] = [0, 1];
  for (let i = 0; i < n; i++) { serie.push(a); [a, b] = [b, a + b]; }
  return serie;
}
console.log(fibonacci(10));'''),
    (("primo", "primos"), "Números primos", "Un primo solo es divisible entre 1 y sí mismo; basta probar hasta √n.",
     '''def es_primo(n):
    if n < 2:
        return False
    for d in range(2, int(n ** 0.5) + 1):
        if n % d == 0:
            return False
    return True

print([n for n in range(1, 50) if es_primo(n)])''', None),
    (("par o impar", "par impar", "es par", "paridad"), "Par o impar", "El resto (%) de dividir entre 2 decide la paridad.",
     '''numero = 7
if numero % 2 == 0:
    print(f"{numero} es par")
else:
    print(f"{numero} es impar")''', None),
    (("ordenar", "ordena", "sort"), "Ordenar una lista", "`sorted` devuelve una lista nueva ordenada.",
     '''numeros = [5, 2, 9, 1, 7]
print(sorted(numeros))                # de menor a mayor
print(sorted(numeros, reverse=True))  # de mayor a menor''',
     '''const numeros = [5, 2, 9, 1, 7];
console.log([...numeros].sort((a, b) => a - b));'''),
    (("palindromo", "invertir", "al reves"), "Invertir texto y palíndromos", "Con `[::-1]` se da la vuelta a una cadena.",
     '''def es_palindromo(texto):
    limpio = "".join(c.lower() for c in texto if c.isalnum())
    return limpio == limpio[::-1]

print("hola"[::-1])                         # aloh
print(es_palindromo("Anita lava la tina"))  # True''', None),
    (("tabla de multiplicar", "tabla del", "tablas de multiplicar"), "Tabla de multiplicar", "Un bucle `for` recorre del 1 al 10.",
     '''n = 7
for i in range(1, 11):
    print(f"{n} x {i} = {n * i}")''', None),
    (("fizzbuzz", "fizz buzz"), "FizzBuzz", "Clásico ejercicio de condicionales y módulo.",
     '''for i in range(1, 31):
    if i % 15 == 0:
        print("FizzBuzz")
    elif i % 3 == 0:
        print("Fizz")
    elif i % 5 == 0:
        print("Buzz")
    else:
        print(i)''',
     '''for (let i = 1; i <= 30; i++) {
  console.log(i % 15 === 0 ? "FizzBuzz" : i % 3 === 0 ? "Fizz" : i % 5 === 0 ? "Buzz" : i);
}'''),
    (("contar palabras", "frecuencia de palabras"), "Contar palabras", "`Counter` cuenta cuántas veces aparece cada palabra.",
     '''from collections import Counter

texto = "el perro y el gato y el pez"
print(Counter(texto.split()).most_common())''', None),
    (("media", "promedio", "maximo", "minimo"), "Media, máximo y mínimo", "Funciones integradas de Python.",
     '''datos = [4, 8, 15, 16, 23, 42]
print("media:", sum(datos) / len(datos))
print("máximo:", max(datos), "mínimo:", min(datos))''', None),
    (("leer archivo", "leer fichero", "abrir archivo", "leer un archivo", "leer un fichero"), "Leer un archivo", "`with` cierra el archivo automáticamente.",
     '''with open("archivo.txt", encoding="utf-8") as f:
    for linea in f:
        print(linea.rstrip())''', None),
    (("clase", "objeto", "poo"), "Una clase", "Una clase agrupa datos y funciones (métodos).",
     '''class Persona:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad

    def saludar(self):
        return f"Hola, soy {self.nombre} y tengo {self.edad} años"

print(Persona("Ana", 30).saludar())''', None),
    (("bucle", "bucles", "for", "while", "repetir"), "Bucles", "`for` recorre una secuencia; `while` repite mientras se cumpla la condición.",
     '''for i in range(5):
    print("for:", i)

contador = 0
while contador < 3:
    print("while:", contador)
    contador += 1''',
     '''for (let i = 0; i < 5; i++) console.log("for:", i);
let c = 0;
while (c < 3) { console.log("while:", c); c++; }'''),
    (("funcion", "funciones", "def"), "Funciones", "`def` define una función reutilizable.",
     '''def sumar(a, b):
    return a + b

print(sumar(2, 3))  # 5''',
     '''function sumar(a, b) { return a + b; }
console.log(sumar(2, 3)); // 5'''),
    (("calculadora",), "Mini calculadora", "Pide dos números y una operación.",
     '''a = float(input("Primer número: "))
b = float(input("Segundo número: "))
op = input("Operación (+, -, *, /): ")
if op == "+": print(a + b)
elif op == "-": print(a - b)
elif op == "*": print(a * b)
elif op == "/": print(a / b if b else "No se puede dividir entre 0")
else: print("Operación no válida")''', None),
    (("diccionario", "diccionarios"), "Diccionarios", "Guardan pares clave → valor.",
     '''edades = {"Ana": 30, "Luis": 25}
edades["Marta"] = 28
for nombre, edad in edades.items():
    print(nombre, edad)''', None),
    (("lista", "listas", "array"), "Listas", "Colecciones ordenadas y modificables.",
     '''frutas = ["manzana", "pera"]
frutas.append("uva")
print(frutas, len(frutas), frutas[0])
print([f.upper() for f in frutas])''',
     '''const frutas = ["manzana", "pera"];
frutas.push("uva");
console.log(frutas, frutas.length, frutas[0]);'''),
]

_VERBOS = re.compile(
    r"\b(escribe|escribeme|haz|hazme|crea|creame|programa|programame|genera|dame|muestrame|ensenyame|ensename|"
    r"necesito|quiero|ejemplo|como (?:se )?(?:hace|programa|escribe|hago))\b"
)
_NOMBRES = re.compile(r"\b(codigo|programa|funcion|script|algoritmo|python|javascript|js|ejemplo|snippet)\b")


def _palabras(n):
    return set(re.findall(r"\w+", n))


def _tiene(n, palabras, clave):
    return clave in n if " " in clave else clave in palabras


def _buscar_plantilla(n):
    pal = _palabras(n)
    mejor, puntos = None, 0
    for pl in PLANTILLAS:
        p = sum(len(c) for c in pl[0] if _tiene(n, pal, c))
        if p > puntos:
            mejor, puntos = pl, p
    return mejor


def lenguaje(n):
    pal = _palabras(n)
    return "javascript" if pal & {"javascript", "js", "node"} else "python"


def es_peticion(texto):
    n = normalizar(texto)
    if len(n) > 160:
        return False
    return bool(_VERBOS.search(n)) and (bool(_NOMBRES.search(n)) or _buscar_plantilla(n) is not None)


def responder(texto):
    """Devuelve (markdown, código, lenguaje) o None."""
    if not es_peticion(texto):
        return None
    n = normalizar(texto)
    lang = lenguaje(n)
    pl = _buscar_plantilla(n)
    if pl is None:
        temas = ", ".join(sorted({p[1].lower() for p in PLANTILLAS}))
        return (
            "Todavía solo tengo generadores locales para ciertos ejemplos. Prueba con: " + temas + ".\n\n"
            "También puedes enseñarme tus propios patrones con `aprende que ...`; intentaré recuperarlos cuando pidas algo parecido.", None, None,
        )
    _, titulo, expl, py, js = pl
    nota = ""
    if lang == "javascript" and js is None:
        lang, nota = "python", "\n\n> Para este ejemplo solo tengo versión en Python."
    cod = js if lang == "javascript" else py
    md = f"### {titulo}\n{expl}\n\n```{'js' if lang == 'javascript' else 'python'}\n{cod}\n```{nota}"
    return md, cod, lang


def extraer(texto):
    """Saca código de un bloque ``` ``` o devuelve el texto sin más."""
    m = re.search(r"```(?:\w+)?\n?(.*?)```", texto, re.S)
    return (m.group(1) if m else texto).strip("\n")


def ejecutar(codigo, lang="python", limite=10):
    """Ejecuta el código en un proceso aparte con tiempo límite. Devuelve (salida, ok)."""
    if lang == "javascript":
        node = shutil.which("node")
        if not node:
            return "No tengo Node.js instalado para ejecutar JavaScript.", False
        orden, sufijo = [node], ".js"
    else:
        orden, sufijo = [sys.executable, "-I"], ".py"
    with tempfile.TemporaryDirectory() as d:
        ruta = f"{d}/programa{sufijo}"
        with open(ruta, "w", encoding="utf-8") as f:
            f.write(codigo)
        try:
            r = subprocess.run(orden + [ruta], capture_output=True, text=True, timeout=limite, cwd=d,
                               stdin=subprocess.DEVNULL, encoding="utf-8", errors="replace")
        except subprocess.TimeoutExpired:
            return f"⏱️ El programa tardó más de {limite} s y lo he detenido.", False
    salida = (r.stdout + (("\n" + r.stderr) if r.stderr else "")).strip()
    if len(salida) > 4000:
        salida = salida[:4000] + "\n… (salida recortada)"
    return salida or "(sin salida)", r.returncode == 0
