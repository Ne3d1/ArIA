"""Investigación web local de ArIA.

No utiliza modelos generativos remotos. Busca con DuckDuckGo/Wikipedia, valida
URLs, descarga páginas públicas y extrae texto/metadata para la memoria local.
"""
from __future__ import annotations

import ipaddress
import re
import socket
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup

UA = {"User-Agent": "Mozilla/5.0 (compatible; ArIA-Research/1.5; +local-assistant)"}
TIMEOUT = (5, 12)
MAX_BYTES = 2_500_000
MAX_REDIRECTS = 5
MAX_PAGE_CHARS = 14000


class ErrorWeb(Exception):
    """Error de búsqueda, conexión o extracción web."""


def validar_url(url: str) -> bool:
    """Permite HTTP(S) público; rechaza destinos locales, privados y puertos raros."""
    try:
        p = urlparse(url)
        if p.scheme not in ("http", "https") or not p.hostname or p.username or p.password:
            return False
        if p.port not in (None, 80, 443):
            return False
        host = p.hostname.rstrip(".").lower()
        if host in {"localhost", "localhost.localdomain"} or host.endswith((".localhost", ".local", ".internal", ".test")):
            return False
        # Direcciones IP literales: nunca acceder a redes privadas o reservadas.
        try:
            ip = ipaddress.ip_address(host)
            return ip.is_global
        except ValueError:
            pass
        # Fallar de forma cerrada si DNS no resuelve o devuelve alguna IP no pública.
        infos = socket.getaddrinfo(host, p.port or (443 if p.scheme == "https" else 80), type=socket.SOCK_STREAM)
        ips = {ipaddress.ip_address(info[4][0].split("%")[0]) for info in infos}
        return bool(ips) and all(ip.is_global for ip in ips)
    except (OSError, ValueError):
        return False


def _url_canonica(url: str) -> str:
    p = urlparse(url)
    host = (p.hostname or "").lower()
    netloc = host
    if p.port and not ((p.scheme == "http" and p.port == 80) or (p.scheme == "https" and p.port == 443)):
        netloc += f":{p.port}"
    path = re.sub(r"/{2,}", "/", p.path or "/")
    query = "&".join(x for x in p.query.split("&") if not x.lower().startswith(("utm_", "fbclid=", "gclid=")))
    return urlunparse((p.scheme.lower(), netloc, path.rstrip("/") or "/", "", query, ""))


def _get_publico(url: str):
    """GET con redirecciones manuales para volver a validar cada destino."""
    actual = url
    for _ in range(MAX_REDIRECTS + 1):
        if not validar_url(actual):
            raise ErrorWeb("La dirección no es pública o no es segura; se ha bloqueado.")
        r = requests.get(actual, headers=UA, timeout=TIMEOUT, stream=True, allow_redirects=False)
        if r.is_redirect or r.is_permanent_redirect:
            destino = urljoin(actual, r.headers.get("location", ""))
            r.close()
            actual = destino
            continue
        r.raise_for_status()
        return r, actual
    raise ErrorWeb("Demasiadas redirecciones.")


def wikipedia(consulta, lang="es", n=3):
    url = f"https://{lang}.wikipedia.org/w/api.php"
    r = requests.get(url, params={
        "action": "query", "format": "json", "generator": "search",
        "gsrsearch": consulta, "gsrlimit": n, "prop": "extracts|info",
        "exintro": 1, "explaintext": 1, "inprop": "url", "exlimit": n, "redirects": 1,
    }, headers=UA, timeout=TIMEOUT)
    r.raise_for_status()
    paginas = r.json().get("query", {}).get("pages", {})
    salida = []
    for p in sorted(paginas.values(), key=lambda x: x.get("index", 999)):
        texto = (p.get("extract") or "").strip()
        if len(texto) > 80:
            salida.append({"titulo": p.get("title", "Wikipedia"), "url": p.get("fullurl") or
                           f"https://{lang}.wikipedia.org/wiki/{quote(p['title'].replace(' ', '_'))}",
                           "texto": texto, "tipo": "wikipedia", "idioma": lang})
    return salida


def duckduckgo(consulta, n=8):
    """Busca usando la biblioteca ddgs y, si no está disponible, HTML público."""
    try:
        try:
            from ddgs import DDGS
        except ImportError:
            from duckduckgo_search import DDGS
        resultados = DDGS().text(consulta, region="es-es", max_results=n)
        salida = [{"titulo": x.get("title", ""), "url": x.get("href", ""),
                   "resumen": x.get("body", ""), "tipo": "web"}
                  for x in resultados or [] if x.get("href")]
        if salida:
            return salida
    except Exception:
        pass
    r = requests.post("https://html.duckduckgo.com/html/", data={"q": consulta}, headers=UA, timeout=TIMEOUT)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    salida = []
    for a in soup.select("a.result__a")[:n]:
        href = a.get("href", "")
        if "uddg=" in href:
            href = unquote(parse_qs(urlparse(href).query).get("uddg", [""])[0])
        elif href.startswith("//"):
            href = "https:" + href
        cuerpo = a.find_parent(class_="result")
        nodo = cuerpo.select_one(".result__snippet") if cuerpo else None
        resumen = nodo.get_text(" ", strip=True) if nodo else ""
        if href.startswith(("http://", "https://")):
            salida.append({"titulo": a.get_text(" ", strip=True), "url": href,
                           "resumen": resumen, "tipo": "web"})
    return salida


def _extraer_pdf(datos: bytes) -> str:
    try:
        from io import BytesIO
        from pypdf import PdfReader
        lector = PdfReader(BytesIO(datos), strict=False)
        return "\n\n".join((p.extract_text() or "") for p in lector.pages[:80])
    except Exception:
        return ""


def leer_pagina(url, max_chars=MAX_PAGE_CHARS):
    """Descarga una página pública (HTML/PDF) y devuelve título y texto limpio."""
    r, final_url = _get_publico(url)
    try:
        tipo = (r.headers.get("content-type") or "").lower()
        datos = r.raw.read(MAX_BYTES + 1, decode_content=True)
        if len(datos) > MAX_BYTES:
            datos = datos[:MAX_BYTES]
        if "pdf" in tipo or final_url.lower().split("?", 1)[0].endswith(".pdf"):
            texto = _extraer_pdf(datos)
            titulo = urlparse(final_url).path.rsplit("/", 1)[-1] or "Documento PDF"
            return titulo, re.sub(r"\s+", " ", texto)[:max_chars]
        if "html" not in tipo and "text/plain" not in tipo and not tipo.startswith("text/"):
            raise ErrorWeb("El resultado no es HTML, PDF ni texto legible.")
        soup = BeautifulSoup(datos, "html.parser")
        for nodo in soup(["script", "style", "nav", "footer", "header", "aside", "form", "noscript", "svg", "iframe"]):
            nodo.decompose()
        for nodo in soup.select(".advertisement, .ads, .cookie, .cookies, .menu, .navigation, .breadcrumb, [aria-hidden=true]"):
            nodo.decompose()
        titulo = soup.title.get_text(" ", strip=True) if soup.title else final_url
        principal = soup.find("article") or soup.find("main") or soup.body or soup
        bloques = principal.find_all(["h1", "h2", "h3", "p", "li", "blockquote"])
        lineas = []
        for bloque in bloques:
            txt = re.sub(r"\s+", " ", bloque.get_text(" ", strip=True))
            if len(txt) >= 45 and txt not in lineas:
                lineas.append(txt)
        texto = "\n\n".join(lineas)
        if not texto and "text/plain" in tipo:
            texto = datos.decode(r.encoding or "utf-8", errors="replace")
        texto = re.sub(r"\[\d{1,3}\]", "", texto)
        return titulo, texto[:max_chars]
    finally:
        r.close()


def _consultas_relacionadas(consulta: str):
    """Variantes deterministas; no se usa ningún modelo remoto."""
    q = consulta.strip()
    variantes = [q]
    if len(q.split()) <= 8:
        variantes.append(f"{q} explicación características funcionamiento")
    else:
        variantes.append(f"{q} fuentes documentación")
    # Quitar variantes duplicadas sin ampliar indiscriminadamente el tema.
    return list(dict.fromkeys(v for v in variantes if v))[:2]


def buscar(consulta, paginas=4):
    """Investiga varias consultas y devuelve fuentes limpias y deduplicadas.

    Cada fuente: titulo, url, texto, tipo e idioma. Nunca descarga más de
    `paginas` páginas completas; mantiene resúmenes del buscador como respaldo.
    """
    consulta = (consulta or "").strip()
    if not consulta:
        raise ErrorWeb("Escribe qué quieres investigar.")
    paginas = max(1, min(8, int(paginas)))
    resultados, errores = [], []
    consultas = _consultas_relacionadas(consulta)
    with ThreadPoolExecutor(max_workers=4) as pool:
        tareas = []
        for q in consultas:
            tareas.append(("ddg", q, pool.submit(duckduckgo, q, 8)))
        tareas.append(("wiki", consulta, pool.submit(wikipedia, consulta, "es", 3)))
        tareas.append(("wiki_en", consulta, pool.submit(wikipedia, consulta, "en", 2)))
        for tipo, q, tarea in tareas:
            try:
                for item in tarea.result():
                    item.setdefault("tipo", tipo)
                    item.setdefault("consulta", q)
                    resultados.append(item)
            except Exception as exc:
                errores.append(str(exc))
    unicos, vistos = [], set()
    for item in resultados:
        url = item.get("url", "")
        if not validar_url(url):
            continue
        clave = _url_canonica(url)
        if clave in vistos:
            continue
        vistos.add(clave)
        item["url"] = clave
        unicos.append(item)
    if not unicos:
        detalle = " Comprueba la conexión o inténtalo más tarde."
        raise ErrorWeb("Los buscadores no han devuelto resultados utilizables." + detalle)

    # Prioriza páginas con resumen y fuentes de referencia; limita lecturas.
    elegidas = unicos[:max(paginas * 2, paginas)]
    fuentes = []
    with ThreadPoolExecutor(max_workers=min(4, paginas)) as pool:
        tareas = [(item, pool.submit(leer_pagina, item["url"])) for item in elegidas[:paginas]]
        for item, tarea in tareas:
            titulo, texto = item.get("titulo", ""), ""
            try:
                titulo_leido, texto = tarea.result()
                titulo = titulo or titulo_leido
            except Exception:
                pass
            texto = texto if len(texto) >= 100 else item.get("resumen", "")
            if len(texto.strip()) < 40:
                continue
            fuentes.append({"titulo": titulo or item["url"], "url": item["url"], "texto": texto,
                            "tipo": item.get("tipo", "web"), "idioma": item.get("idioma", ""),
                            "consulta": item.get("consulta", consulta)})
    # Si una página bloquea lectura, aún se conservan snippets de resultados válidos.
    if len(fuentes) < min(2, len(unicos)):
        for item in unicos[paginas:paginas + 3]:
            resumen = item.get("resumen", "")
            if len(resumen) >= 60:
                fuentes.append({"titulo": item.get("titulo", item["url"]), "url": item["url"],
                                "texto": resumen, "tipo": item.get("tipo", "web"),
                                "idioma": "", "consulta": item.get("consulta", consulta)})
    # Una misma fuente nunca aparece dos veces.
    finales, vistos = [], set()
    for f in fuentes:
        if f["url"] not in vistos:
            vistos.add(f["url"])
            finales.append(f)
    if not finales:
        raise ErrorWeb("He encontrado enlaces, pero no he podido extraer contenido legible.")
    return finales[:paginas + 3]
