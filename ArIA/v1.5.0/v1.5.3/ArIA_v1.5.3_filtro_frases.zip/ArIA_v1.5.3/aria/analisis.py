"""Análisis textual local, explicable y basado en reglas; no usa modelos externos."""
import re
from collections import Counter

from .memoria import tokens

_MARCADORES = {
    "causa": r"\b(porque|debido a|ya que|puesto que|a causa de|por culpa de)\b",
    "consecuencia": r"\b(por tanto|por consiguiente|por eso|por ello|en consecuencia|de modo que)\b",
    "contraste": r"\b(sin embargo|no obstante|aunque|pero|en cambio|por el contrario|mientras que)\b",
    "ejemplo": r"\b(por ejemplo|como muestra|tal como|un caso es)\b",
    "secuencia": r"\b(primero|en primer lugar|despues|a continuacion|luego|finalmente|por ultimo)\b",
    "definicion": r"\b(se define como|significa|consiste en|se trata de|es un|es una|son los|son las)\b",
    "recomendacion": r"\b(deberia|deberian|conviene|se recomienda|es necesario|es importante)\b",
    "incertidumbre": r"\b(quizas|quiza|tal vez|posiblemente|probablemente|parece que|podria)\b",
    "opinion": r"\b(creo que|pienso que|en mi opinion|considero que|me parece que)\b",
}


def _frases(texto):
    return [x.strip() for x in re.split(r"(?<=[.!?])\s+|\n+", texto) if len(x.strip()) >= 18]


def _extraer(frases, patron):
    rx = re.compile(patron, re.I)
    return [f for f in frases if rx.search(f)]


def _terminos_clave(frases, limite=8):
    frecuencia = Counter(t for f in frases for t in tokens(f))
    return [t for t, _ in frecuencia.most_common(limite) if len(t) > 3]


def _entidades_aparentes(texto):
    # Heurística ortográfica, no reconocimiento neuronal de entidades.
    candidatas = re.findall(r"(?<![.!?]\s)(?<!^)(?<!\n)\b[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}){0,2}", texto)
    salida, vistas = [], set()
    for x in candidatas:
        clave = x.casefold()
        if clave not in vistas and x not in {"El", "La", "Los", "Las", "Un", "Una", "Este", "Esta", "Por"}:
            vistas.add(clave)
            salida.append(x)
    return salida[:8]


def analizar_texto(texto, max_frases=4):
    texto = (texto or "").strip()
    if not texto:
        return "No hay texto suficiente para analizar."
    frases = _frases(texto)
    if not frases:
        return "El texto es demasiado corto para extraer conclusiones fiables."

    frecuencias = Counter(t for f in frases for t in tokens(f))

    def puntuacion(frase, indice):
        ts = tokens(frase)
        centralidad = sum(frecuencias[t] for t in ts) / (len(ts) ** 0.65 or 1)
        posicion = 0.12 if indice == 0 else (0.06 if indice == len(frases) - 1 else 0)
        marcadores = ("porque", "debido", "por tanto", "por eso", "sin embargo", "por ejemplo", "en cambio", "conclusion", "finalmente")
        refuerzo = 0.18 if any(m in frase.lower() for m in marcadores) else 0
        return centralidad + posicion + refuerzo

    elegidas = sorted(enumerate(frases), key=lambda x: puntuacion(x[1], x[0]), reverse=True)[:max_frases]
    resumen = [f for _, f in sorted(elegidas)]
    cifras = [f for f in frases if re.search(r"\d", f)]
    secciones = {k: _extraer(frases, p) for k, p in _MARCADORES.items()}
    conclusiones = _extraer(frases, r"\b(en conclusion|por tanto|por consiguiente|en resumen|finalmente|se concluye que)\b")
    entidades = _entidades_aparentes(texto)
    terminos = _terminos_clave(frases)
    palabras_total = len(re.findall(r"\b\w+\b", texto))
    palabras_unicas = len(set(tokens(texto)))

    salida = ["## Análisis del texto", "**1. Idea principal (resumen extractivo):**", " ".join(resumen)]
    salida += ["", f"**2. Estructura:** {len(frases)} frases detectadas, aproximadamente {palabras_total} palabras y {palabras_unicas} términos distintos."]
    if terminos:
        salida += ["", "**3. Conceptos más repetidos:** " + ", ".join(f"`{x}`" for x in terminos)]
    if entidades:
        salida += ["", "**4. Nombres propios o entidades posibles:** " + ", ".join(entidades)]

    etiquetas = [
        ("definicion", "Definiciones"), ("causa", "Razones, causas o explicaciones"),
        ("consecuencia", "Consecuencias"), ("contraste", "Contrastes o excepciones"),
        ("secuencia", "Pasos u orden temporal"), ("ejemplo", "Ejemplos"),
        ("recomendacion", "Recomendaciones o propuestas"),
    ]
    numero = 5
    for clave, titulo in etiquetas:
        filas = secciones[clave]
        if filas:
            salida += ["", f"**{numero}. {titulo}:**"] + [f"- {f}" for f in filas[:4]]
            numero += 1
    if cifras:
        salida += ["", f"**{numero}. Datos y cifras mencionados:**"] + [f"- {f}" for f in cifras[:6]]
        numero += 1
    if conclusiones:
        salida += ["", f"**{numero}. Conclusiones expresadas:**"] + [f"- {f}" for f in conclusiones[:4]]
        numero += 1
    if secciones["incertidumbre"] or secciones["opinion"]:
        salida += ["", f"**{numero}. Afirmaciones que requieren cautela:**"]
        salida += [f"- {f}" for f in (secciones["incertidumbre"] + secciones["opinion"])[:4]]
        numero += 1
    salida += ["", "**Lectura crítica:**"]
    if not any(secciones.values()):
        salida.append("No he encontrado conectores claros de causa, contraste o conclusión. El resumen describe el texto, pero no demuestra que sus afirmaciones sean verdaderas.")
    else:
        salida.append("He separado los conectores y afirmaciones que aparecen explícitamente. Una relación causal escrita en el texto no demuestra por sí sola que la causa sea correcta; habría que contrastar las fuentes y los datos.")
    return "\n".join(salida)
