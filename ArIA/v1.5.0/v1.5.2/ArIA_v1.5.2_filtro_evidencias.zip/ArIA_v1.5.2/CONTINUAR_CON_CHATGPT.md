# Continuidad del proyecto — ArIA v1.5.2

## Estado de esta versión

La v1.5.2 parte de v1.5.1 y corrige la selección de evidencias web. El título de una página participa en su puntuación para distinguir una explicación directa de una mención incidental. La investigación web no debe generar un resumen de emergencia con fragmentos arbitrarios si el constructor no encuentra evidencias relacionadas. Las páginas de baja pertinencia no se incorporan a la memoria.

## Pruebas

`python -m unittest discover -q` ejecutado en el paquete: 64 pruebas superadas. También deben ejecutarse `./test.sh` en Linux y `test.bat` en Windows tras instalar dependencias. No se ha validado aquí una búsqueda real en Internet; los tests de integración web usan respuestas simuladas.

## Próximo trabajo

1. Evaluar búsquedas reales con un conjunto de consultas en español y catalán.
2. Extraer afirmaciones atómicas y vincularlas a pasajes concretos de cada URL.
3. Contrastar afirmaciones entre dominios independientes y detectar contradicciones.
4. Guardar conocimiento estructurado con fecha, fuente, fragmento, idioma y estado de verificación.
5. No usar porcentajes de similitud como probabilidad de verdad.

Mantener las reglas del proyecto: funcionamiento local, sin APIs de modelos generativos externos; memoria/RAG no equivale a entrenamiento neuronal; conservar identidad de ArIA y pruebas de regresión; no afirmar pruebas no realizadas.
