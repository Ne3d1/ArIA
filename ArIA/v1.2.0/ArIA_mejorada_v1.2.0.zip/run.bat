@echo off
REM Ejecuta ArIA en Windows. Admite --cli y --datos CARPETA.
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
if not exist ".venv\Scripts\python.exe" goto :setup
".venv\Scripts\python.exe" -c "import requests,bs4,ddgs,sympy,pypdf,docx,mss,PIL,pytesseract,psutil,pygetwindow,rapidfuzz,torch" 2>nul
if errorlevel 1 goto :setup
goto :run

:setup
echo Preparando o reparando el entorno ...
call setup.bat
if errorlevel 1 exit /b 1

:run
if "%~1"=="--cli" (
  ".venv\Scripts\python.exe" main.py %*
) else (
  start "" ".venv\Scripts\pythonw.exe" main.py %*
)
