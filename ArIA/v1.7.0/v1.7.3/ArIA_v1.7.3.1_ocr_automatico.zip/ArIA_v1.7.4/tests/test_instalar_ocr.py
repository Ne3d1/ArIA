import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from aria import instalar_ocr


class InstalacionAutomaticaOCR(unittest.TestCase):
    def test_descarga_solo_los_idiomas_ausentes(self):
        with tempfile.TemporaryDirectory() as tmp:
            tessdata = Path(tmp)
            llamadas = []

            def fake_download(codigo, destino, timeout=90):
                llamadas.append(codigo)
                destino.write_bytes(b"x" * 100_001)

            estados = [set(), {"spa", "eng"}]
            with patch.object(instalar_ocr, "buscar_tesseract", return_value="tesseract.exe"), \
                 patch.object(instalar_ocr, "directorio_tessdata", return_value=tessdata), \
                 patch.object(instalar_ocr, "directorio_tessdata_usuario", return_value=tessdata), \
                 patch.object(instalar_ocr, "idiomas_instalados", side_effect=estados), \
                 patch.object(instalar_ocr, "descargar_modelo", side_effect=fake_download):
                ok, mensaje = instalar_ocr.reparar_ocr()
            self.assertTrue(ok, mensaje)
            self.assertEqual(llamadas, ["spa", "eng"])
            self.assertTrue((tessdata / "spa.traineddata").is_file())
            self.assertTrue((tessdata / "eng.traineddata").is_file())

    def test_no_descarga_si_ambos_idiomas_estan(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "spa.traineddata").write_bytes(b"spa")
            (root / "eng.traineddata").write_bytes(b"eng")
            with patch.object(instalar_ocr, "buscar_tesseract", return_value="tesseract.exe"), \
                 patch.object(instalar_ocr, "directorio_tessdata", return_value=root), \
                 patch.object(instalar_ocr, "directorio_tessdata_usuario", return_value=root), \
                 patch.object(instalar_ocr, "idiomas_instalados", return_value={"spa", "eng"}), \
                 patch.object(instalar_ocr, "descargar_modelo") as descarga:
                ok, _ = instalar_ocr.reparar_ocr()
            self.assertTrue(ok)
            descarga.assert_not_called()

    def test_detecta_directorio_tessdata_desde_list_langs(self):
        with tempfile.TemporaryDirectory() as tmp:
            salida = f'List of available languages in "{tmp}/" (2):\neng\nspa\n'
            class Resultado:
                returncode = 0
                stdout = salida
                stderr = ""
            with patch("aria.instalar_ocr.subprocess.run", return_value=Resultado()):
                self.assertEqual(instalar_ocr.directorio_tessdata("tesseract"), Path(tmp))

    def test_sin_tesseract_da_instruccion_util(self):
        with patch.object(instalar_ocr, "buscar_tesseract", return_value=None):
            ok, mensaje = instalar_ocr.reparar_ocr()
        self.assertFalse(ok)
        self.assertIn("setup.bat", mensaje)

    def test_descarga_rechaza_archivo_demasiado_pequeno(self):
        with tempfile.TemporaryDirectory() as tmp:
            destino = Path(tmp) / "spa.traineddata"
            with patch("aria.instalar_ocr.urllib.request.urlopen") as abrir:
                class Respuesta:
                    def __enter__(self): return self
                    def __exit__(self, *args): pass
                    def read(self): return b"short"
                abrir.return_value = Respuesta()
                with self.assertRaises(RuntimeError):
                    instalar_ocr.descargar_modelo("spa", destino)
            self.assertFalse(destino.exists())


if __name__ == "__main__":
    unittest.main()
