# Células y seres vivos

## Definición
La célula es la unidad estructural y funcional básica de los seres vivos. Existen organismos unicelulares y pluricelulares, y las células presentan estructuras comunes y especializadas.

## Método de trabajo
Relaciona membrana, citoplasma y material genético con sus funciones. En células eucariotas, estudia núcleo y orgánulos; en procariotas, la organización sin núcleo rodeado por membrana.

## Ejemplo explicado
Las células vegetales suelen tener pared celular, cloroplastos y una gran vacuola central; las animales no presentan cloroplastos.

## Errores y límites
No todas las células de un organismo realizan la misma función. La especialización celular permite formar tejidos y órganos.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de células y seres vivos?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
