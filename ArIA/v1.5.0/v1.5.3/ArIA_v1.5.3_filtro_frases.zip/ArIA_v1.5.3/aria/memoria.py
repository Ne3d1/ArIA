"""Memoria de ArIA: aprende textos y pares pregunta/respuesta y los recupera con BM25."""
import hashlib
import math
import re
import sqlite3
import threading
import time
import unicodedata
from collections import Counter
from difflib import SequenceMatcher

try:
    from rapidfuzz import fuzz
except ImportError:  # fallback sin dependencias opcionales
    fuzz = None

from . import config
from .generador import GeneradorLocal
from .transformer_local import TransformerLocal

PARADA = set(
    """el la los las un una unos unas de del al a en y o u que se su sus por con para como es son
    ser esta este esto estas estos ese esa eso lo le les me mi mis tu tus te nos si no mas pero ya
    muy sobre entre hay fue ha han he era eran cual cuales quien quienes cuando donde cuanto cuantos
    dime explica explicame sabes puedes podrias hablame cuentame the of and to in is are for on with
    it that this i you what who how els amb per com""".split()
)

_PALABRA = re.compile(r"[a-z0-9]+")


def normalizar(texto):
    """Minúsculas y sin tildes (la ñ pasa a n)."""
    texto = unicodedata.normalize("NFD", texto.lower())
    return "".join(c for c in texto if unicodedata.category(c) != "Mn")


def tokens(texto, quitar_parada=True):
    salida = []
    for w in _PALABRA.findall(normalizar(texto)):
        if quitar_parada and w in PARADA:
            continue
        if len(w) > 5 and w.endswith("es"):
            w = w[:-2]
        elif len(w) > 3 and w.endswith("s"):
            w = w[:-1]
        salida.append(w)
    return salida


def trocear(texto, max_len=700):
    """Parte un texto largo en trozos de unos 700 caracteres."""
    texto = re.sub(r"[ \t]+", " ", texto.replace("\r", ""))
    parrafos = [p.strip() for p in re.split(r"\n\s*\n", texto) if p.strip()]
    trozos, actual = [], ""
    for p in parrafos:
        frases = [p] if len(p) <= max_len else re.split(r"(?<=[.!?])\s+", p)
        for f in frases:
            while len(f) > max_len * 1.5:
                corte = f.rfind(" ", 0, max_len)
                corte = corte if corte > 0 else max_len
                pieza, f = f[:corte], f[corte:].strip()
                if actual:
                    trozos.append(actual)
                    actual = ""
                trozos.append(pieza)
            if len(actual) + len(f) + 1 <= max_len:
                actual = (actual + " " + f).strip()
            else:
                if actual:
                    trozos.append(actual)
                actual = f
    if actual:
        trozos.append(actual)
    return trozos


def resumir(consulta, textos, n=4):
    """Resumen extractivo: las frases de los textos que mejor responden a la consulta."""
    qt = set(tokens(consulta))
    candidatas = []
    for ti, t in enumerate(textos):
        for pos, f in enumerate(re.split(r"(?<=[.!?])\s+|\n+", t)):
            f = f.strip()
            if not 25 <= len(f) <= 400:
                continue
            solape = len(qt & set(tokens(f))) / (len(qt) or 1)
            bono = max(0.0, 0.2 - 0.02 * pos) if ti == 0 else 0.0
            candidatas.append((solape + bono, ti, pos, f))
    if not candidatas:
        return ""
    elegidas = [c for c in sorted(candidatas, key=lambda c: -c[0])[:n] if c[0] > 0]
    vistas, finales = set(), []
    for c in sorted(elegidas, key=lambda c: (c[1], c[2])):
        if c[3] not in vistas:
            vistas.add(c[3])
            finales.append(c[3])
    return " ".join(finales)


def resumen_general(texto, n=5):
    """Resumen extractivo sin consulta: las frases con las palabras más frecuentes."""
    frases = [f.strip() for f in re.split(r"(?<=[.!?])\s+|\n+", texto) if 30 <= len(f.strip()) <= 400]
    if not frases:
        return texto[:600].strip()
    frec = Counter(t for f in frases for t in tokens(f))
    def puntos(f):
        tk = tokens(f)
        return sum(frec[t] for t in tk) / (len(tk) ** 0.6 or 1)
    top = sorted(range(len(frases)), key=lambda i: -puntos(frases[i]))[:n]
    return " ".join(frases[i] for i in sorted(top))


class Memoria:
    K1 = 1.5
    B = 0.75

    def __init__(self, ruta=None):
        config.DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.bd = sqlite3.connect(str(ruta or config.DB_FILE), check_same_thread=False)
        self.cerrojo = threading.RLock()
        with self.cerrojo:
            self.bd.executescript(
                """
                CREATE TABLE IF NOT EXISTS trozos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, hash TEXT UNIQUE,
                    fuente TEXT, titulo TEXT, texto TEXT, creado REAL);
                CREATE TABLE IF NOT EXISTS qa (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, pregunta TEXT,
                    respuesta TEXT, puntos INTEGER DEFAULT 0, creado REAL);
                CREATE TABLE IF NOT EXISTS reglas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, clave TEXT UNIQUE,
                    nombre TEXT, explicacion TEXT, ejemplo TEXT, creado REAL);
                CREATE TABLE IF NOT EXISTS reglas_logicas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    antecedente TEXT NOT NULL, consecuente TEXT NOT NULL,
                    explicacion TEXT DEFAULT '', creado REAL,
                    UNIQUE(antecedente, consecuente));
                CREATE TABLE IF NOT EXISTS hechos_reglas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sujeto TEXT NOT NULL, predicado TEXT NOT NULL,
                    fuente TEXT DEFAULT 'usuario', creado REAL,
                    UNIQUE(sujeto, predicado));
                """
            )
        self.generador = GeneradorLocal(self.bd, self.cerrojo)
        self.transformer = TransformerLocal(self.bd)
        self._reindexar()
        # Migra el conocimiento ya existente al generador local una sola vez.
        with self.cerrojo:
            pendientes = list(self.bd.execute("SELECT id, texto FROM trozos"))
        self.generador.aprender_muchos((texto, f"trozo:{id_}", False) for id_, texto in pendientes)
        with self.cerrojo:
            qa_pendientes = list(self.bd.execute("SELECT pregunta, respuesta FROM qa"))
        for pregunta, respuesta in qa_pendientes:
            clave = "qa:" + hashlib.sha1(normalizar(pregunta).encode("utf-8")).hexdigest()
            self.generador.aprender(pregunta + "\n" + respuesta, clave, reemplazar=True)

    # ---------- índice en memoria ----------
    def _reindexar(self):
        with self.cerrojo:
            self.idx, self.df, self.total = {}, Counter(), 0
            for id_, fuente, titulo, texto in self.bd.execute(
                "SELECT id, fuente, titulo, texto FROM trozos"
            ):
                self._indexar(id_, fuente, titulo, texto)
            self.qa = [
                list(f)
                for f in self.bd.execute("SELECT id, pregunta, respuesta, puntos FROM qa")
            ]

    def _indexar(self, id_, fuente, titulo, texto):
        toks = tokens((titulo or "") + " " + texto)
        tf = Counter(toks)
        n = len(toks) or 1
        self.idx[id_] = {"tf": tf, "n": n, "fuente": fuente, "titulo": titulo or "", "texto": texto}
        for t in tf:
            self.df[t] += 1
        self.total += n

    # ---------- aprender ----------
    def aprender_texto(self, texto, fuente="usuario", titulo=""):
        """Guarda un texto (troceado). Devuelve cuántos trozos nuevos se guardaron."""
        nuevos = 0
        aportes_generador = []
        with self.cerrojo:
            for t in trocear(texto):
                if len(t) < 8:
                    continue
                h = hashlib.sha1(t.encode("utf-8")).hexdigest()
                try:
                    cur = self.bd.execute(
                        "INSERT INTO trozos (hash, fuente, titulo, texto, creado) VALUES (?,?,?,?,?)",
                        (h, fuente, titulo, t, time.time()),
                    )
                except sqlite3.IntegrityError:
                    continue
                self._indexar(cur.lastrowid, fuente, titulo, t)
                aportes_generador.append((t, f"trozo:{cur.lastrowid}", False))
                nuevos += 1
            self.bd.commit()
        if aportes_generador:
            self.generador.aprender_muchos(aportes_generador)
            self.transformer.marcar_desactualizado()
        return nuevos

    def _misma_pregunta(self, a, b):
        ta, tb = set(tokens(a)), set(tokens(b))
        if ta and tb:
            return ta == tb
        return normalizar(a).strip(" ¿?") == normalizar(b).strip(" ¿?")

    def aprender_qa(self, pregunta, respuesta):
        with self.cerrojo:
            for fila in self.qa:
                if self._misma_pregunta(fila[1], pregunta):
                    self.bd.execute("UPDATE qa SET respuesta=? WHERE id=?", (respuesta, fila[0]))
                    fila[2] = respuesta
                    self.bd.commit()
                    clave = "qa:" + hashlib.sha1(normalizar(pregunta).encode("utf-8")).hexdigest()
                    self.generador.aprender(pregunta + "\n" + respuesta, clave, reemplazar=True)
                    self.transformer.marcar_desactualizado()
                    return
            cur = self.bd.execute(
                "INSERT INTO qa (pregunta, respuesta, puntos, creado) VALUES (?,?,0,?)",
                (pregunta, respuesta, time.time()),
            )
            self.qa.append([cur.lastrowid, pregunta, respuesta, 0])
            self.bd.commit()
            clave = "qa:" + hashlib.sha1(normalizar(pregunta).encode("utf-8")).hexdigest()
            self.generador.aprender(pregunta + "\n" + respuesta, clave, reemplazar=True)
            self.transformer.marcar_desactualizado()

    def aprender_regla(self, clave, nombre, explicacion, ejemplo=""):
        """Guarda una regla conceptual reutilizable, no solo el ejemplo literal."""
        with self.cerrojo:
            self.bd.execute(
                "INSERT INTO reglas (clave, nombre, explicacion, ejemplo, creado) VALUES (?,?,?,?,?) "
                "ON CONFLICT(clave) DO UPDATE SET nombre=excluded.nombre, "
                "explicacion=excluded.explicacion, ejemplo=excluded.ejemplo, creado=excluded.creado",
                (clave, nombre, explicacion, ejemplo, time.time()),
            )
            self.bd.commit()

    def reglas_aprendidas(self):
        with self.cerrojo:
            return [dict(clave=f[0], nombre=f[1], explicacion=f[2], ejemplo=f[3])
                    for f in self.bd.execute(
                        "SELECT clave, nombre, explicacion, ejemplo FROM reglas ORDER BY creado DESC"
                    )]

    def aprender_regla_logica(self, antecedente, consecuente, explicacion=""):
        """Guarda una implicación reutilizable: si se cumple A, se puede inferir B."""
        antecedente, consecuente = normalizar(antecedente).strip(), normalizar(consecuente).strip()
        if not antecedente or not consecuente or antecedente == consecuente:
            return False
        with self.cerrojo:
            self.bd.execute(
                "INSERT OR IGNORE INTO reglas_logicas (antecedente, consecuente, explicacion, creado) VALUES (?,?,?,?)",
                (antecedente, consecuente, explicacion, time.time()))
            self.bd.commit()
        return True

    def aprender_hecho(self, sujeto, predicado, fuente="usuario"):
        sujeto, predicado = normalizar(sujeto).strip(), normalizar(predicado).strip()
        if not sujeto or not predicado:
            return False
        with self.cerrojo:
            self.bd.execute(
                "INSERT OR IGNORE INTO hechos_reglas (sujeto, predicado, fuente, creado) VALUES (?,?,?,?)",
                (sujeto, predicado, fuente, time.time()))
            self.bd.commit()
        return True

    def inferir_hecho(self, sujeto, predicado):
        """Cierre transitivo de reglas lógicas sobre los hechos conocidos."""
        sujeto, objetivo = normalizar(sujeto).strip(), normalizar(predicado).strip()
        with self.cerrojo:
            hechos = {p for s, p in self.bd.execute("SELECT sujeto, predicado FROM hechos_reglas") if s == sujeto}
            reglas = list(self.bd.execute("SELECT antecedente, consecuente FROM reglas_logicas"))
        vistos, cola = set(hechos), list(hechos)
        while cola:
            actual = cola.pop(0)
            if actual == objetivo:
                return True
            for a, c in reglas:
                if a == actual and c not in vistos:
                    vistos.add(c)
                    cola.append(c)
        return objetivo in vistos

    def reglas_logicas(self):
        with self.cerrojo:
            return [{"antecedente": a, "consecuente": c, "explicacion": e}
                    for a, c, e in self.bd.execute(
                        "SELECT antecedente, consecuente, explicacion FROM reglas_logicas ORDER BY creado DESC")]

    # ---------- recordar ----------
    def _qa_parecida(self, consulta, minimo=0.6):
        qt = set(tokens(consulta))
        if not qt:
            return None
        mejor, mejor_s = None, 0.0
        for fila in self.qa:
            pt = set(tokens(fila[1]))
            if not pt or fila[3] <= -2:
                continue
            jaccard = len(qt & pt) / len(qt | pt)
            if fuzz:
                parecido = fuzz.token_set_ratio(normalizar(consulta), normalizar(fila[1])) / 100
                sim = max(jaccard, parecido * 0.85) + 0.05 * fila[3]
            else:
                parecido = SequenceMatcher(None, normalizar(consulta), normalizar(fila[1])).ratio()
                sim = max(jaccard, parecido * 0.8) + 0.05 * fila[3]
            if sim >= minimo and sim > mejor_s:
                mejor, mejor_s = fila, sim
        return mejor

    def mejor_qa(self, consulta):
        with self.cerrojo:
            fila = self._qa_parecida(consulta)
        return {"pregunta": fila[1], "respuesta": fila[2]} if fila else None

    def valorar(self, pregunta, delta):
        with self.cerrojo:
            fila = self._qa_parecida(pregunta)
            if fila:
                fila[3] += delta
                self.bd.execute("UPDATE qa SET puntos=? WHERE id=?", (fila[3], fila[0]))
                self.bd.commit()

    def buscar(self, consulta, k=4):
        """BM25. Devuelve [{texto, fuente, titulo, puntos, cobertura}] ordenado por relevancia."""
        q = set(tokens(consulta))
        with self.cerrojo:
            if not q or not self.idx:
                return []
            N = len(self.idx)
            media = (self.total / N) or 1
            res = []
            for id_, d in self.idx.items():
                puntos, aciertos = 0.0, 0
                for t in q:
                    f = d["tf"].get(t)
                    if not f:
                        continue
                    aciertos += 1
                    df = self.df[t]
                    idf = math.log(1 + (N - df + 0.5) / (df + 0.5))
                    puntos += idf * f * (self.K1 + 1) / (f + self.K1 * (1 - self.B + self.B * d["n"] / media))
                if aciertos:
                    if d["fuente"].startswith("usuario"):
                        puntos *= 1.3
                    cob = aciertos / len(q)
                    res.append((puntos * (0.4 + cob), puntos, cob, id_))
            res.sort(reverse=True)
            return [
                {
                    "texto": self.idx[i]["texto"],
                    "fuente": self.idx[i]["fuente"],
                    "titulo": self.idx[i]["titulo"],
                    "puntos": round(p, 2),
                    "cobertura": cob,
                }
                for _, p, cob, i in res[:k]
            ]

    # ---------- gestión ----------
    def estadisticas(self):
        with self.cerrojo:
            datos = {"trozos": len(self.idx), "qa": len(self.qa)}
        datos["generador"] = self.generador.estadisticas()
        return datos

    def fuentes(self, limite=10):
        with self.cerrojo:
            return self.bd.execute(
                "SELECT fuente, COUNT(*) FROM trozos GROUP BY fuente ORDER BY MAX(creado) DESC LIMIT ?",
                (limite,),
            ).fetchall()

    def olvidar(self, fuente=None):
        """Borra todo (fuente=None) o los trozos cuya fuente contenga el texto dado."""
        with self.cerrojo:
            if fuente is None:
                n = self.bd.execute("DELETE FROM trozos").rowcount
                self.bd.execute("DELETE FROM qa")
                self.bd.execute("DELETE FROM reglas")
                self.bd.execute("DELETE FROM reglas_logicas")
                self.bd.execute("DELETE FROM hechos_reglas")
            else:
                n = self.bd.execute(
                    "DELETE FROM trozos WHERE fuente LIKE ?", (f"%{fuente}%",)
                ).rowcount
            self.bd.commit()
            self._reindexar()
            documentos = [(f"trozo:{i}", txt) for i, txt in self.bd.execute("SELECT id, texto FROM trozos")]
            documentos += [("qa:" + hashlib.sha1(normalizar(p).encode("utf-8")).hexdigest(), p + "\n" + r)
                           for p, r in self.bd.execute("SELECT pregunta, respuesta FROM qa")]
            self.generador.reconstruir(documentos)
            self.transformer.invalidar()
        return n
