# ArIA 🤖

Asistente de chat local en español, con ventana sencilla (Tkinter), mensajes en **Markdown**, memoria que
aprende, búsqueda en internet, matemáticas, programación básica y acceso a archivos con permiso.

## Instalación y arranque

| | Linux / macOS | Windows |
|---|---|---|
| **Montar el proyecto** (una vez) | `./setup.sh` | doble clic en `setup.bat` |
| **Ejecutar** | `./run.sh` | doble clic en `run.bat` |
| **Ejecutar pruebas** | `./test.sh` | doble clic en `test.bat` |

- Necesitas **Python 3.9+**. `setup.bat` / `setup.sh` instala todas las dependencias declaradas en `requirements.txt`, verifica los módulos y comprueba conflictos con `pip check`. `run.bat` y `run.sh` también detectan un entorno incompleto y reparan la instalación automáticamente. Si falta Tesseract OCR, el instalador pregunta si quieres instalarlo (winget en Windows; apt/dnf/pacman/brew en sistemas compatibles). Si no puede instalarlo o faltan idiomas, ArIA sigue funcionando; solo queda desactivado el OCR de pantalla. Se comprueban español (`spa`) e inglés (`eng`).
- El generador estadístico usa Python estándar y SQLite. Para entrenar el GPT pequeño desde cero se instala **PyTorch** (`torch`); el paquete es un framework de cálculo, no un modelo. ArIA no descarga pesos ni checkpoints preentrenados.
- En Linux, la ventana necesita Tkinter: `sudo apt install python3-tk` (Fedora: `python3-tkinter`, Arch: `tk`).
- Modo texto (sin ventana): `./run.sh --cli` / `run.bat --cli`. Otra carpeta de datos: `--datos RUTA`.

## Qué sabe hacer

| Área | Ejemplos |
|---|---|
| **Aprender** | `Aprender` o `/aprender` para ver ejemplos · `aprende que mi gato se llama Mou` · `cuando te pregunte X, responde Y` · `aprende que si algo es mamífero, entonces es vertebrado` · `aprende que un perro es mamífero` · guarda patrones de programación · 👍/👎 |
| **Internet** | `busca en internet qué es la fotosíntesis` · `dame el enlace de la web oficial de Python`. Solo busca cuando se lo pides expresamente; guarda resultados y cita fuentes |
| **Matemáticas** | `quanto es 2 por 4` · `me puedes calcular 3 por 7` · `haz la cuenta de 12 entre 3` · `50 más 30` · `2+3*4` · `calcula sqrt(81)` · `15% de 200` · `5!` · `resuelve x^2-5x+6=0` · `deriva x^3` · `integra sin(x)` · aprende y aplica la propiedad distributiva |
| **Programación** | `escribe un programa de fibonacci en python` · `escribe fizzbuzz y ejecútalo` · `ejecuta` + bloque ```` ``` ```` |
| **Pantalla y programas** | Botón `🪟 Programas` para consultar nombres de procesos/ventanas con permiso · `👁 Analizar pantalla` para capturar el monitor principal y extraer texto con OCR local; muestra una vista previa y pide confirmación antes del análisis. No guarda capturas ni OCR automáticamente. |
| **Generación local** | `/generar una historia sobre ...` · `inventa una historia sobre ...` · `/modelo` para consultar el entrenamiento |
| **Análisis** | `analiza este texto: ...` · `analiza el archivo ruta` (con permiso) · extrae ideas centrales, cifras, razones y conclusiones expresadas |
| **Archivos** | `lee el archivo ruta` · `resume el archivo ruta` · `aprende del archivo ruta` · `aprende de la carpeta ruta` · `lista la carpeta ruta` · botones 📎 y 📁 |
| **Comandos** | `/ayuda` · `/aprender` · `/memoria` · `/reglas` · `/fuentes` · `/perfil` · `/personas` · `/olvidar` · `/olvidar texto` |

Lee `.txt .md .py .json .csv .html … .pdf .docx`.

## Recuerda quién eres (perfil)

ArIA guarda en `data/memoria.db` un perfil por persona y lo recuerda entre sesiones (castellano y catalán):

| Qué | Ejemplos |
|---|---|
| **Con quién habla** | `me llamo Ana` · `em dic Pau` · `soy Marta` (cambia de persona) · `quién soy` · `a quién conoces` |
| **Gustos** | `me gusta el té y las motos` · `no me gusta el frío` · `qué me gusta` · `ya no me gusta el té` |
| **Datos** | `vivo en Girona` · `tengo 25 años` · `trabajo de…` · `mi cumpleaños es…` · `mi gato se llama Mou` · `mi color favorito es el verde` |
| **Preferencias** | `sé más breve` / `sé más detallado` (cambia la longitud de mis respuestas) · `respóndeme en catalán` (se guarda como preferencia; las respuestas integradas se adaptan cuando hay traducción local) |
| **Consultar / borrar** | `qué sabes de mí` · `cuál es mi color favorito` · `/perfil` · `/personas` · `olvida mi gato` · `olvídame` |

Cada persona tiene su propio perfil. Al abrir ArIA recuerda la última persona y te lo avisa; si eres otra, di `soy …`.
`/olvidar` borra el conocimiento aprendido, pero **no** los perfiles (para eso, `olvídame`).

## Memoria intocable 🔒

ArIA tiene una memoria nuclear que **no se puede borrar, cambiar ni encontrar en internet**: su creadora es
**Aria Català**, su ayudante es **Claude**, y sobre su creadora: *amante de los gatos, programadora y una mica idiota*.
Pregúntale `quién te creó`, `quién es tu ayudante` o `háblame de tu creadora`.

- Vive en el código (`aria/nucleo.py`), no en la base de datos: `/olvidar`, `olvídame` o borrar `data/` no la tocan.
- Se responde antes de consultar la memoria aprendida o internet, así que nada que lea puede contradecirla.
- Cualquier intento de cambiarla desde el chat (`tu creador es …`, `aprende que te creó …`) se rechaza.
- Hay una copia de solo lectura en `aria/identidad.md` que se restaura sola si falta o se modifica.

## Cómo "aprende"

ArIA mantiene una **memoria propia** en SQLite (`data/memoria.db`) con búsqueda por relevancia (BM25). Todo lo que le enseñas, lee de archivos o encuentra en internet se guarda en fragmentos y se recupera al preguntar; las respuestas informativas se construyen combinando esas evidencias mediante un motor local de composición y razonamiento. Los pares pregunta→respuesta que le enseñas o que valoras con 👍 tienen prioridad. No inicia búsquedas web automáticamente: primero consulta la memoria y solo consulta internet ante una orden explícita.

### Generación de texto local

ArIA incluye ahora `aria/generador.py`, un **modelo estadístico de lenguaje de n-gramas con backoff** (trigramas, bigramas y unigramas), muestreo por temperatura, penalización de repeticiones y entrenamiento incremental. Aprende transiciones lingüísticas de los textos que incorporas con `aprende que ...`, `aprende del archivo ...` y `aprende de la carpeta ...`, además de ejemplos pregunta→respuesta. El entrenamiento se guarda en SQLite y persiste entre sesiones.

- `/generar una historia sobre dragones` o `inventa una historia sobre dragones`: busca fragmentos relacionados y crea una continuación estadística a partir de ellos.
- `/modelo`: muestra documentos, tokens, transiciones y el estado del GPT.
- `/entrenar-modelo` o `/entrenar-modelo 500`: entrena desde cero un pequeño GPT de caracteres con PyTorch. El valor indica pasos de optimización; empieza con 100 y aumenta si tienes un corpus grande y paciencia.
- `/olvidar`: borra las transiciones aprendidas y el checkpoint GPT; al olvidar una fuente concreta, reconstruye el modelo estadístico con lo que queda y elimina el GPT para que no conserve datos olvidados.

El GPT es una **red neuronal causal tipo Transformer** (4 bloques, 6 cabezas de atención y dimensión 192), con embeddings, atención causal multi-cabeza y bloques MLP. Su vocabulario de caracteres y todos sus pesos se inicializan aleatoriamente y se entrenan con la memoria local. No es un modelo preentrenado: con corpus pequeño y pocas iteraciones generará texto imperfecto; necesita muchos textos variados y entrenamiento sostenido para mejorar. El instalador selecciona la compilación CPU de PyTorch en Windows/Linux para no descargar bibliotecas CUDA. Al incorporar nuevos textos, el GPT se marca como desactualizado y ArIA vuelve al n-grama hasta que lo reentrenes. El generador estadístico n-grama queda como respaldo si aún no hay un GPT actualizado. Ambos pueden repetir frases, mezclar contextos o cometer errores; por eso se limitan a peticiones creativas explícitas y marcan sus textos como no verificados. Las preguntas factuales siguen usando recuperación de evidencias y razonamiento, no texto estadístico como si fueran hechos.

### Aprendizaje de reglas matemáticas

Además de guardar ejemplos literales, ArIA reconoce algunos patrones matemáticos. Por ejemplo, al enseñarle
`aprende que (2+2)*5=20`, detecta que el ejemplo demuestra la **propiedad distributiva**, guarda la regla en
SQLite y puede aplicarla a cálculos nuevos como `(3+4)*6` o `8*(10-3)`, mostrando el desarrollo. Consulta lo
aprendido con `/reglas`. Este aprendizaje de reglas es explícito y ampliable: no significa que ArIA pueda deducir
automáticamente cualquier ley a partir de cualquier frase o ejemplo. También puede encadenar reglas lógicas
que le enseñes (por ejemplo, mamífero → vertebrado → animal) sobre hechos concretos guardados en su memoria.

La interpretación del lenguaje combina normalización de tildes, expansión local de sinónimos, tolerancia a errores de escritura y similitud difusa (RapidFuzz). Las respuestas que le enseñas se pueden recuperar aunque cambies la redacción. El motor `razonamiento.py` identifica si preguntas por definiciones, causas, procesos, comparaciones, ventajas, desventajas o ejemplos; descompone algunas preguntas compuestas, busca evidencias para cada parte, elimina repeticiones y redacta una respuesta estructurada. También puede mantener el tema en preguntas de seguimiento como «¿y por qué?» o «ponme ejemplos».

La composición informativa selecciona y reorganiza evidencias, combina varias frases, adapta la introducción al tipo de pregunta y estima cuánto encajan las fuentes con la consulta. Esa cifra es una medida heurística, no una garantía de verdad. El módulo `analisis.py` separa definiciones, razones, consecuencias, contrastes, secuencias, recomendaciones, cifras, conclusiones y expresiones de incertidumbre u opinión. La memoria prioriza lo que enseña el usuario y puede reutilizar reglas lógicas encadenadas y patrones de programación guardados.

**Límite importante:** el generador estadístico local no tiene la comprensión ni la fluidez de un LLM moderno. No voy a añadir modelos externos ni disfrazar el n-grama como una red neuronal. La forma de mejorarlo sin IA externa es alimentarlo con un corpus amplio, limpio, variado y con permisos de uso adecuados, y evaluar sus resultados con pruebas.

**Modelos externos prohibidos por diseño:** ArIA no ofrece campos para Ollama, OpenAI ni otros proveedores. Las configuraciones antiguas se eliminan al cargar Ajustes y el módulo de compatibilidad rechaza cualquier intento de conexión. El razonamiento, la recuperación de memoria, los resúmenes y el análisis OCR se realizan localmente. La búsqueda web solo se activa cuando se solicita expresamente y no es una llamada a un modelo de IA.

**Contenido adulto (+18):** no he encontrado en el código un filtro general que bloquee conversaciones por mencionar sexo, desnudez o temas adultos; no se añade ninguno. El GPT local es pequeño y se entrena desde cero con el corpus disponible; no tiene la amplitud ni la comprensión de un LLM moderno y no garantiza una generación libre y coherente de cualquier petición. Las protecciones de archivos y permisos son independientes del contenido adulto.

## Análisis de pantalla y privacidad

- La consulta de programas/ventanas y cada captura requieren permiso explícito.
- La captura se procesa en memoria; ArIA no guarda la imagen. El OCR se muestra para revisión antes de analizarlo.
- El OCR y su análisis se realizan localmente. ArIA no envía texto ni imágenes a modelos externos.
- La función no controla el ratón ni el teclado, no hace clic y no modifica programas.

## Privacidad y seguridad

- Nunca lee archivos fuera de las carpetas permitidas sin preguntarte (*Denegar / Solo esta vez / Permitir siempre*).
- Se niega a leer archivos que parecen sensibles (`.env`, claves SSH, contraseñas…).
- Ejecutar código **siempre pide confirmación**, tiene límite de 10 s y se puede desactivar en ⚙ Ajustes.
- Los datos (memoria, chats `.md`, ajustes) están en `data/`. Bórrala para empezar de cero.

## Estructura

```
main.py            punto de entrada
aria/cerebro.py    decide cómo responder
aria/memoria.py    memoria y aprendizaje (SQLite + BM25 + similitud difusa)
aria/analisis.py   análisis textual estructurado y explicable local
aria/razonamiento.py motor de intención, recuperación y composición de respuestas
aria/generador.py  modelo estadístico local de lenguaje (n-gramas) y generación
aria/transformer_local.py GPT causal pequeño entrenado desde cero con PyTorch
aria/web.py        Wikipedia, DuckDuckGo y lectura de páginas
aria/mate.py       aritmética segura + álgebra (sympy)
aria/codigo.py     plantillas de código y ejecución
aria/archivos.py   lectura de archivos con permisos
aria/llm.py        bloqueo de compatibilidad (modelos externos desactivados)
aria/gui.py        ventana Tkinter + render Markdown + permisos de pantalla
aria/pantalla.py   consulta de procesos/ventanas y OCR local
```
