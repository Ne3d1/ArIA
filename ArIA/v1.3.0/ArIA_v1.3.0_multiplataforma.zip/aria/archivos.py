"""Acceso a archivos del PC (siempre con permiso) y extracción de texto."""
import itertools
import os
import re
from pathlib import Path

EXT_TEXTO = {
    ".txt", ".md", ".rst", ".py", ".js", ".ts", ".json", ".csv", ".tsv", ".html", ".htm", ".css",
    ".java", ".c", ".h", ".cpp", ".cs", ".go", ".rs", ".php", ".sql", ".log", ".yaml", ".yml",
    ".xml", ".ini", ".toml", ".cfg", ".sh", ".bat", ".ps1", ".tex",
}
EXT_SOPORTADAS = EXT_TEXTO | {".pdf", ".docx"}
MAX_BYTES = 30 * 1024 * 1024
IGNORAR_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__", ".idea", ".vscode", "site-packages"}
SENSIBLES = re.compile(
    r"(^\.env|id_rsa|id_ed25519|\.pem$|\.key$|\.pfx$|\.kdbx$|\.p12$|password|contrase|credential|secret|"
    r"\.ssh$|\.aws$|cookies|wallet)",
    re.I,
)


class ErrorArchivo(Exception):
    pass


def es_sensible(ruta):
    p = Path(ruta)
    return any(SENSIBLES.search(parte) for parte in (p.name, *[x.name for x in p.parents][:4]))


def resolver(texto, extra=()):
    """Convierte lo que escribió el usuario en una ruta existente (o None)."""
    texto = texto.strip().strip("\"'“”`").strip()
    if not texto:
        return None
    p = Path(os.path.expanduser(texto))
    if p.is_absolute() or texto.startswith("~"):
        return p.resolve() if p.exists() else None
    h = Path.home()
    bases = [Path.cwd(), h, h / "Documents", h / "Documentos", h / "Desktop", h / "Escritorio",
             h / "Downloads", h / "Descargas", *[Path(c) for c in extra]]
    for b in bases:
        if (b / p).exists():
            return (b / p).resolve()
    for b in map(Path, extra):
        if b.is_dir():
            for f in itertools.islice(b.rglob(p.name), 1):
                return f.resolve()
    return None


def esta_permitido(ruta, carpetas):
    ruta = Path(ruta).resolve()
    for c in carpetas:
        c = Path(c).resolve()
        if ruta == c or c in ruta.parents:
            return True
    return False


def leer(ruta):
    """Devuelve el texto de un archivo (txt, código, pdf, docx...)."""
    p = Path(ruta)
    if not p.is_file():
        raise ErrorArchivo("No es un archivo.")
    if p.stat().st_size > MAX_BYTES:
        raise ErrorArchivo("El archivo es demasiado grande (máx. 30 MB).")
    ext = p.suffix.lower()
    if ext == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError:
            raise ErrorArchivo("Para leer PDF necesito `pypdf` (pip install pypdf).")
        try:
            lector = PdfReader(str(p))
            return "\n\n".join((pg.extract_text() or "") for pg in lector.pages[:300])
        except Exception as e:
            raise ErrorArchivo(f"No pude leer el PDF: {e}")
    if ext == ".docx":
        try:
            import docx
        except ImportError:
            raise ErrorArchivo("Para leer Word necesito `python-docx` (pip install python-docx).")
        try:
            d = docx.Document(str(p))
            partes = [x.text for x in d.paragraphs]
            for tabla in d.tables:
                for fila in tabla.rows:
                    partes.append(" | ".join(c.text for c in fila.cells))
            return "\n".join(partes)
        except Exception as e:
            raise ErrorArchivo(f"No pude leer el documento: {e}")
    datos = p.read_bytes()
    if b"\x00" in datos[:4096]:
        raise ErrorArchivo("Parece un archivo binario; no sé leerlo.")
    for cod in ("utf-8-sig", "utf-16", "latin-1"):
        try:
            return datos.decode(cod)
        except UnicodeError:
            continue
    return datos.decode("utf-8", errors="replace")


def listar(carpeta, maximo=60):
    carpeta = Path(carpeta)
    filas = []
    for e in sorted(carpeta.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
        if e.name.startswith(".") or es_sensible(e):
            continue
        filas.append(f"📁 {e.name}/" if e.is_dir() else f"📄 {e.name} ({e.stat().st_size // 1024 + 1} KB)")
        if len(filas) >= maximo:
            filas.append("…")
            break
    return filas


def archivos_de_carpeta(carpeta, maximo=300):
    """Archivos de texto/pdf/docx dentro de una carpeta (recursivo)."""
    salida = []
    for raiz, dirs, ficheros in os.walk(carpeta):
        dirs[:] = [d for d in dirs if d not in IGNORAR_DIRS and not d.startswith(".")]
        for f in sorted(ficheros):
            p = Path(raiz) / f
            if p.suffix.lower() in EXT_SOPORTADAS and not es_sensible(p):
                salida.append(p)
                if len(salida) >= maximo:
                    return salida
    return salida
