# Código mantenible

El código mantenible utiliza nombres descriptivos, funciones pequeñas, módulos con responsabilidades claras, validación de entradas y errores explícitos.

Evita duplicar lógica. Escribe pruebas para comportamientos esperados y casos límite. Documenta decisiones no obvias, no cada línea. Separa configuración de código y no almacenes secretos en el repositorio.

Al cambiar una función, revisa sus usos y ejecuta pruebas de regresión. Un programa que funciona una vez no está necesariamente probado.
