# Aritmética y orden de operaciones

## Definición
Las operaciones aritméticas incluyen suma, resta, multiplicación, división, potencias y raíces. El orden convencional evita interpretaciones distintas de una misma expresión.

## Método de trabajo
Resuelve primero paréntesis; después potencias y raíces; luego multiplicaciones y divisiones de izquierda a derecha; finalmente sumas y restas de izquierda a derecha.

## Ejemplo explicado
En 3 + 4 × 2, primero 4 × 2 = 8 y después 3 + 8 = 11. Si hay paréntesis en (3 + 4) × 2, el resultado es 14.

## Errores y límites
No confundas −3² con (−3)². La primera expresión suele interpretarse como −(3²) = −9; la segunda vale 9.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de aritmética y orden de operaciones?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
