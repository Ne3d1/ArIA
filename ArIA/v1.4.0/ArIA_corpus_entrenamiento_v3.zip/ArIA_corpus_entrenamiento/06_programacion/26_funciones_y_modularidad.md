# Funciones y modularidad

## Definición
Una función agrupa una operación con nombre, parámetros y un resultado opcional. La modularidad permite dividir programas en piezas comprensibles y comprobables.

## Método de trabajo
Define una responsabilidad clara; usa parámetros explícitos; devuelve resultados; evita efectos secundarios innecesarios; documenta supuestos; prueba casos límite.

## Ejemplo explicado
Una función convertir_celsius_a_fahrenheit recibe una temperatura y devuelve c * 9 / 5 + 32.

## Errores y límites
Una función demasiado larga o con muchas responsabilidades es difícil de probar. No ocultes dependencias importantes en variables globales.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de funciones y modularidad?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
