# Falacias frecuentes

## Definición
Una falacia es un patrón de argumentación que parece apoyar una conclusión, pero no lo hace adecuadamente. Reconocerla ayuda a evaluar argumentos sin atacar a quien los presenta.

## Método de trabajo
Busca ataques personales, falsas dicotomías, generalizaciones apresuradas, apelaciones irrelevantes a autoridad, falsas causas y argumentos circulares. Reformula la tesis y pregunta qué evidencia la apoya.

## Ejemplo explicado
«No escuches su propuesta porque es joven» ataca a la persona en vez de evaluar la propuesta. «O aceptas todo o estás en contra» plantea una falsa dicotomía.

## Errores y límites
No llames falacia a cualquier desacuerdo. Explica qué paso lógico falla y qué evidencia sería pertinente.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de falacias frecuentes?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
