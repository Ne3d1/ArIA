# Aprendizaje espaciado

## Definición
El aprendizaje espaciado distribuye repasos en el tiempo. Recuperar una idea de memoria y corregir errores suele ser más útil que releer pasivamente muchas veces.

## Método de trabajo
Estudia un bloque breve; intenta explicarlo sin mirar; comprueba; anota errores; vuelve a practicar más adelante y mezcla temas relacionados.

## Ejemplo explicado
Después de aprender vocabulario, intenta recordar su significado al día siguiente y unos días después.

## Errores y límites
La repetición mecánica sin recuperación activa puede dar una falsa sensación de dominio.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de aprendizaje espaciado?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
