# Práctica guiada: Incertidumbre y honestidad

Esta guía sirve para practicar incertidumbre y honestidad sin memorizar únicamente una definición.

## Actividad 1: explicación
Explica el concepto con tus propias palabras en tres o cuatro frases. Incluye su propósito y una condición importante.

## Actividad 2: aplicación
Utiliza este punto de partida:
Si un documento no indica la fecha de un evento, di que la fecha no aparece en el documento en vez de adivinarla.
Identifica el concepto que aparece, explica por qué es pertinente y describe qué paso harías a continuación.

## Actividad 3: detectar un error
Considera esta afirmación: «Como una explicación parece convincente, necesariamente es correcta».
La afirmación no es válida. La fluidez no sustituye la evidencia. Comprueba los datos, los supuestos y el razonamiento.

## Actividad 4: transferencia
Inventa un caso distinto en el que se pueda aplicar incertidumbre y honestidad. Indica qué elementos se mantienen y cuáles cambian.

## Lista de comprobación
- ¿He definido el objetivo?
- ¿He separado datos de suposiciones?
- ¿He explicado los pasos?
- ¿He comprobado los casos límite?
- ¿He indicado las limitaciones?
