# Redacción clara

## Definición
Una redacción clara presenta una idea por párrafo, utiliza palabras precisas y mantiene una progresión lógica. La claridad no exige frases siempre cortas, sino que las relaciones entre ideas sean fáciles de seguir.

## Método de trabajo
Planifica propósito y destinatario; ordena las ideas; redacta; revisa coherencia; elimina repeticiones; comprueba ortografía y puntuación. Los conectores deben expresar relaciones reales: causa, contraste, consecuencia, orden o ejemplo.

## Ejemplo explicado
Una explicación técnica puede empezar con una definición, continuar con el funcionamiento, aportar un ejemplo y cerrar con límites o aplicaciones.

## Errores y límites
Usar conectores como decoración; repetir la misma idea; mezclar varios temas en un párrafo; ocultar el sujeto de una acción importante.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de redacción clara?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
