# Connectors en català

## Definición
Els connectors relacionen idees i indiquen ordre, causa, conseqüència, contrast, condició o exemplificació.

## Método de trabajo
Per ordenar: primer, després, finalment. Per causa: perquè, ja que. Per conseqüència: per tant, així doncs. Per contrast: tanmateix, en canvi, però.

## Ejemplo explicado
«La bateria és lleugera; tanmateix, té poca capacitat». El connector marca un contrast entre dues propietats.

## Errores y límites
No utilitzis connectors sense comprovar la relació lògica entre les frases.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de connectors en català?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
