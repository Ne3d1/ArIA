# Sistemas operativos

## Definición
Un sistema operativo administra recursos del equipo y ofrece servicios a las aplicaciones. Gestiona procesos, memoria, archivos, dispositivos, usuarios y permisos.

## Método de trabajo
Distingue núcleo, procesos, servicios, sistema de archivos e interfaz. Comprende que las aplicaciones solicitan recursos mediante interfaces del sistema operativo.

## Ejemplo explicado
Al abrir un navegador, el sistema crea un proceso, asigna memoria, abre archivos y utiliza la red mediante controladores y servicios.

## Errores y límites
Un proceso no es lo mismo que un programa almacenado. Los permisos y el aislamiento reducen errores y riesgos de seguridad.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de sistemas operativos?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
