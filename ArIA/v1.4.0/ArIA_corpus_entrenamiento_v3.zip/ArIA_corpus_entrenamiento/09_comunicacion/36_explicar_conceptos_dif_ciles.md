# Explicar conceptos difíciles

## Definición
Una buena explicación parte de lo conocido y añade complejidad gradualmente. Las analogías ayudan, pero deben señalarse sus límites.

## Método de trabajo
Define el concepto; explica sus partes; muestra un ejemplo; compara con algo familiar; indica dónde falla la analogía; termina con una comprobación.

## Ejemplo explicado
La memoria RAM puede compararse con una mesa de trabajo: facilita acceso temporal, pero no es un almacén permanente.

## Errores y límites
Una analogía no es una definición exacta. No atribuyas al sistema propiedades que solo pertenecen a la comparación.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de explicar conceptos difíciles?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
