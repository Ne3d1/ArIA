"""Búsqueda en internet: Wikipedia + DuckDuckGo + lectura de páginas."""
import ipaddress
import re
import socket
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import parse_qs, quote, unquote, urlparse

import requests
from bs4 import BeautifulSoup

UA = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) ArIA/1.0"}
TIMEOUT = 10


class ErrorWeb(Exception):
    pass


def _seguro(url):
    """Solo http(s) y nunca hacia la red local."""
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        return False
    try:
        for info in socket.getaddrinfo(p.hostname, None):
            ip = ipaddress.ip_address(info[4][0].split("%")[0])
            if ip.is_private or ip.is_loopback or ip.is_link_local:
                return False
    except (OSError, ValueError):
        pass
    return True


def wikipedia(consulta, lang="es", n=2):
    r = requests.get(
        f"https://{lang}.wikipedia.org/w/api.php",
        params={
            "action": "query", "format": "json", "generator": "search",
            "gsrsearch": consulta, "gsrlimit": n, "prop": "extracts",
            "exintro": 1, "explaintext": 1, "exlimit": n, "redirects": 1,
        },
        headers=UA, timeout=TIMEOUT,
    )
    r.raise_for_status()
    paginas = r.json().get("query", {}).get("pages", {})
    salida = []
    for p in sorted(paginas.values(), key=lambda p: p.get("index", 99)):
        texto = (p.get("extract") or "").strip()
        if len(texto) > 40:
            titulo = p["title"]
            url = f"https://{lang}.wikipedia.org/wiki/{quote(titulo.replace(' ', '_'))}"
            salida.append({"titulo": f"{titulo} (Wikipedia)", "url": url, "texto": texto})
    return salida


def duckduckgo(consulta, n=6):
    try:
        try:
            from ddgs import DDGS
        except ImportError:
            from duckduckgo_search import DDGS
        res = DDGS().text(consulta, region="es-es", max_results=n)
        out = [
            {"titulo": r.get("title", ""), "url": r.get("href", ""), "resumen": r.get("body", "")}
            for r in res or []
            if r.get("href")
        ]
        if out:
            return out
    except ImportError:
        pass
    except Exception:
        pass
    # Plan B: versión HTML de DuckDuckGo
    r = requests.post("https://html.duckduckgo.com/html/", data={"q": consulta}, headers=UA, timeout=TIMEOUT)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    out = []
    for a in soup.select("a.result__a")[:n]:
        href = a.get("href", "")
        if "uddg=" in href:
            href = unquote(parse_qs(urlparse(href).query).get("uddg", [""])[0])
        elif href.startswith("//"):
            href = "https:" + href
        cuerpo = a.find_parent(class_="result")
        resumen = cuerpo.select_one(".result__snippet").get_text(" ", strip=True) if cuerpo and cuerpo.select_one(".result__snippet") else ""
        if href.startswith("http"):
            out.append({"titulo": a.get_text(" ", strip=True), "url": href, "resumen": resumen})
    return out


def leer_pagina(url, max_chars=6000):
    """Descarga una página y devuelve (título, texto limpio)."""
    if not _seguro(url):
        raise ErrorWeb("Dirección no permitida.")
    r = requests.get(url, headers=UA, timeout=TIMEOUT, stream=True)
    r.raise_for_status()
    tipo = r.headers.get("content-type", "")
    if "html" not in tipo and "text" not in tipo:
        raise ErrorWeb("No es una página de texto.")
    contenido = r.raw.read(1_500_000, decode_content=True)
    soup = BeautifulSoup(contenido, "html.parser", from_encoding=r.encoding)
    for t in soup(["script", "style", "nav", "footer", "header", "aside", "form", "noscript", "svg"]):
        t.decompose()
    titulo = soup.title.get_text(" ", strip=True) if soup.title else url
    parrafos = [p.get_text(" ", strip=True) for p in soup.find_all(["p", "li"])]
    texto = "\n\n".join(p for p in parrafos if len(p) > 50)
    return titulo, re.sub(r"\[\d+\]", "", texto)[:max_chars]


def buscar(consulta, paginas=2):
    """Devuelve una lista de fuentes [{titulo, url, texto}]. Lanza ErrorWeb si no hay conexión."""
    errores = []
    with ThreadPoolExecutor(3) as ex:
        fw, fd = ex.submit(wikipedia, consulta), ex.submit(duckduckgo, consulta, 6)
        try:
            wiki = fw.result()
        except Exception as e:
            wiki = []
            errores.append(e)
        try:
            ddg = fd.result()
        except Exception as e:
            ddg = []
            errores.append(e)
    if not wiki and not ddg:
        if len(errores) == 2:
            raise ErrorWeb("no hay conexión o los buscadores no responden.")
        try:
            wiki = wikipedia(consulta, "en", 1)
        except Exception:
            pass
    fuentes = list(wiki[:1])
    candidatas = [r for r in ddg if "wikipedia.org" not in r["url"]]
    elegidas = candidatas[: max(0, paginas)]
    with ThreadPoolExecutor(4) as ex:
        trabajos = [(r, ex.submit(leer_pagina, r["url"])) for r in elegidas]
        for r, t in trabajos:
            try:
                titulo, texto = t.result()
            except Exception:
                titulo, texto = r["titulo"], ""
            texto = texto if len(texto) > 120 else r["resumen"]
            if texto:
                fuentes.append({"titulo": r["titulo"] or titulo, "url": r["url"], "texto": texto})
    for r in candidatas[len(elegidas): len(elegidas) + 2]:
        if r["resumen"]:
            fuentes.append({"titulo": r["titulo"], "url": r["url"], "texto": r["resumen"]})
    return fuentes
