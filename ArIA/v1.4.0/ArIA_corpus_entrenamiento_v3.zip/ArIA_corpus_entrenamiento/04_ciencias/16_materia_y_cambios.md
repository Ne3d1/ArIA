# Materia y cambios

## Definición
La materia tiene masa y ocupa espacio. Las propiedades físicas pueden observarse sin cambiar la composición; las químicas describen la capacidad de formar sustancias diferentes.

## Método de trabajo
Distingue sustancia pura y mezcla; identifica estado físico; separa cambios físicos de reacciones químicas; utiliza observaciones y medidas reproducibles.

## Ejemplo explicado
El hielo que se funde sigue siendo agua: es un cambio físico. La oxidación del hierro produce sustancias nuevas: es un cambio químico.

## Errores y límites
Un cambio de color puede sugerir una reacción, pero no la demuestra por sí solo. Considera otras evidencias.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de materia y cambios?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
