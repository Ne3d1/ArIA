# Práctica guiada: Bases de datos

Esta guía sirve para practicar bases de datos sin memorizar únicamente una definición.

## Actividad 1: explicación
Explica el concepto con tus propias palabras en tres o cuatro frases. Incluye su propósito y una condición importante.

## Actividad 2: aplicación
Utiliza este punto de partida:
Una tabla de alumnos puede tener un identificador único y una tabla de matrículas puede referenciar ese identificador.
Identifica el concepto que aparece, explica por qué es pertinente y describe qué paso harías a continuación.

## Actividad 3: detectar un error
Considera esta afirmación: «Como una explicación parece convincente, necesariamente es correcta».
La afirmación no es válida. La fluidez no sustituye la evidencia. Comprueba los datos, los supuestos y el razonamiento.

## Actividad 4: transferencia
Inventa un caso distinto en el que se pueda aplicar bases de datos. Indica qué elementos se mantienen y cuáles cambian.

## Lista de comprobación
- ¿He definido el objetivo?
- ¿He separado datos de suposiciones?
- ¿He explicado los pasos?
- ¿He comprobado los casos límite?
- ¿He indicado las limitaciones?
