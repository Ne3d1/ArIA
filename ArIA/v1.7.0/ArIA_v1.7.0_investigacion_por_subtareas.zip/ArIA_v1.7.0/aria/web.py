"""Investigación web local de ArIA.

No utiliza modelos generativos remotos. Busca con DuckDuckGo/Wikipedia, valida
URLs, descarga páginas públicas y extrae texto/metadata para la memoria local.
"""
from __future__ import annotations

import ipaddress
import re
import socket
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup

UA = {"User-Agent": "Mozilla/5.0 (compatible; ArIA-Research/1.5; +local-assistant)"}
TIMEOUT = (5, 12)
MAX_BYTES = 2_500_000
MAX_REDIRECTS = 5
MAX_PAGE_CHARS = 14000



_STOP_WEB = set("""el la los las un una unos unas de del al a en y o u que se su sus por con para como es son ser esta este esto estas ese esa eso lo le les me mi mis tu tus te nos si no mas pero ya muy sobre entre hay cual cuales quien quienes cuando donde cuanto cuantos the of and to in is are for with it that what who how""".split())
_DOMINIOS_REFERENCIA = (".gov", ".edu", "europa.eu", "ibm.com", "microsoft.com", "intel.com", "amd.com", "redhat.com", "kernel.org", "python.org", "w3.org", "nist.gov", "acm.org", "ieee.org")
_DOMINIOS_DEBILES = ("grokipedia.com",)
_RUIDO_WEB = (
    "¿quien es el lider", "quien es el lider", "en nuestra empresa",
    "entendemos que dominar", "haz clic", "suscribete", "leer mas",
    "te puede interesar", "preguntas frecuentes", "tabla de contenidos",
)

def _tokens_web(texto):
    plano = unicodedata.normalize("NFD", unquote(texto).lower())
    plano = "".join(c for c in plano if unicodedata.category(c) != "Mn")
    return {x for x in re.findall(r"[a-z0-9]{2,}", plano) if x not in _STOP_WEB}

def _calidad_texto(texto, consulta):
    """Puntuación heurística de utilidad textual; no mide veracidad."""
    limpio = re.sub(r"\s+", " ", texto or "").strip()
    if len(limpio) < 180:
        return 0.0
    tokens = _tokens_web(limpio)
    q = _tokens_web(consulta)
    cobertura = len(tokens & q) / max(1, len(q))
    frases = re.split(r"(?<=[.!?])(?=\s*[A-ZÁÉÍÓÚÜ¿¡])\s*", limpio)
    completas = sum(1 for f in frases if len(f.split()) >= 8 and f[-1:] in ".!?;")
    ruido = sum(1 for x in _RUIDO_WEB if x in limpio.lower())
    ratio_prosa = min(1.0, completas / 5)
    return 0.58 * cobertura + 0.32 * ratio_prosa + 0.10 * min(1, len(tokens) / 180) - 0.18 * ruido

def _puntuacion_fuente(fuente, consulta):
    """Valora también el título: que una página mencione el tema no basta.

    Una página institucional puede mencionar un instituto o un evento sobre el
    tema sin explicar el concepto. El título ayuda a distinguir ese caso.
    Esta puntuación mide pertinencia, nunca veracidad.
    """
    texto = fuente.get("texto", "")
    titulo = fuente.get("titulo", "")
    url = fuente.get("url", "")
    dominio = (urlparse(url).hostname or "").lower()
    q = _tokens_web(consulta)
    tt = _tokens_web(titulo)
    score = _calidad_texto(texto, consulta)
    coincidencia_titulo = len(q & tt) / max(1, len(q))
    if coincidencia_titulo >= 0.5:
        score += 0.24
    elif coincidencia_titulo == 0:
        # No descartar documentación con títulos editoriales, pero evitar que
        # una página institucional desplace a una explicación del concepto.
        score -= 0.22
    if any(dominio.endswith(x) for x in _DOMINIOS_REFERENCIA):
        score += 0.08
    if any(x in dominio for x in _DOMINIOS_DEBILES):
        score -= 0.20
    if len(texto) < 350:
        score -= 0.12
    return score

def _similares(a, b):
    ta, tb = _tokens_web(a), _tokens_web(b)
    return len(ta & tb) / max(1, len(ta | tb))


_RUIDO_EDITORIAL = (
    r"\b(?:escuche|escucha|siga a|síguenos|siguenos|suscr[ií]bete|suscr[ií]base|"
    r"spotify|apple podcasts|podcast|episodio|patrocinad[oa]|anuncio)\b",
    r"\b(?:haz clic|haga clic|leer m[aá]s|m[aá]s informaci[oó]n|compartir en)\b",
    r"\b(?:es el motor de|es la fuerza impulsora de|es de especial inter[eé]s|para entender .{0,70} es importante)\b",
)
_PATRON_COPULA_DEFINICION = re.compile(
    r"^(?:es|son)\s+(?:(?:un|una|el|la|los|las)\s+)?"
    r"(?:tipo|forma|rama|disciplina|campo|proceso|transferencia|tecnolog[ií]a|"
    r"t[eé]cnica|m[eé]todo|sistema|conjunto|m[aá]quina|memoria|herramienta|"
    r"modelo|ciencia|[a-záéíóúñ]+ci[oó]n)\b|"
    r"^(?:consiste\s+en|se\s+define\s+como|se\s+trata\s+de|"
    r"es\s+el\s+proceso\s+de|es\s+la\s+rama\s+de)\b",
    re.I,
)


def _es_definicion_directa(frase, consulta):
    """Solo acepta definiciones cuyo sujeto sea el concepto preguntado.

    Evita falsos positivos del tipo «la computación cuántica óptica es una
    propuesta...» o «X es de interés para la computación cuántica».
    """
    # Mantener el orden de la consulta, excluyendo palabras interrogativas.
    plano = unicodedata.normalize("NFD", consulta.lower())
    plano = "".join(c for c in plano if unicodedata.category(c) != "Mn")
    tema = [x for x in re.findall(r"[a-z0-9]{2,}", plano) if x not in _STOP_WEB]
    if not tema:
        return False
    f = unicodedata.normalize("NFD", frase.lower())
    f = "".join(c for c in f if unicodedata.category(c) != "Mn")
    f = re.sub(r"^[\s¿¡]*(?:el|la|los|las|un|una)\s+", "", f)
    palabras = re.findall(r"[a-z0-9]+", f)
    if palabras[:len(tema)] != tema:
        return False
    resto = " ".join(palabras[len(tema):])
    return bool(_PATRON_COPULA_DEFINICION.match(resto))


def extraer_evidencias(texto, consulta, requiere_definicion=False, max_frases=8, anclas_externas=None):
    """Extrae afirmaciones pertinentes y sus relaciones, sin reglas por tema.

    Si encuentra una definición directa, utiliza sus conceptos como ancla para
    recuperar explicaciones complementarias (por ejemplo, detalles que ya no
    repiten literalmente el nombre del tema). La puntuación no mide veracidad.
    """
    limpio = re.sub(r"\s+", " ", texto or "").strip()
    frases = re.split(r"(?<=[.!?])(?=\s*[A-ZÁÉÍÓÚÜ¿¡])\s*", limpio)
    q = _tokens_web(consulta)
    if not q:
        return [], False

    candidatas = []
    definiciones = []
    for frase in frases:
        frase = frase.strip(" \t-•")
        normal = unicodedata.normalize("NFD", frase.lower())
        normal = "".join(c for c in normal if unicodedata.category(c) != "Mn")
        if len(frase.split()) < 7 or len(frase) < 45:
            continue
        if any(re.search(p, normal, re.I) for p in _RUIDO_EDITORIAL):
            continue
        tokens = _tokens_web(frase)
        if not tokens:
            continue
        if _es_definicion_directa(frase, consulta):
            definiciones.append(frase)
        # Flexión morfológica ligera (singular/plural y género) para no perder
        # una coincidencia solo porque la fuente use «cuánticos» y la pregunta
        # «cuántica». No introduce sinónimos temáticos específicos.
        coincidentes = {qt for qt in q if qt in tokens or any(
            len(qt) >= 5 and len(tok) >= 5 and (qt[:5] == tok[:5]) for tok in tokens)}
        coincidencias = len(coincidentes)
        cobertura = coincidencias / max(1, len(q))
        candidatas.append((frase, tokens, cobertura, coincidencias))

    # Las frases directamente ligadas al tema actúan como anclas generales;
    # una frase complementaria puede añadir conceptos que conecten con otra.
    # Así se construye una pequeña red de evidencias sin reglas por disciplina.
    anclas = set(anclas_externas or ())
    for frase in definiciones:
        anclas.update(_tokens_web(frase))
    directas = [x for x in candidatas if x[2] >= (0.5 if len(q) > 1 else 1.0)]
    if not anclas:
        for _, tokens, _, _ in directas:
            anclas.update(tokens)
    seleccionadas = list(dict.fromkeys(definiciones + [x[0] for x in directas]))
    pendientes = [x for x in candidatas if x[0] not in seleccionadas]
    progreso = True
    while progreso and pendientes:
        progreso = False
        restantes = []
        for frase, tokens, cobertura, coincidencias in pendientes:
            relacionadas = len(tokens & anclas)
            if relacionadas >= 1 and len(frase.split()) >= 8:
                seleccionadas.append(frase)
                anclas.update(tokens)
                progreso = True
            else:
                restantes.append((frase, tokens, cobertura, coincidencias))
        pendientes = restantes

    elegidas = []
    for frase in seleccionadas:
        tokens = _tokens_web(frase)
        cobertura = len(tokens & q) / max(1, len(q))
        relacionadas = len(tokens & anclas)
        elegidas.append((cobertura + min(0.25, relacionadas * 0.025), frase))
    tiene_definicion = bool(definiciones)
    if requiere_definicion and not tiene_definicion:
        return [], False
    salida = []
    # La definición siempre abre; después, las frases más relacionadas con
    # sus conceptos completan el proceso, los componentes o las aplicaciones.
    ordenadas = definiciones + [f for _, f in sorted(elegidas, key=lambda x: x[0], reverse=True)]
    for frase in ordenadas:
        if frase not in salida:
            salida.append(frase)
        if len(salida) >= max_frases:
            break
    return salida, tiene_definicion


class ErrorWeb(Exception):
    """Error de búsqueda, conexión o extracción web."""


def validar_url(url: str) -> bool:
    """Permite HTTP(S) público; rechaza destinos locales, privados y puertos raros."""
    try:
        p = urlparse(url)
        if p.scheme not in ("http", "https") or not p.hostname or p.username or p.password:
            return False
        if p.port not in (None, 80, 443):
            return False
        host = p.hostname.rstrip(".").lower()
        if host in {"localhost", "localhost.localdomain"} or host.endswith((".localhost", ".local", ".internal", ".test")):
            return False
        # Direcciones IP literales: nunca acceder a redes privadas o reservadas.
        try:
            ip = ipaddress.ip_address(host)
            return ip.is_global
        except ValueError:
            pass
        # Fallar de forma cerrada si DNS no resuelve o devuelve alguna IP no pública.
        infos = socket.getaddrinfo(host, p.port or (443 if p.scheme == "https" else 80), type=socket.SOCK_STREAM)
        ips = {ipaddress.ip_address(info[4][0].split("%")[0]) for info in infos}
        return bool(ips) and all(ip.is_global for ip in ips)
    except (OSError, ValueError):
        return False


def _url_canonica(url: str) -> str:
    p = urlparse(url)
    host = (p.hostname or "").lower()
    netloc = host
    if p.port and not ((p.scheme == "http" and p.port == 80) or (p.scheme == "https" and p.port == 443)):
        netloc += f":{p.port}"
    path = re.sub(r"/{2,}", "/", p.path or "/")
    query = "&".join(x for x in p.query.split("&") if not x.lower().startswith(("utm_", "fbclid=", "gclid=")))
    return urlunparse((p.scheme.lower(), netloc, path.rstrip("/") or "/", "", query, ""))


def _get_publico(url: str):
    """GET con redirecciones manuales para volver a validar cada destino."""
    actual = url
    for _ in range(MAX_REDIRECTS + 1):
        if not validar_url(actual):
            raise ErrorWeb("La dirección no es pública o no es segura; se ha bloqueado.")
        r = requests.get(actual, headers=UA, timeout=TIMEOUT, stream=True, allow_redirects=False)
        if r.is_redirect or r.is_permanent_redirect:
            destino = urljoin(actual, r.headers.get("location", ""))
            r.close()
            actual = destino
            continue
        r.raise_for_status()
        return r, actual
    raise ErrorWeb("Demasiadas redirecciones.")


def wikipedia(consulta, lang="es", n=3):
    url = f"https://{lang}.wikipedia.org/w/api.php"
    r = requests.get(url, params={
        "action": "query", "format": "json", "generator": "search",
        "gsrsearch": consulta, "gsrlimit": n, "prop": "extracts|info",
        "exintro": 1, "explaintext": 1, "inprop": "url", "exlimit": n, "redirects": 1,
    }, headers=UA, timeout=TIMEOUT)
    r.raise_for_status()
    paginas = r.json().get("query", {}).get("pages", {})
    salida = []
    for p in sorted(paginas.values(), key=lambda x: x.get("index", 999)):
        texto = (p.get("extract") or "").strip()
        if len(texto) > 80:
            salida.append({"titulo": p.get("title", "Wikipedia"), "url": p.get("fullurl") or
                           f"https://{lang}.wikipedia.org/wiki/{quote(p['title'].replace(' ', '_'))}",
                           "texto": texto, "tipo": "wikipedia", "idioma": lang})
    return salida


def duckduckgo(consulta, n=8):
    """Busca usando la biblioteca ddgs y, si no está disponible, HTML público."""
    try:
        try:
            from ddgs import DDGS
        except ImportError:
            from duckduckgo_search import DDGS
        resultados = DDGS().text(consulta, region="es-es", max_results=n)
        salida = [{"titulo": x.get("title", ""), "url": x.get("href", ""),
                   "resumen": x.get("body", ""), "tipo": "web"}
                  for x in resultados or [] if x.get("href")]
        if salida:
            return salida
    except Exception:
        pass
    r = requests.post("https://html.duckduckgo.com/html/", data={"q": consulta}, headers=UA, timeout=TIMEOUT)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    salida = []
    for a in soup.select("a.result__a")[:n]:
        href = a.get("href", "")
        if "uddg=" in href:
            href = unquote(parse_qs(urlparse(href).query).get("uddg", [""])[0])
        elif href.startswith("//"):
            href = "https:" + href
        cuerpo = a.find_parent(class_="result")
        nodo = cuerpo.select_one(".result__snippet") if cuerpo else None
        resumen = nodo.get_text(" ", strip=True) if nodo else ""
        if href.startswith(("http://", "https://")):
            salida.append({"titulo": a.get_text(" ", strip=True), "url": href,
                           "resumen": resumen, "tipo": "web"})
    return salida


def _extraer_pdf(datos: bytes) -> str:
    try:
        from io import BytesIO
        from pypdf import PdfReader
        lector = PdfReader(BytesIO(datos), strict=False)
        return "\n\n".join((p.extract_text() or "") for p in lector.pages[:80])
    except Exception:
        return ""


def leer_pagina(url, max_chars=MAX_PAGE_CHARS):
    """Descarga una página pública (HTML/PDF) y devuelve título y texto limpio."""
    r, final_url = _get_publico(url)
    try:
        tipo = (r.headers.get("content-type") or "").lower()
        datos = r.raw.read(MAX_BYTES + 1, decode_content=True)
        if len(datos) > MAX_BYTES:
            datos = datos[:MAX_BYTES]
        if "pdf" in tipo or final_url.lower().split("?", 1)[0].endswith(".pdf"):
            texto = _extraer_pdf(datos)
            titulo = urlparse(final_url).path.rsplit("/", 1)[-1] or "Documento PDF"
            return titulo, re.sub(r"\s+", " ", texto)[:max_chars]
        if "html" not in tipo and "text/plain" not in tipo and not tipo.startswith("text/"):
            raise ErrorWeb("El resultado no es HTML, PDF ni texto legible.")
        soup = BeautifulSoup(datos, "html.parser")
        for nodo in soup(["script", "style", "nav", "footer", "header", "aside", "form", "noscript", "svg", "iframe"]):
            nodo.decompose()
        for nodo in soup.select(".advertisement, .ads, .cookie, .cookies, .menu, .navigation, .breadcrumb, [aria-hidden=true]"):
            nodo.decompose()
        titulo = soup.title.get_text(" ", strip=True) if soup.title else final_url
        principal = soup.find("article") or soup.find("main") or soup.body or soup
        bloques = principal.find_all(["h1", "h2", "h3", "p", "li", "blockquote"])
        lineas = []
        for bloque in bloques:
            txt = re.sub(r"\s+", " ", bloque.get_text(" ", strip=True))
            if len(txt) >= 45 and txt not in lineas:
                lineas.append(txt)
        texto = "\n\n".join(lineas)
        if not texto and "text/plain" in tipo:
            texto = datos.decode(r.encoding or "utf-8", errors="replace")
        texto = re.sub(r"\[\d{1,3}\]", "", texto)
        return titulo, texto[:max_chars]
    finally:
        r.close()


def _consultas_relacionadas(consulta: str):
    """Variantes deterministas; no se usa ningún modelo remoto."""
    q = consulta.strip()
    variantes = [q]
    if len(q.split()) <= 8:
        variantes.append(f"{q} explicación características funcionamiento")
    else:
        variantes.append(f"{q} fuentes documentación")
    # Quitar variantes duplicadas sin ampliar indiscriminadamente el tema.
    return list(dict.fromkeys(v for v in variantes if v))[:2]


def buscar(consulta, paginas=4):
    """Investiga varias consultas y devuelve fuentes limpias y deduplicadas.

    Cada fuente: titulo, url, texto, tipo e idioma. Nunca descarga más de
    `paginas` páginas completas; mantiene resúmenes del buscador como respaldo.
    """
    consulta = (consulta or "").strip()
    if not consulta:
        raise ErrorWeb("Escribe qué quieres investigar.")
    paginas = max(1, min(8, int(paginas)))
    resultados, errores = [], []
    consultas = _consultas_relacionadas(consulta)
    with ThreadPoolExecutor(max_workers=4) as pool:
        tareas = []
        for q in consultas:
            tareas.append(("ddg", q, pool.submit(duckduckgo, q, 8)))
        tareas.append(("wiki", consulta, pool.submit(wikipedia, consulta, "es", 3)))
        tareas.append(("wiki_en", consulta, pool.submit(wikipedia, consulta, "en", 2)))
        for tipo, q, tarea in tareas:
            try:
                for item in tarea.result():
                    item.setdefault("tipo", tipo)
                    item.setdefault("consulta", q)
                    resultados.append(item)
            except Exception as exc:
                errores.append(str(exc))
    unicos, vistos = [], set()
    for item in resultados:
        url = item.get("url", "")
        if not validar_url(url):
            continue
        clave = _url_canonica(url)
        if clave in vistos:
            continue
        vistos.add(clave)
        item["url"] = clave
        unicos.append(item)
    if not unicos:
        detalle = " Comprueba la conexión o inténtalo más tarde."
        raise ErrorWeb("Los buscadores no han devuelto resultados utilizables." + detalle)

    # Primero se leen más candidatos que el número final solicitado. Después se
    # puntúan por pertinencia, calidad textual y diversidad de dominios.
    candidatas = unicos[:max(paginas * 3, paginas)]
    fuentes = []
    limite_lectura = min(len(candidatas), max(paginas * 2, paginas))
    with ThreadPoolExecutor(max_workers=min(4, max(1, paginas))) as pool:
        tareas = [(item, pool.submit(leer_pagina, item["url"])) for item in candidatas[:limite_lectura]]
        for item, tarea in tareas:
            titulo, texto = item.get("titulo", ""), ""
            try:
                titulo_leido, texto = tarea.result()
                titulo = titulo or titulo_leido
            except Exception:
                pass
            texto = texto if len(texto) >= 180 else item.get("resumen", "")
            texto = re.sub(r"\s+", " ", texto).strip()
            if len(texto) < 100:
                continue
            fuente = {"titulo": titulo or item["url"], "url": item["url"], "texto": texto,
                      "tipo": item.get("tipo", "web"), "idioma": item.get("idioma", ""),
                      "consulta": item.get("consulta", consulta)}
            fuente["calidad"] = round(_puntuacion_fuente(fuente, consulta), 3)
            # No incorporar a la respuesta páginas que solo mencionan el tema
            # incidentalmente. Se conservan candidatos con evidencia textual.
            if fuente["calidad"] >= 0.12:
                fuentes.append(fuente)

    # Elimina copias de contenido aunque tengan URL o idioma diferentes.
    fuentes.sort(key=lambda f: (f["calidad"], len(f["texto"])), reverse=True)
    finales, dominios = [], set()
    for f in fuentes:
        if any(_similares(f["texto"], previa["texto"]) >= 0.78 for previa in finales):
            continue
        dominio = (urlparse(f["url"]).hostname or "").lower()
        # Se prefiere diversidad de dominios; se permite repetir si faltan fuentes.
        if dominio in dominios and len(finales) < paginas:
            continue
        finales.append(f)
        dominios.add(dominio)
        if len(finales) >= paginas:
            break

    # Si no hay suficientes páginas legibles, recupera snippets pertinentes.
    if len(finales) < min(2, len(unicos)):
        for item in candidatas[limite_lectura:]:
            resumen = re.sub(r"\s+", " ", item.get("resumen", "")).strip()
            if len(resumen) < 100 or _calidad_texto(resumen, consulta) < 0.10:
                continue
            fuente = {"titulo": item.get("titulo", item["url"]), "url": item["url"],
                      "texto": resumen, "tipo": item.get("tipo", "web"),
                      "idioma": item.get("idioma", ""), "consulta": item.get("consulta", consulta)}
            if any(_similares(fuente["texto"], previa["texto"]) >= 0.78 for previa in finales):
                continue
            finales.append(fuente)
            if len(finales) >= paginas:
                break
    if not finales:
        raise ErrorWeb("He encontrado enlaces, pero no he podido extraer contenido legible.")
    return finales[:paginas]
