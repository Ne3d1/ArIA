# Variables y tipos

## Definición
Una variable asocia un nombre con un valor. Los tipos describen qué operaciones tienen sentido y cómo se representan los datos.

## Método de trabajo
Elige nombres claros; distingue números, texto, booleanos y colecciones; valida entradas; convierte tipos explícitamente cuando sea necesario.

## Ejemplo explicado
En Python, edad = 18 guarda un entero; nombre = 'Ada' guarda texto; activo = True guarda un booleano.

## Errores y límites
No conviertas datos automáticamente sin comprobar errores. El texto '12' y el número 12 no son el mismo tipo.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de variables y tipos?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
