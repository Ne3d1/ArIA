# Metacognición

## Definición
La metacognición es observar y regular el propio proceso de aprendizaje. Incluye planificar, supervisar comprensión y evaluar resultados.

## Método de trabajo
Antes de empezar, identifica lo que sabes; durante la tarea, detecta dudas; al terminar, compara el resultado con el objetivo y decide el siguiente paso.

## Ejemplo explicado
Si una explicación no se entiende, cambia de ejemplo o representa el proceso con un esquema.

## Errores y límites
Confundir familiaridad con dominio es frecuente. Poder explicar o aplicar un concepto ofrece una prueba más sólida.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de metacognición?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
