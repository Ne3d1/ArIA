# Semántica y contexto

## Definición
La semántica estudia el significado. Una palabra puede tener varios sentidos y el contexto ayuda a seleccionar el adecuado. La pragmática añade la intención del hablante, la situación y lo que se presupone.

## Método de trabajo
Para interpretar una expresión, examina las palabras cercanas, el tema, el registro, el idioma y el objetivo. No elijas un significado solo porque comparta una palabra con la consulta.

## Ejemplo explicado
En «el ratón no responde», el contexto informático sugiere un dispositivo apuntador; en un texto sobre animales, puede referirse al mamífero.

## Errores y límites
Tomar expresiones figuradas literalmente; ignorar ironía; asumir que dos sinónimos son intercambiables en todos los contextos.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de semántica y contexto?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
