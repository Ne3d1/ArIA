# Unidades y conversiones

Una magnitud física se expresa mediante un valor y una unidad. Antes de operar, comprueba que las unidades sean compatibles.

Para convertir una unidad, utiliza un factor de conversión equivalente a uno. Por ejemplo, 1 km = 1000 m; por tanto, 2,5 km × 1000 m/km = 2500 m.

En velocidades, recuerda que km/h y m/s no son la misma unidad. Para pasar de km/h a m/s divide entre 3,6; para pasar de m/s a km/h multiplica por 3,6.

No sumes directamente magnitudes con unidades incompatibles. Escribe las unidades en cada paso y comprueba que se cancelen correctamente.
