import copy
import tempfile
import unittest
from unittest.mock import patch

from aria import web
from aria.cerebro import Cerebro, quiere_busqueda_web
from aria.config import DEFAULTS
from aria.memoria import Memoria


class SeguridadWeb(unittest.TestCase):
    def test_bloquea_destinos_locales_y_privados(self):
        for url in ("http://127.0.0.1/", "http://192.168.1.2/", "http://localhost/",
                    "file:///etc/passwd", "http://10.0.0.1:8080/"):
            with self.subTest(url=url):
                self.assertFalse(web.validar_url(url))

    @patch("aria.web.socket.getaddrinfo")
    def test_dominio_publico_se_permite(self, dns):
        dns.return_value = [(None, None, None, None, ("93.184.216.34", 0))]
        self.assertTrue(web.validar_url("https://example.org/path"))

    @patch("aria.web.socket.getaddrinfo")
    def test_dominio_que_resuelve_a_ip_privada_se_bloquea(self, dns):
        dns.return_value = [(None, None, None, None, ("127.0.0.1", 0))]
        self.assertFalse(web.validar_url("https://evil.example/path"))

    @patch("aria.web.requests.get")
    @patch("aria.web.validar_url", return_value=True)
    def test_redireccion_se_revalida(self, validar, get):
        import requests
        from unittest.mock import Mock
        redir = Mock()
        redir.is_redirect = True
        redir.is_permanent_redirect = False
        redir.headers = {"location": "http://127.0.0.1/secret"}
        ok = Mock()
        ok.is_redirect = False
        ok.is_permanent_redirect = False
        ok.raise_for_status.return_value = None
        get.side_effect = [redir, ok]
        validar.side_effect = [True, False]
        with self.assertRaises(web.ErrorWeb):
            web._get_publico("https://example.org")


class BusquedaWeb(unittest.TestCase):
    @patch("aria.web.leer_pagina")
    @patch("aria.web.wikipedia")
    @patch("aria.web.duckduckgo")
    @patch("aria.web.validar_url", return_value=True)
    def test_busqueda_combina_fuentes_y_deduplica(self, validar, ddg, wiki, leer):
        ddg.return_value = [
            {"titulo": "Ordenadores", "url": "https://example.org/ordenadores?utm_source=x", "resumen": "Resumen suficientemente largo sobre ordenadores y sus componentes."},
            {"titulo": "Duplicado", "url": "https://example.org/ordenadores", "resumen": "Duplicado."},
        ]
        wiki.return_value = [{"titulo": "Computadora", "url": "https://es.wikipedia.org/wiki/Computadora", "texto": "Una computadora es una máquina electrónica." * 10}]
        leer.side_effect = [("Ordenadores", "Un ordenador procesa datos y ejecuta instrucciones. " * 8),
                            ("Computadora", "Una computadora es una máquina electrónica. " * 8)]
        fuentes = web.buscar("qué es un ordenador", paginas=2)
        self.assertGreaterEqual(len(fuentes), 1)
        self.assertTrue(all(len(f["texto"]) > 40 for f in fuentes))
        self.assertEqual(len({f["url"] for f in fuentes}), len(fuentes))

    def test_calidad_penaliza_titulares_promocionales_y_premia_prosa_relevante(self):
        consulta = "computación cuántica qubits superposición"
        texto_bueno = ("La computación cuántica utiliza qubits para representar estados cuánticos. "
                       "La superposición permite combinar estados antes de medirlos. "
                       "Los algoritmos cuánticos manipulan estos estados mediante operaciones." * 3)
        texto_ruido = ("¿Quién es el líder en computación cuántica? "
                       "En nuestra empresa entendemos que dominar la computación cuántica "
                       "es una oportunidad para liderar en cualquier sector." * 3)
        self.assertGreater(web._calidad_texto(texto_bueno, consulta),
                           web._calidad_texto(texto_ruido, consulta))

    def test_titulo_de_explicacion_supera_mencion_institucional_incidental(self):
        consulta = "¿Qué es la computación cuántica?"
        institucional = {"titulo": "Universidad de Waterloo", "url": "https://example.org/uw",
                         "texto": "La universidad anunció fondos para el Instituto de Computación Cuántica. " * 12}
        explicativa = {"titulo": "¿Qué es la computación cuántica?", "url": "https://example.org/quantum",
                       "texto": ("La computación cuántica utiliza qubits para representar información. "
                                 "Los qubits pueden estar en superposición y entrelazarse. " * 12)}
        self.assertGreater(web._puntuacion_fuente(explicativa, consulta),
                           web._puntuacion_fuente(institucional, consulta))

    def test_filtra_podcast_y_frases_incidentales_de_computacion_cuantica(self):
        texto = (
            "La interferencia es el motor de la computación cuántica. "
            "Por lo tanto, la computación cuántica es de especial interés para las aplicaciones de la química y la ciencia de los materiales. "
            "Escuche: Parte 1: ¿Qué es la computación cuántica? Siga a Techsplainers en Spotify y Apple Podcasts. "
            "La principal diferencia entre los ordenadores clásicos y los ordenadores cuánticos es que los ordenadores cuánticos utilizan cúbits en lugar de bits. "
            "Para entender computación cuántica, es importante entender cuatro principios clave de la mecánica cuántica. "
            "Un cúbit en sí no es útil."
        )
        frases, definicion = web.extraer_evidencias(texto, "computación cuántica")
        self.assertFalse(definicion)
        self.assertTrue(frases)
        self.assertFalse(any("Spotify" in f or "Techsplainers" in f for f in frases))
        self.assertFalse(any("interferencia es el motor" in f for f in frases))
        self.assertFalse(any("Un cúbit en sí" in f for f in frases))

    def test_no_confunde_subtipo_con_definicion_del_concepto_general(self):
        subtipo = "La computación cuántica óptica es una propuesta experimental y teórica para desarrollar esta tecnología."
        frases, definicion = web.extraer_evidencias(
            subtipo, "computación cuántica", requiere_definicion=True)
        self.assertEqual(frases, [])
        self.assertFalse(definicion)
        incidental = "La computación cuántica es de especial interés para la química y la ciencia de materiales."
        self.assertFalse(web._es_definicion_directa(incidental, "computación cuántica"))

    def test_exige_definicion_directa_para_pregunta_que_es(self):
        ruido = "La interferencia es el motor de la computación cuántica. " * 3
        frases, definicion = web.extraer_evidencias(ruido, "computación cuántica", requiere_definicion=True)
        self.assertEqual(frases, [])
        self.assertFalse(definicion)
        buena = "La computación cuántica es un tipo de computación que utiliza cúbits para procesar información."
        frases, definicion = web.extraer_evidencias(buena, "computación cuántica", requiere_definicion=True)
        self.assertTrue(definicion)
        self.assertTrue(frases)
        ampliada, _ = web.extraer_evidencias(
            "La computación cuántica es un tipo de computación que utiliza cúbits para procesar información. "
            "Los cúbits pueden estar en superposición y entrelazarse.", "computación cuántica", True)
        self.assertTrue(any("superposición" in f for f in ampliada))

    def test_deduplicacion_de_contenido_detecta_misma_pagina_en_otro_idioma(self):
        a = "Los qubits permiten representar estados cuánticos y realizar operaciones."
        b = "Los qubits permiten representar estados cuanticos y realizar operaciones."
        self.assertGreaterEqual(web._similares(a, b), 0.78)

    def test_busqueda_rechaza_consulta_vacia(self):
        with self.assertRaises(web.ErrorWeb):
            web.buscar("  ")


class IntegracionInvestigacion(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.mem = Memoria(ruta=f"{self.tmp.name}/memoria.db")
        self.cfg = copy.deepcopy(DEFAULTS)
        self.cfg["aprender_de_internet"] = True
        self.cerebro = Cerebro(self.cfg, self.mem)

    def tearDown(self):
        self.mem.bd.close()
        self.tmp.cleanup()

    @patch("aria.cerebro.web.buscar")
    def test_investiga_guarda_contenido_y_muestra_fuentes(self, buscar):
        buscar.return_value = [{"titulo": "Fuente técnica", "url": "https://example.org/cpu",
                                "texto": "Un procesador ejecuta instrucciones y coordina operaciones del ordenador. "
                                        "La unidad de control dirige el flujo de datos y la unidad aritmético lógica "
                                        "realiza operaciones matemáticas y lógicas."}]
        r = self.cerebro.responder("investiga cómo funciona un procesador")
        self.assertEqual(r.origen, "web")
        self.assertIn("example.org/cpu", r.texto)
        self.assertIn("fragmentos seleccionados", r.texto)
        self.assertGreaterEqual(len(self.mem.buscar("procesador instrucciones", k=3)), 1)

    @patch("aria.cerebro.web.buscar")
    def test_no_acepta_articulo_de_subtipo_ni_guarda_fragmentos_sin_definicion(self, buscar):
        buscar.return_value = [
            {"titulo": "Computación cuántica óptica", "url": "https://example.org/optica",
             "texto": ("La computación cuántica óptica es una propuesta experimental y teórica "
                       "que pretende servir como base para el desarrollo de la computación cuántica. "
                       "El análisis de circuitos ópticos requiere estudiar la naturaleza cuántica de la luz. "
                       "El muestreo de bosones permite demostrar algunas ventajas cuánticas.") , "calidad": 0.8},
            {"titulo": "Román Orús", "url": "https://example.net/roman-orus",
             "texto": ("Román Orús es un físico e investigador que trabaja en información cuántica. "
                       "Ha publicado trabajos sobre simulación de sistemas cuánticos y computación cuántica. "
                       "Su investigación estudia algoritmos y aplicaciones científicas.") , "calidad": 0.8},
        ]
        r = self.cerebro.responder("busca en internet qué es la computación cuántica")
        self.assertEqual(r.origen, "nada")
        self.assertIn("no una definición suficientemente clara", r.texto)
        self.assertEqual(self.mem.buscar("computación cuántica óptica", k=10), [])

    @patch("aria.cerebro.web.buscar")
    def test_no_presenta_fragmentos_aleatorios_como_respuesta_web(self, buscar):
        buscar.return_value = [{"titulo": "Universidad", "url": "https://example.org/uni",
                                "texto": "La universidad anunció fondos para el Instituto de Computación Cuántica. " * 4,
                                "calidad": 0.2}]
        r = self.cerebro.responder("busca en internet qué es la computación cuántica")
        self.assertEqual(r.origen, "nada")
        self.assertIn("mencionan el tema", r.texto)

    @patch("aria.cerebro.web.buscar")
    def test_comando_investiga(self, buscar):
        buscar.return_value = [{"titulo": "Fuente", "url": "https://example.org/a",
                                "texto": "La memoria RAM almacena temporalmente datos e instrucciones que necesita la CPU." * 3}]
        r = self.cerebro.responder("/investiga memoria RAM")
        self.assertEqual(r.origen, "web")


    @patch("aria.cerebro.web.buscar")
    def test_aprende_de_internet_guarda_y_lo_anuncia(self, buscar):
        buscar.return_value = [{"titulo": "Fuente de RAM", "url": "https://example.org/ram",
                                "texto": "La memoria RAM es memoria volátil que conserva temporalmente "
                                        "los datos y programas que utiliza el procesador." * 3}]
        r = self.cerebro.responder("aprende de internet sobre memoria RAM")
        self.assertEqual(r.origen, "web")
        self.assertIn("He aprendido esto", r.texto)
        self.assertGreaterEqual(len(self.mem.buscar("memoria RAM volátil", k=3)), 1)

    @patch("aria.cerebro.web.buscar")
    def test_busqueda_automatica_si_no_hay_evidencia_local(self, buscar):
        self.cfg["buscar_automaticamente_si_no_sabe"] = True
        buscar.return_value = [{"titulo": "Fuente", "url": "https://example.org/termica",
                                "texto": "La conducción térmica es la transferencia de energía "
                                        "por contacto entre cuerpos a distinta temperatura." * 3}]
        r = self.cerebro.responder("¿Qué es la conducción térmica?")
        self.assertEqual(r.origen, "web")
        buscar.assert_called_once()

    @patch("aria.cerebro.web.buscar")
    def test_no_busca_automaticamente_si_ya_hay_respuesta_local(self, buscar):
        self.cfg["buscar_automaticamente_si_no_sabe"] = True
        self.mem.aprender_texto("La fotosíntesis es el proceso por el que las plantas convierten luz en energía química.",
                                fuente="test", titulo="Fotosíntesis")
        self.cerebro.responder("¿Qué es la fotosíntesis?")
        buscar.assert_not_called()

    @patch("aria.cerebro.web.buscar")
    def test_sintetiza_afirmaciones_de_fuentes_distintas_sin_repetir_definicion(self, buscar):
        buscar.return_value = [
            {"titulo": "Qué es la fotosíntesis", "url": "https://ciencia.example/foto",
             "texto": ("La fotosíntesis es el proceso por el que las plantas convierten la luz en energía química. "
                       "Este proceso ocurre principalmente en los cloroplastos y necesita agua y dióxido de carbono."),
             "calidad": 0.9},
            {"titulo": "Fotosíntesis: guía", "url": "https://educacion.example/foto",
             "texto": ("La fotosíntesis es un proceso mediante el cual las plantas transforman la energía luminosa en energía química. "
                       "Durante algunas reacciones se libera oxígeno a partir del agua."),
             "calidad": 0.9},
        ]
        r = self.cerebro.responder("busca en internet qué es la fotosíntesis")
        self.assertEqual(r.origen, "web")
        self.assertEqual(r.texto.lower().count("la fotosíntesis es"), 1)
        self.assertIn("cloroplastos", r.texto.lower())
        self.assertIn("oxígeno", r.texto.lower())
        self.assertIn("coinciden en más de un dominio", r.texto.lower())
        self.assertNotIn("ajuste temático estimado", r.texto.lower())

    def test_detecta_intenciones_de_busqueda(self):
        for q in ("investiga procesadores", "consulta en internet la fotosíntesis",
                  "busca en la web Python", "dame el enlace de la web oficial de Python"):
            self.assertTrue(quiere_busqueda_web(q), q)


if __name__ == "__main__":
    unittest.main()
