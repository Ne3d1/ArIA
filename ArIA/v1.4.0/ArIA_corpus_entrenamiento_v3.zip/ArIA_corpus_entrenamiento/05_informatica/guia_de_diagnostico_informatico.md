# Diagnóstico de problemas informáticos

Empieza por describir el síntoma exacto, el momento en que aparece y los cambios recientes. Reproduce el fallo si es seguro hacerlo.

Comprueba de forma ordenada: alimentación y conexiones; mensajes de error; espacio disponible; procesos y recursos; red; permisos; versiones; registros. Cambia una variable cada vez y anota el resultado.

Antes de modificar archivos importantes, realiza una copia de seguridad. Evita ejecutar comandos destructivos sin comprender su efecto. Si el problema puede afectar a datos o seguridad, detente y pide ayuda especializada.
