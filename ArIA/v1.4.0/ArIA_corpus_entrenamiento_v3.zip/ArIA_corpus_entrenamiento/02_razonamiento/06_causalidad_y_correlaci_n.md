# Causalidad y correlación

## Definición
Dos variables correlacionadas cambian juntas, pero eso no basta para demostrar que una cause la otra. Puede existir causalidad inversa, una tercera variable o una coincidencia.

## Método de trabajo
Formula una hipótesis causal; establece el orden temporal; identifica variables de confusión; compara grupos o periodos; busca mecanismos plausibles y evidencia independiente.

## Ejemplo explicado
Las ventas de helados y los casos de insolación pueden aumentar en verano. La temperatura puede influir en ambas variables, sin que comprar helado cause insolación.

## Errores y límites
No deduzcas causalidad de una gráfica correlacional aislada. Considera explicaciones alternativas y limita el alcance de la conclusión.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de causalidad y correlación?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
