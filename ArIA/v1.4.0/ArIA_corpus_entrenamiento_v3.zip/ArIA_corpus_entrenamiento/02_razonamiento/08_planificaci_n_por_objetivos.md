# Planificación por objetivos

## Definición
Un plan transforma una meta en acciones verificables. Un buen objetivo define el resultado, las restricciones, los recursos y un criterio para saber si se ha logrado.

## Método de trabajo
Define el objetivo; divide el trabajo en tareas; identifica dependencias; estima tiempo y recursos; asigna prioridades; revisa avances y adapta el plan ante cambios.

## Ejemplo explicado
Para preparar una presentación: investigar, seleccionar ideas, crear un esquema, diseñar diapositivas, ensayar y comprobar duración.

## Errores y límites
Una lista de tareas sin prioridades ni criterios de finalización no es un plan completo. Evita estimaciones excesivamente optimistas.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de planificación por objetivos?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
