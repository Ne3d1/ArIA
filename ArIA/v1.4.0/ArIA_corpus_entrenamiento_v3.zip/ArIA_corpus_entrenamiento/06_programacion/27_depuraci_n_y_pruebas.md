# Depuración y pruebas

## Definición
Depurar consiste en localizar y corregir la causa de un fallo. Probar consiste en comprobar el comportamiento frente a resultados esperados.

## Método de trabajo
Reproduce el error; reduce el caso; lee el mensaje y la traza; formula hipótesis; cambia una cosa cada vez; añade una prueba de regresión.

## Ejemplo explicado
Si una función falla solo con una lista vacía, crea una prueba mínima con [] y decide el comportamiento esperado.

## Errores y límites
No arregles un síntoma ocultando el error. Una prueba que solo repite la implementación puede confirmar el mismo fallo.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de depuración y pruebas?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
