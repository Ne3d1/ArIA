import unittest

from aria.sintesis import consolidar
from aria import web


class SintesisMultiFuente(unittest.TestCase):
    def test_fusiona_definiciones_repetidas_y_conserva_aportes_complementarios(self):
        textos = [
            "La fotosíntesis es el proceso por el que las plantas convierten la luz en energía química. "
            "Este proceso ocurre principalmente en los cloroplastos y necesita agua y dióxido de carbono.",
            "La fotosíntesis es un proceso mediante el cual las plantas transforman la energía luminosa en energía química. "
            "Durante algunas reacciones se libera oxígeno a partir del agua.",
        ]
        fuentes = [("https://ciencia.example/a", "Fotosíntesis"),
                   ("https://educacion.example/b", "Fotosíntesis")]
        r = consolidar("¿Qué es la fotosíntesis?", textos, fuentes, max_frases=4)
        defs = [x for x in r["afirmaciones"] if "fotosíntesis" in x.lower()]
        self.assertEqual(len(defs), 1)
        self.assertTrue(any("cloroplastos" in x for x in r["afirmaciones"]) or
                        any("oxígeno" in x for x in r["afirmaciones"]))
        self.assertTrue(r["corroboradas"])

    def test_no_fusiona_definiciones_con_polaridad_opuesta(self):
        r = consolidar("¿Qué es la memoria RAM?", [
            "La memoria RAM es una memoria volátil que almacena datos temporalmente.",
            "La memoria RAM no es una memoria volátil y conserva los datos sin alimentación.",
        ], [("https://a.example/ram", "RAM"), ("https://b.example/ram", "RAM")])
        self.assertEqual(len(r["afirmaciones"]), 2)

    def test_no_confunde_numero_de_fuentes_con_numero_de_afirmaciones(self):
        textos = [
            "La memoria RAM almacena temporalmente datos e instrucciones que utiliza el procesador.",
            "La memoria RAM almacena temporalmente datos e instrucciones que utiliza el procesador.",
        ]
        r = consolidar("¿Qué es la memoria RAM?", textos,
                       [("https://a.example/ram", "RAM"), ("https://b.example/ram", "RAM")])
        self.assertEqual(len(r["afirmaciones"]), 1)
        self.assertEqual(len(r["corroboradas"]), 1)

    def test_elimina_promociones_y_titulos_sin_contenido(self):
        r = consolidar("¿Qué es la fotosíntesis?", [
            "Fotosíntesis: todo lo que debes saber. Escucha nuestro podcast y suscríbete.",
            "La fotosíntesis es el proceso por el que las plantas convierten luz en energía química.",
        ], [("https://a.example", "A"), ("https://b.example", "B")])
        self.assertEqual(len(r["afirmaciones"]), 1)
        self.assertIn("proceso", r["afirmaciones"][0])


class EvidenciasGenericas(unittest.TestCase):
    def test_usa_definicion_como_ancla_para_detalles_sin_repetir_el_tema(self):
        texto = (
            "La fotosíntesis es el proceso por el que las plantas convierten la luz en energía química. "
            "Este proceso ocurre principalmente en los cloroplastos y necesita agua y dióxido de carbono. "
            "Durante las reacciones luminosas se libera oxígeno a partir de moléculas de agua."
        )
        frases, definicion = web.extraer_evidencias(texto, "fotosíntesis", requiere_definicion=True)
        self.assertTrue(definicion)
        self.assertTrue(any("cloroplastos" in f for f in frases))
        self.assertTrue(any("oxígeno" in f for f in frases))

    def test_no_depende_de_reglas_especificas_de_computacion_cuantica(self):
        texto = (
            "La memoria RAM es una memoria volátil que almacena temporalmente datos e instrucciones. "
            "El contenido se pierde cuando se interrumpe la alimentación eléctrica. "
            "El procesador consulta esta memoria para acceder rápidamente a los datos activos."
        )
        frases, definicion = web.extraer_evidencias(texto, "memoria RAM", requiere_definicion=True)
        self.assertTrue(definicion)
        self.assertTrue(any("procesador" in f for f in frases))


if __name__ == "__main__":
    unittest.main()


class PlanificadorInvestigacion(unittest.TestCase):
    def test_descompone_comparacion_de_versiones_y_dimensiones(self):
        from aria.razonamiento import planificar_investigacion
        consulta = ("¿Qué diferencias existen entre PCIe 3.0, 4.0, 5.0 y 6.0? "
                   "Incluye sus velocidades, fechas de lanzamiento y diferencias técnicas.")
        plan = planificar_investigacion(consulta)
        self.assertGreaterEqual(len(plan), 5)
        self.assertIn(consulta.strip(" ¿?."), plan[0])
        for version in ("PCIe 3.0", "PCIe 4.0", "PCIe 5.0", "PCIe 6.0"):
            self.assertTrue(any(version in q for q in plan), version)
        self.assertTrue(any("velocidad" in q for q in plan))
        self.assertTrue(any("fecha" in q for q in plan))

    def test_no_multiplica_busquedas_para_una_pregunta_sencilla(self):
        from aria.razonamiento import planificar_investigacion
        self.assertEqual(planificar_investigacion("cómo funciona un procesador"),
                         ["cómo funciona un procesador"])
