# Seguridad digital

## Definición
La seguridad digital protege confidencialidad, integridad y disponibilidad. Depende de tecnología, hábitos, procedimientos y respuesta ante incidentes.

## Método de trabajo
Actualiza sistemas; utiliza contraseñas únicas y gestor; activa autenticación multifactor; limita permisos; verifica enlaces y adjuntos; conserva copias de seguridad probadas.

## Ejemplo explicado
Una copia de seguridad desconectada o protegida frente a modificaciones puede ayudar a recuperarse de ransomware.

## Errores y límites
Ninguna medida elimina todos los riesgos. No compartas claves privadas ni códigos de recuperación y verifica solicitudes inesperadas.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de seguridad digital?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
