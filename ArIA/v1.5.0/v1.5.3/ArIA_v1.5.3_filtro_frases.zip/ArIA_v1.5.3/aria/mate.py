"""Matemáticas de ArIA: aritmética segura y álgebra básica (con sympy)."""
import ast
import math
import operator
import re


class ErrorMate(Exception):
    pass


def _fact(n):
    if n < 0 or n > 2000 or int(n) != n:
        raise ErrorMate("El factorial solo se calcula para enteros entre 0 y 2000.")
    return math.factorial(int(n))


def _log(x, base=None):
    return math.log10(x) if base is None else math.log(x, base)


_BIN = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod, ast.Pow: operator.pow,
}
_UN = {ast.USub: operator.neg, ast.UAdd: operator.pos}
_CONST = {"pi": math.pi, "e": math.e, "tau": math.tau}
_FUNC = {
    "sqrt": math.sqrt, "raiz": math.sqrt, "sin": math.sin, "sen": math.sin, "cos": math.cos,
    "tan": math.tan, "asin": math.asin, "acos": math.acos, "atan": math.atan,
    "ln": math.log, "log": _log, "log10": math.log10, "log2": math.log2, "exp": math.exp,
    "abs": abs, "round": round, "floor": math.floor, "ceil": math.ceil,
    "factorial": _fact, "fact": _fact, "gcd": math.gcd, "mcd": math.gcd,
    "lcm": math.lcm, "mcm": math.lcm, "min": min, "max": max,
    "grados": math.degrees, "radianes": math.radians,
}
_NOMBRES_FUNC = "|".join(sorted(list(_FUNC) + list(_CONST), key=len, reverse=True))


def _eval(n):
    if isinstance(n, ast.Expression):
        return _eval(n.body)
    if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool):
        return n.value
    if isinstance(n, ast.BinOp) and type(n.op) in _BIN:
        a, b = _eval(n.left), _eval(n.right)
        if isinstance(n.op, ast.Pow) and (abs(b) > 10000 or (abs(a) > 1e6 and abs(b) > 1000)):
            raise ErrorMate("Esa potencia es demasiado grande.")
        return _BIN[type(n.op)](a, b)
    if isinstance(n, ast.UnaryOp) and type(n.op) in _UN:
        return _UN[type(n.op)](_eval(n.operand))
    if isinstance(n, ast.Name) and n.id in _CONST:
        return _CONST[n.id]
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in _FUNC and not n.keywords:
        return _FUNC[n.func.id](*[_eval(a) for a in n.args])
    raise ErrorMate("No entiendo esa expresión.")


def _normalizar_operadores(expr):
    """Traduce operaciones expresadas con palabras a símbolos matemáticos."""
    s = expr.lower().strip()
    s = re.sub(r"^(?:calcula|calcular|divide|dividir|multiplica|multiplicar|suma|sumar|resta|restar)\s+", "", s)
    # Errores ortográficos frecuentes y variantes sin tilde.
    s = re.sub(r"\bquanto\b|\bkuanto\b", "cuanto", s)
    s = re.sub(r"\bmas\b", "más", s)
    # Operadores compuestos primero para evitar reemplazos parciales.
    reemplazos = [
        (r"\bdividido\s+entre\b|\bdividido\s+por\b|\bdividir\s+entre\b", "/"),
        (r"\bmultiplicado\s+por\b|\bmultiplicada\s+por\b", "*"),
        (r"\belevado\s+a\b|\belevada\s+a\b", "**"),
        (r"\bpor\b|\bveces\b|\bmultiplica(?:r)?\b", "*"),
        (r"\bm[aá]s\b|\bsuma(?:r)?\b|\bmas\b", "+"),
        (r"\bmenos\b|\bresta(?:r)?\b", "-"),
        (r"\bentre\b|\bdivid(?:e|ir)\b", "/"),
        (r"\bal\s+cuadrado\b", "**2"),
        (r"\bal\s+cubo\b", "**3"),
    ]
    for patron, simbolo in reemplazos:
        s = re.sub(patron, simbolo, s, flags=re.I)
    # Quita palabras de enlace que suelen aparecer en preguntas habladas.
    s = re.sub(r"\b(?:es|son|sale|seria|sería|te da|vale|da|igual a|cu[aá]nto|cuanto|calcula|calcular|dime|haz la cuenta de|resuelve la cuenta de)\b", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _preparar(expr):
    s = _normalizar_operadores(expr).lower().strip().rstrip("?=")
    s = s.replace("×", "*").replace("÷", "/").replace("^", "**")
    s = re.sub(r"√\s*\(", "sqrt(", s)
    s = re.sub(r"√\s*(\d+(?:[.,]\d+)?)", r"sqrt(\1)", s)
    s = re.sub(r"(\d),(\d)", r"\1.\2", s)
    s = re.sub(r"(\d+)\s*!", r"factorial(\1)", s)
    s = re.sub(r"(\d)\s*x\s*(\d)", r"\1*\2", s)
    s = re.sub(r"(\d+(?:\.\d+)?)\s*%", r"(\1/100)", s)
    s = re.sub(r"(\d|\))\s*\(", r"\1*(", s)
    s = re.sub(r"(\d)\s*(pi|tau)\b", r"\1*\2", s)
    return s


def formatear(x):
    if isinstance(x, float):
        if x.is_integer() and abs(x) < 1e15:
            return str(int(x))
        return f"{x:.10g}"
    return str(x)


def calcular(expr):
    """Evalúa una expresión aritmética. Lanza ErrorMate si no se puede."""
    try:
        arbol = ast.parse(_preparar(expr), mode="eval")
        return formatear(_eval(arbol))
    except ErrorMate:
        raise
    except ZeroDivisionError:
        raise ErrorMate("No se puede dividir entre cero.")
    except (SyntaxError, ValueError, TypeError, OverflowError, RecursionError):
        raise ErrorMate("No he podido calcular eso. Revisa la expresión.")


# ---------------- álgebra (sympy) ----------------
def _sympy():
    try:
        import sympy as sp
        from sympy.parsing.sympy_parser import (
            convert_xor, implicit_multiplication_application, parse_expr, standard_transformations,
        )
    except ImportError:
        raise ErrorMate("Para álgebra necesito la librería `sympy` (pip install sympy).")
    return sp, parse_expr, standard_transformations + (implicit_multiplication_application, convert_xor)


def _parse(sp, parse_expr, transf, txt):
    txt = txt.strip().replace("√", "sqrt").replace("×", "*").replace("÷", "/")
    txt = re.sub(r"(\d),(\d)", r"\1.\2", txt)
    if not txt or len(txt) > 200 or "__" in txt or not re.fullmatch(r"[\w\s+\-*/^().,<>]+", txt):
        raise ErrorMate("Esa expresión no es válida.")
    local = {
        "e": sp.E, "pi": sp.pi, "sen": sp.sin, "raiz": sp.sqrt, "ln": sp.log,
        "log": lambda x, b=10: sp.log(x, b),
    }
    try:
        return parse_expr(txt, local_dict=local, transformations=transf)
    except Exception:
        raise ErrorMate("No he entendido la expresión.")


def _mostrar(sp, e):
    return sp.sstr(e).replace("**", "^")


def algebra(operacion, texto):
    sp, parse_expr, transf = _sympy()
    p = lambda t: _parse(sp, parse_expr, transf, t)
    texto = re.sub(r"(\d),(\d)", r"\1.\2", texto)

    if operacion == "resolver":
        partes = [x for x in re.split(r"[;,]", texto) if x.strip()]
        if len(partes) > 1 and all("=" in x for x in partes):
            eqs = [p(a) - p(b) for a, b in (x.split("=", 1) for x in partes)]
            vars_ = sorted(set().union(*[e.free_symbols for e in eqs]), key=str)
            sols = sp.solve(eqs, vars_, dict=True)
            if not sols:
                return "El sistema no tiene solución."
            return "**Solución del sistema:** " + "; ".join(
                ", ".join(f"{k} = {_mostrar(sp, v)}" for k, v in s.items()) for s in sols
            )
        if "=" in texto:
            izq, der = texto.split("=", 1)
            expr = p(izq) - p(der)
        else:
            expr = p(texto)
        vars_ = sorted(expr.free_symbols, key=str)
        if not vars_:
            raise ErrorMate("No veo ninguna incógnita que resolver.")
        var = next((v for v in vars_ if str(v) == "x"), vars_[0])
        sols = sp.solve(expr, var)
        if not sols:
            return f"No encuentro soluciones reales para `{var}`."
        lineas = []
        for s in sols:
            aprox = ""
            if not s.is_Rational and s.is_real:
                aprox = f" ≈ {sp.N(s, 6)}"
            lineas.append(f"- `{var} = {_mostrar(sp, s)}`{aprox}")
        return "**Soluciones:**\n" + "\n".join(lineas)

    expr = p(texto)
    vars_ = sorted(expr.free_symbols, key=str)
    var = next((v for v in vars_ if str(v) == "x"), vars_[0] if vars_ else sp.Symbol("x"))
    if operacion == "derivar":
        return f"**Derivada** respecto a `{var}`: `{_mostrar(sp, sp.diff(expr, var))}`"
    if operacion == "integrar":
        return f"**Integral** respecto a `{var}`: `{_mostrar(sp, sp.integrate(expr, var))} + C`"
    if operacion == "simplificar":
        return f"**Simplificado:** `{_mostrar(sp, sp.simplify(expr))}`"
    if operacion == "factorizar":
        return f"**Factorizado:** `{_mostrar(sp, sp.factor(expr))}`"
    if operacion == "expandir":
        return f"**Expandido:** `{_mostrar(sp, sp.expand(expr))}`"
    raise ErrorMate("Operación desconocida.")


# ---------------- reglas matemáticas aprendidas ----------------
def inferir_regla_ejemplo(texto):
    """Reconoce ejemplos numéricos que demuestran la propiedad distributiva."""
    t = texto.strip().rstrip(". ")
    if "=" not in t:
        return None
    izquierda, derecha = t.split("=", 1)
    try:
        arbol = ast.parse(_preparar(izquierda), mode="eval").body
        esperado = float(calcular(derecha))
        obtenido = float(calcular(izquierda))
    except (ErrorMate, ValueError, TypeError):
        return None
    if not math.isclose(obtenido, esperado, rel_tol=1e-9, abs_tol=1e-9):
        return None

    def distributiva(n):
        if not isinstance(n, ast.BinOp) or not isinstance(n.op, ast.Mult):
            return False
        return ((isinstance(n.left, ast.BinOp) and isinstance(n.left.op, (ast.Add, ast.Sub))) or
                (isinstance(n.right, ast.BinOp) and isinstance(n.right.op, (ast.Add, ast.Sub))))

    if distributiva(arbol):
        return {
            "clave": "propiedad_distributiva",
            "nombre": "Propiedad distributiva",
            "explicacion": "La multiplicación se puede repartir entre los términos de una suma o resta: "
                           "(a+b)×c = a×c+b×c y (a-b)×c = a×c-b×c. También funciona si el paréntesis está a la derecha.",
            "ejemplo": t,
        }
    return None


def _explicar_distributiva(texto):
    """Devuelve el desarrollo de un producto por una suma/resta, si tiene esa forma."""
    try:
        arbol = ast.parse(_preparar(texto), mode="eval").body
    except (SyntaxError, ValueError):
        return None
    if not isinstance(arbol, ast.BinOp) or not isinstance(arbol.op, ast.Mult):
        return None
    suma, factor = None, None
    if isinstance(arbol.left, ast.BinOp) and isinstance(arbol.left.op, (ast.Add, ast.Sub)):
        suma, factor = arbol.left, arbol.right
    elif isinstance(arbol.right, ast.BinOp) and isinstance(arbol.right.op, (ast.Add, ast.Sub)):
        suma, factor = arbol.right, arbol.left
    if suma is None:
        return None
    a, b = ast.unparse(suma.left), ast.unparse(suma.right)
    c = ast.unparse(factor)
    op = "+" if isinstance(suma.op, ast.Add) else "-"
    paso = f"({a}×{c}) {op} ({b}×{c})"
    try:
        valor_paso = calcular(paso.replace("×", "*"))
    except ErrorMate:
        return None
    return f"Aplico la **propiedad distributiva**: `({a} {op} {b}) × {c} = {paso} = {valor_paso}`. "


# ---------------- detección en lenguaje natural ----------------
_RE_ALG = re.compile(
    r"^(?P<v>resuelve|resolver|resuelva|ecuaci[oó]n|deriva|derivar|derivada de|integra|integrar|"
    r"integral de|simplifica|simplificar|factoriza|factorizar|expande|expandir|desarrolla)\b"
    r"\s*(?:la |el |de )?(?P<r>.*)$",
    re.I,
)
_RE_CALC = re.compile(
    r"^(?:(?:oye,?|por favor,?|me puedes|puedes|podr[ií]as|quiero que)\s+)*(?:calcula|calcular|haz la cuenta de|resuelve la cuenta de|cu[aá]?nto|quanto|kuanto|resultado de|dime cu[aá]?nto|cu[aá]?nto da|cu[aá]?nto vale|cu[aá]?nto es|cu[aá]?nto sale|cu[aá]?nto te da|cu[aá]?nto ser[ií]a)\b\s*(?P<r>.*)$",
    re.I,
)
_RE_PORC = re.compile(r"(\d+(?:[.,]\d+)?)\s*%\s*de\s*(\d+(?:[.,]\d+)?)", re.I)
_OPS_ALG = {
    "resuelve": "resolver", "resolver": "resolver", "resuelva": "resolver", "ecuacion": "resolver",
    "deriva": "derivar", "derivar": "derivar", "derivada de": "derivar",
    "integra": "integrar", "integrar": "integrar", "integral de": "integrar",
    "simplifica": "simplificar", "simplificar": "simplificar",
    "factoriza": "factorizar", "factorizar": "factorizar",
    "expande": "expandir", "expandir": "expandir", "desarrolla": "expandir",
}


def _parece_expresion(t):
    if re.search(r"\d+[-/]\d+[-/]\d+", t):  # fechas
        return False
    preparado = _normalizar_operadores(t)
    sin_funciones = re.sub(rf"\b({_NOMBRES_FUNC})\b", "", preparado.lower())
    return (
        bool(re.search(r"\d", preparado))
        and bool(re.search(r"[+\-*/^×÷√%!]", preparado))
        and re.fullmatch(r"[\d\s+\-*/^().,×÷√%!x]*", sin_funciones) is not None
    )


def responder(texto, reglas=None):
    """Devuelve una respuesta matemática; puede explicar reglas aprendidas."""
    t = texto.strip().strip("¿?¡").strip()
    t = re.sub(r"(?<!\d)!+$|\?+$", "", t).strip()

    m = _RE_PORC.search(t)
    if m:
        a, b = float(m.group(1).replace(",", ".")), float(m.group(2).replace(",", "."))
        return f"El {m.group(1)}% de {m.group(2)} es **{formatear(a * b / 100)}**."

    m = _RE_ALG.match(t)
    if m:
        op = _OPS_ALG[re.sub(r"ó", "o", m.group("v").lower())]
        try:
            return algebra(op, m.group("r"))
        except ErrorMate as e:
            return f"⚠️ {e}"

    m = _RE_CALC.match(t)
    if m:
        try:
            expr = _normalizar_operadores(m.group("r"))
            resultado = calcular(m.group("r"))
            extra = _explicar_distributiva(m.group("r")) if "propiedad_distributiva" in (reglas or []) else None
            return f"`{expr}` = **{resultado}**" + ("\n\n" + extra if extra else "")
        except ErrorMate as e:
            return f"⚠️ {e}"

    if _parece_expresion(t):
        try:
            expr = _normalizar_operadores(t)
            resultado = calcular(t)
            extra = _explicar_distributiva(t) if "propiedad_distributiva" in (reglas or []) else None
            return f"`{expr.rstrip('=')}` = **{resultado}**" + ("\n\n" + extra if extra else "")
        except ErrorMate:
            return None
    return None
