# Redes e Internet

## Definición
Una red conecta dispositivos para intercambiar datos. Internet es una red de redes que utiliza protocolos comunes. La comunicación depende de direccionamiento, encaminamiento y transporte.

## Método de trabajo
Distingue dirección IP, nombre de dominio, DNS, router, paquetes y protocolos. Comprueba conectividad por etapas en vez de cambiar varias configuraciones a la vez.

## Ejemplo explicado
Al visitar un dominio, el sistema resuelve su nombre mediante DNS y establece una conexión con el servidor correspondiente.

## Errores y límites
DNS no es lo mismo que una dirección IP. Una conexión local puede funcionar aunque el acceso a Internet falle.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de redes e internet?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
