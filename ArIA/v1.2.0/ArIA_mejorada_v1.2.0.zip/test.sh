#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then bash ./setup.sh; fi
.venv/bin/python -m compileall -q aria main.py tests
.venv/bin/python -m unittest discover -v
