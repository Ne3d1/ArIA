import copy
import tempfile
import unittest
from unittest.mock import patch

from aria.config import DEFAULTS
from aria.cerebro import Cerebro
from aria.memoria import Memoria
from aria.razonamiento import descomponer_preguntas


class DescomposicionPreguntasV180(unittest.TestCase):
    def test_separa_dos_preguntas_con_signos(self):
        preguntas = descomponer_preguntas(
            "¿Por qué comenzó la Segunda Guerra Mundial? ¿Qué relación tuvo el Tratado de Versalles?"
        )
        self.assertEqual(len(preguntas), 2)
        self.assertIn("Segunda Guerra Mundial", preguntas[0])
        self.assertIn("Tratado de Versalles", preguntas[1])

    def test_separa_interrogativas_coordinadas_en_una_frase(self):
        preguntas = descomponer_preguntas(
            "¿Por qué comenzó la Segunda Guerra Mundial y qué relación tuvo el Tratado de Versalles?"
        )
        self.assertEqual(len(preguntas), 2)
        self.assertIn("por qué comenzó", preguntas[0].lower())
        self.assertIn("qué relación", preguntas[1].lower())

    def test_instruccion_cronologica_se_mantiene_con_su_pregunta(self):
        preguntas = descomponer_preguntas(
            "¿Cuáles fueron las causas de la Segunda Guerra Mundial? Ordénalas cronológicamente."
        )
        self.assertEqual(len(preguntas), 1)
        self.assertIn("cronológicamente", preguntas[0])

    def test_tres_preguntas_se_conservan_por_separado(self):
        preguntas = descomponer_preguntas(
            "¿Qué fue el Tratado de Versalles? ¿Qué consecuencias tuvo para Alemania? ¿Cómo influyó en la guerra?"
        )
        self.assertEqual(len(preguntas), 3)


class MemoriaYComposicionV180(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = copy.deepcopy(DEFAULTS)
        self.cfg["buscar_automaticamente_si_no_sabe"] = False
        self.cfg["buscar_en_internet"] = True
        self.cfg["aprender_de_internet"] = False
        self.mem = Memoria(ruta=f"{self.tmp.name}/memoria.db")
        self.cerebro = Cerebro(self.cfg, self.mem)

    def tearDown(self):
        self.mem.bd.close()
        self.tmp.cleanup()

    def test_qa_no_reutiliza_literal_ante_otra_pregunta_del_mismo_tema(self):
        respuesta_ensenada = "La guerra comenzó por la invasión alemana de Polonia y las tensiones expansionistas."
        self.mem.aprender_qa("¿Por qué comenzó la Segunda Guerra Mundial?", respuesta_ensenada)
        self.mem.aprender_texto(
            "El Tratado de Versalles de 1919 impuso a Alemania reparaciones económicas, pérdidas territoriales y limitaciones militares. "
            "El resentimiento contra el tratado fue aprovechado por movimientos nacionalistas y contribuyó a la inestabilidad europea.",
            fuente="usuario:historia", titulo="Tratado de Versalles")
        r = self.cerebro.responder("¿Y el Tratado de Versalles?")
        self.assertEqual(r.origen, "memoria")
        self.assertNotIn(respuesta_ensenada, r.texto)
        self.assertIn("Tratado de Versalles", r.texto)
        self.assertIn("1919", r.texto)

    def test_seguimiento_con_nombre_de_entidad_se_conecta_al_tema_anterior(self):
        self.mem.aprender_texto(
            "La Segunda Guerra Mundial comenzó en Europa en 1939 cuando Alemania invadió Polonia. "
            "Entre los factores de fondo de la Segunda Guerra Mundial estuvieron el expansionismo nazi y las tensiones europeas.",
            fuente="usuario:historia", titulo="Segunda Guerra Mundial")
        self.mem.aprender_texto(
            "El Tratado de Versalles se firmó en 1919 y sus reparaciones y restricciones alimentaron el resentimiento político en Alemania.",
            fuente="usuario:historia", titulo="Tratado de Versalles")
        primera = self.cerebro.responder("¿Por qué comenzó la Segunda Guerra Mundial?")
        self.assertNotIn("Tratado de Versalles", primera.texto)
        self.assertIn("Síntesis causal", primera.texto)
        self.assertIn("desencadenante", primera.texto.lower())
        segunda = self.cerebro.responder("¿Y el Tratado de Versalles?")
        self.assertIn("relación", segunda.texto.lower())
        self.assertIn("1919", segunda.texto)
        self.assertIn("1939", segunda.texto)
        self.assertIn("antecedente", segunda.texto.lower())

    def test_pregunta_exacta_aprendida_puede_reutilizar_respuesta(self):
        respuesta_ensenada = "Respuesta exacta enseñada para esta pregunta."
        self.mem.aprender_qa("¿Por qué comenzó la Segunda Guerra Mundial?", respuesta_ensenada)
        r = self.cerebro.responder("¿Por qué comenzó la Segunda Guerra Mundial?")
        self.assertIn(respuesta_ensenada, r.texto)

    def test_responde_varias_preguntas_con_apartados_independientes(self):
        self.mem.aprender_texto(
            "La Segunda Guerra Mundial comenzó en Europa en 1939 después de que Alemania invadiera Polonia. "
            "Entre sus antecedentes estuvieron el expansionismo nazi, el militarismo y la debilidad de la seguridad colectiva.",
            fuente="usuario:historia", titulo="Causas de la Segunda Guerra Mundial")
        self.mem.aprender_texto(
            "El Tratado de Versalles se firmó en 1919 al terminar la Primera Guerra Mundial. "
            "Impuso reparaciones, pérdidas territoriales y restricciones militares a Alemania, alimentando el resentimiento político.",
            fuente="usuario:historia", titulo="Tratado de Versalles")
        r = self.cerebro.responder(
            "¿Por qué comenzó la Segunda Guerra Mundial? ¿Qué relación tuvo el Tratado de Versalles?")
        self.assertEqual(r.origen, "memoria")
        self.assertIn("### 1.", r.texto)
        self.assertIn("### 2.", r.texto)
        self.assertIn("1939", r.texto)
        self.assertIn("1919", r.texto)

    @patch("aria.cerebro.web.buscar")
    def test_investigacion_web_consulta_y_responde_cada_pregunta(self, buscar):
        def fake(q, paginas):
            qn = q.lower()
            if "tratado" in qn or "versalles" in qn:
                texto = (
                    "El Tratado de Versalles fue firmado en 1919 después de la Primera Guerra Mundial. "
                    "El acuerdo impuso reparaciones económicas y pérdidas territoriales a Alemania. "
                    "El resentimiento y la inestabilidad política asociados al tratado favorecieron el auge del extremismo."
                )
                return [{"titulo": "Tratado de Versalles y sus consecuencias", "url": "https://example.org/versalles",
                         "texto": texto, "calidad": 0.9}]
            if "guerra" in qn or "polonia" in qn or "causas" in qn:
                texto = (
                    "La Segunda Guerra Mundial comenzó en Europa en 1939 cuando Alemania invadió Polonia. "
                    "El expansionismo de la Alemania nazi y el fracaso de la diplomacia europea fueron causas importantes. "
                    "Las tensiones internacionales se agravaron durante la década de 1930."
                )
                return [{"titulo": "Causas de la Segunda Guerra Mundial", "url": "https://example.org/guerra",
                         "texto": texto, "calidad": 0.9}]
            return []
        buscar.side_effect = fake
        r = self.cerebro.responder(
            "investiga ¿Por qué comenzó la Segunda Guerra Mundial? ¿Qué relación tuvo el Tratado de Versalles?")
        self.assertEqual(r.origen, "web")
        self.assertIn("### 1.", r.texto)
        self.assertIn("### 2.", r.texto)
        self.assertIn("https://example.org/guerra", r.texto)
        self.assertIn("https://example.org/versalles", r.texto)


if __name__ == "__main__":
    unittest.main()
