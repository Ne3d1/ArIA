# Energía y conservación

## Definición
La energía es una magnitud que permite describir cambios y transferencias. En un sistema aislado se conserva: puede transformarse o transferirse, pero no aparecer de la nada ni desaparecer.

## Método de trabajo
Identifica el sistema y sus límites; reconoce formas de energía; describe transferencias; distingue energía útil y disipación; comprueba unidades y balance.

## Ejemplo explicado
En una bombilla, parte de la energía eléctrica se transforma en luz y parte en energía térmica.

## Errores y límites
No digas que la energía se pierde sin especificar el sistema. A menudo se dispersa al entorno y resulta menos aprovechable.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de energía y conservación?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
