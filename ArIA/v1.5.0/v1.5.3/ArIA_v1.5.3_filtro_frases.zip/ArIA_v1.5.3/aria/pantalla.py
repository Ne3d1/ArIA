"""Funciones opcionales para inspeccionar ventanas y leer texto de pantalla.

No guarda capturas ni las transmite. La captura y el OCR se ejecutan localmente;
la aplicación debe pedir permiso explícito antes de cada inspección.
"""
from __future__ import annotations

import platform
import subprocess


def programas_abiertos(limite=35):
    """Devuelve procesos visibles/activos sin argumentos ni datos de usuario."""
    try:
        import psutil
    except ImportError:
        return [], "Falta psutil. Ejecuta setup para instalar dependencias."

    resultados = []
    vistos = set()
    try:
        for p in psutil.process_iter(["name", "status"]):
            try:
                nombre = (p.info.get("name") or "").strip()
                if nombre and nombre.lower() not in vistos:
                    vistos.add(nombre.lower())
                    resultados.append(nombre)
            except (psutil.Error, OSError):
                continue
    except psutil.Error as e:
        return [], f"No pude consultar los procesos: {e}"
    return sorted(resultados, key=str.casefold)[:limite], None


def ventanas_abiertas():
    """Intenta recuperar títulos de ventanas; depende de soporte del sistema."""
    try:
        import pygetwindow
        titulos = [x.title.strip() for x in pygetwindow.getAllWindows() if x.title.strip()]
        return list(dict.fromkeys(titulos)), None
    except Exception as e:
        return [], f"No se pudieron leer los títulos de ventana en este sistema ({e})."


def leer_pantalla():
    """Captura la pantalla principal en memoria y extrae texto mediante Tesseract."""
    try:
        import mss
        from PIL import Image
    except ImportError:
        raise RuntimeError("Faltan mss o Pillow. Ejecuta setup para instalar las dependencias.")
    try:
        import pytesseract
    except ImportError:
        raise RuntimeError("Falta pytesseract. Ejecuta setup para instalarlo y después instala Tesseract OCR en tu sistema.")

    with mss.mss() as sct:
        monitor = sct.monitors[1]  # monitor principal; no captura todos los monitores
        shot = sct.grab(monitor)
        img = Image.frombytes("RGB", shot.size, shot.rgb)
    try:
        texto = pytesseract.image_to_string(img, lang="spa+eng")
    except Exception as e:
        raise RuntimeError("No se pudo ejecutar Tesseract OCR. Comprueba que Tesseract esté instalado y en PATH. " + str(e))
    # La imagen se descarta al salir; no se escribe a disco.
    return texto.strip(), img.size
