"""Perfil: con quién habla ArIA, sus gustos, datos, preferencias y quién creó a ArIA.

Todo se guarda en la base de datos local (tabla `hechos`) y sobrevive entre sesiones.
Entiende frases en castellano y en catalán.
"""
import re
import time

from . import config, nucleo
from .memoria import normalizar

ANON, ARIA = "_anonimo", "_aria"

SIN = {
    "ciudad": ["vivo", "vives", "vivir", "visc"],
    "edad": ["edad", "anos", "tengo", "tinc"],
    "cumpleanos": ["cumpleanos", "cumple", "aniversari"],
    "trabajo": ["trabajo", "trabajas", "treballo"],
    "lugar de trabajo": ["trabajo", "trabajas", "treballo"],
    "estudios": ["estudio", "estudias"],
}
PREGUNTA = {"cual", "cuales", "como", "que", "donde", "cuando", "cuanto", "cuantos", "cuantas", "quien", "dime",
            "recuerdas", "sabes", "en", "a", "quin", "quina", "on", "quan", "quants", "com"}
PERSONAL = {"mi", "mis", "vivo", "tengo", "trabajo", "estudio", "meu", "meva", "meus", "meves", "tinc", "visc"}
ARTICULOS = re.compile(r"^(?:el|la|los|las|un|una|els|les|l')\s*")
IDIOMAS = {"castellano": "castellano", "espanol": "castellano", "catalan": "catalán", "valenciano": "valenciano",
           "ingles": "inglés", "frances": "francés", "aleman": "alemán", "italiano": "italiano",
           "portugues": "portugués", "gallego": "gallego", "euskera": "euskera"}
ESTILOS = {"breve": "breve", "conciso": "breve", "concisa": "breve", "corta": "breve", "corto": "breve",
           "cortas": "breve", "breves": "breve", "breu": "breve", "concis": "breve", "curtes": "breve",
           "detallado": "detallado", "detallada": "detallado", "detallat": "detallado", "largas": "detallado",
           "detalladas": "detallado", "llargues": "detallado"}


def _cap(s):
    return s[:1].upper() + s[1:]


class Perfil:
    def __init__(self, mem, cfg, confirmar=None):
        self.mem, self.cfg = mem, cfg
        self.confirmar = confirmar or (lambda msg: False)
        self._sql(
            "CREATE TABLE IF NOT EXISTS hechos (persona TEXT, tipo TEXT, clave TEXT, valor TEXT, frase TEXT, "
            "creado REAL, PRIMARY KEY (persona, tipo, clave))"
        )
        self._sql("DELETE FROM hechos WHERE persona=?", (ARIA,))  # la identidad ya no vive en la base de datos

    # ---------------- almacenamiento ----------------
    def _sql(self, q, args=()):
        with self.mem.cerrojo:
            cur = self.mem.bd.execute(q, args)
            filas, n = cur.fetchall(), cur.rowcount
            self.mem.bd.commit()
        return filas, n

    def clave(self, nombre=None):
        n = normalizar(self.cfg.get("nombre_usuario", "") if nombre is None else nombre)
        return re.sub(r"\s+", " ", n).strip() or ANON

    def poner(self, persona, tipo, clave, valor, frase=""):
        self._sql("INSERT OR REPLACE INTO hechos VALUES (?,?,?,?,?,?)",
                  (persona, tipo, clave, valor, frase, time.time()))

    def quitar(self, persona, tipo, clave):
        return self._sql("DELETE FROM hechos WHERE persona=? AND tipo=? AND clave=?", (persona, tipo, clave))[1]

    def hechos(self, persona, tipo):
        return self._sql("SELECT clave, valor, frase FROM hechos WHERE persona=? AND tipo=? ORDER BY creado",
                         (persona, tipo))[0]

    def pref(self, clave, persona=None):
        filas, _ = self._sql("SELECT valor FROM hechos WHERE persona=? AND tipo='pref' AND clave=?",
                             (persona or self.clave(), clave))
        return filas[0][0] if filas else None

    def creador(self):
        return nucleo.CREADORA

    def personas(self):
        filas, _ = self._sql(
            "SELECT valor FROM hechos WHERE tipo='dato' AND clave='nombre' AND persona NOT IN (?,?) ORDER BY creado",
            (ANON, ARIA))
        return [f[0] for f in filas]

    def cambiar_usuario(self, nombre):
        """Cambia la persona activa. Devuelve (nombre, ya_la_conocía, hechos_migrados)."""
        nombre = re.sub(r"\s+", " ", nombre.strip()).title()
        pk = self.clave(nombre)
        conocida = bool(self._sql("SELECT 1 FROM hechos WHERE persona=? LIMIT 1", (pk,))[0])
        migrados = 0
        if not conocida:
            migrados = self._sql("SELECT COUNT(*) FROM hechos WHERE persona=?", (ANON,))[0][0][0]
            self._sql("UPDATE OR IGNORE hechos SET persona=? WHERE persona=?", (pk, ANON))
            self._sql("DELETE FROM hechos WHERE persona=?", (ANON,))
        self.cfg["nombre_usuario"] = nombre
        config.guardar(self.cfg)
        self.poner(pk, "dato", "nombre", nombre, f"te llamas {nombre}")
        return nombre, conocida, migrados

    # ---------------- presentación ----------------
    def _partes(self, pk):
        datos = [f for f in self.hechos(pk, "dato") if f[0] != "nombre"]
        gusta = [f[1] for f in self.hechos(pk, "gusta")]
        nogusta = [f[1] for f in self.hechos(pk, "nogusta")]
        prefs = [(f[0], f[1]) for f in self.hechos(pk, "pref")]
        return datos, gusta, nogusta, prefs

    def resumen(self, persona=None):
        pk = persona or self.clave()
        nombre = self.cfg.get("nombre_usuario") or "ti"
        datos, gusta, nogusta, prefs = self._partes(pk)
        lineas = [f"- {_cap(f[2])}" for f in datos]
        if gusta:
            lineas.append("- **Te gusta:** " + ", ".join(gusta))
        if nogusta:
            lineas.append("- **No te gusta:** " + ", ".join(nogusta))
        if prefs:
            lineas.append("- **Cómo quieres que te responda:** " + " · ".join(f"{k}: {v}" for k, v in prefs))
        if not lineas:
            md = (f"## 👤 Lo que sé de {nombre}\nTodavía casi nada 🙈. Cuéntame cosas: *«me llamo …»*, *«me gusta …»*, "
                  "*«vivo en …»*, *«mi color favorito es …»*.")
        else:
            md = f"## 👤 Lo que sé de {nombre}\n" + "\n".join(lineas)
        md += f"\n\n🤖 **Mi creadora:** {nucleo.CREADORA} · **Mi ayudante:** {nucleo.AYUDANTE}"
        otros = [p for p in self.personas() if self.clave(p) != pk]
        if otros:
            md += "\n\n👥 También conozco a: " + ", ".join(otros)
        return md

    def contexto(self):
        """Contexto textual del perfil para el razonamiento local."""
        pk, nombre = self.clave(), self.cfg.get("nombre_usuario", "")
        datos, gusta, nogusta, prefs = self._partes(pk)
        partes = []
        if nombre:
            partes.append(f"Hablas con {nombre}.")
        if datos:
            partes.append("Sabes de esta persona: " + "; ".join(f[2] for f in datos) + ".")
        if gusta:
            partes.append("Le gusta: " + ", ".join(gusta) + ".")
        if nogusta:
            partes.append("No le gusta: " + ", ".join(nogusta) + ".")
        for k, v in prefs:
            partes.append(f"Preferencia de la persona ({k}): {v}.")
        partes.append(nucleo.CONTEXTO)
        return " ".join(partes)

    # ---------------- comprensión del lenguaje ----------------
    def procesar(self, texto):
        """Si el texto habla de la persona (o de ArIA), actúa y devuelve la respuesta en Markdown; si no, None."""
        t = texto.strip().lstrip("¿¡").rstrip(" .!?")
        if not t:
            return None
        n = normalizar(t)
        if len(n) != len(t):
            t = n
        pk = self.clave()
        nombre = self.cfg.get("nombre_usuario", "")
        g = lambda m, i: t[m.start(i):m.end(i)].strip(" ,;\"'«»")  # noqa: E731
        mayus = lambda m, i: t[m.start(i)].isupper()  # noqa: E731
        M = lambda p: re.match(p, n)  # noqa: E731

        # ---- preguntas sobre la identidad ----
        if M(r"^(?:quien soy(?: yo)?|como me llamo|cual es mi nombre|con quien (?:hablas|hablo|estas hablando)|"
             r"sabes quien soy|me conoces|qui soc|com em dic|amb qui parles)$"):
            if not nombre:
                return "Todavía no sé cómo te llamas 🙈. Dime *«me llamo …»* y lo recordaré."
            datos, gusta, nogusta, _ = self._partes(pk)
            k = len(datos) + len(gusta) + len(nogusta)
            return (f"Hablo con **{nombre}** 😊" +
                    (f". Sé {k} cosas sobre ti; pregúntame *«qué sabes de mí»*." if k else
                     ". Todavía sé poco de ti: cuéntame qué te gusta, dónde vives…"))
        if M(r"^(?:que sabes (?:de|sobre) mi|que recuerdas (?:de|sobre) mi|dime (?:todo )?(?:lo que )?sabes (?:de|sobre) mi|"
             r"que saps de mi|que se de mi|mi perfil)$"):
            return self.resumen()
        m = M(r"^(?:que(?: cosas)? (no )?me (?:gusta|gustan)|cuales son mis gustos|que (no )?m'agrada)$")
        if m:
            datos, gusta, nogusta, _ = self._partes(pk)
            lista = nogusta if m.group(1) else gusta
            if not lista:
                return "Todavía no me has dicho " + ("lo que no te gusta" if m.group(1) else "lo que te gusta") + \
                       ". Cuéntamelo: *«me gusta …»* / *«no me gusta …»*."
            return ("No te gusta: " if m.group(1) else "Te gusta: ") + ", ".join(lista) + "."
        if M(r"^(?:a quien conoces|quienes conoces|con quien has hablado|quienes son tus usuarios)$"):
            ps = self.personas()
            return ("Conozco a: " + ", ".join(f"**{p}**" for p in ps) + ".") if ps else \
                "Todavía no conozco a nadie. Dime *«me llamo …»* 😊"

        # ---- olvidar ----
        if M(r"^(?:olvida(?:te)? (?:todo )?(?:lo (?:que )?sabes )?(?:de|sobre) mi|olvidame|borra (?:mis datos|mi perfil)|"
             r"oblida'm|oblida tot de mi)$"):
            if not self.confirmar(f"¿Seguro que quieres que olvide todo lo que sé de {nombre or 'ti'}?"):
                return "Vale, no olvido nada 🙂"
            self._sql("DELETE FROM hechos WHERE persona=?", (pk,))
            self.cfg["nombre_usuario"] = ""
            config.guardar(self.cfg)
            return "🗑️ Hecho. Ya no recuerdo nada de ti. Si quieres, dime de nuevo *«me llamo …»*."
        m = M(r"^(?:olvida que no me gusta(?:n)?|olvida que me gusta(?:n)?|ya no me gusta(?:n)?|ja no m'agrada(?:n)?)\s+(.+)$")
        if m:
            clave = ARTICULOS.sub("", normalizar(g(m, 1)))
            q = self.quitar(pk, "gusta", clave) + self.quitar(pk, "nogusta", clave)
            return f"Hecho, ya no tengo apuntado eso ({g(m, 1)})." if q else "No tenía eso apuntado 🙂"
        m = M(r"^olvida mi\s+(.+)$")
        if m:
            q = self.quitar(pk, "dato", normalizar(g(m, 1)))
            return f"Hecho, he olvidado tu {g(m, 1)}." if q else "No tenía eso apuntado 🙂"

        # ---- quién habla ----
        m = M(r"^(?:me llamo|mi nombre es|em dic|el meu nom es|llamame|diguem|digueu-me)\s+([a-z][a-z' \-]{0,28})$")
        if not m:
            m = M(r"^(?:soy|soc|ahora habla|ara parla|habla|parla)\s+([a-z][a-z'\-]{1,20})(?:\s+(?:otra vez|de nuevo|un altre cop))?$")
            if m and not mayus(m, 1):
                m = None
        if m:
            nuevo = re.split(r"\s+(?:y|i)\s+", g(m, 1))[0]
            if 0 < len(nuevo.split()) <= 3:
                nom, conocida, migrados = self.cambiar_usuario(nuevo)
                if conocida:
                    return f"¡Hola de nuevo, **{nom}**! 👋\n\n" + self.resumen()
                extra = f" Además he asociado a tu nombre {migrados} cosas que ya me habías contado." if migrados > 1 else ""
                return (f"¡Encantada, **{nom}**! 😊 Ya sé con quién hablo y te recordaré la próxima vez.{extra}\n\n"
                        "Cuéntame cosas de ti: *«me gusta …»*, *«vivo en …»*, *«mi color favorito es …»*. "
                        "Y si eres otra persona, dime *«soy …»*.")

        # ---- gustos ----
        m = M(r"^(?:no me gusta(?:n)?|no m'agrada(?:n)?|odio|detesto|no soporto)\s+(.+)$")
        neg = bool(m)
        if not m:
            m = M(r"^(?:me gusta(?:n)?|me encanta(?:n)?|adoro|m'agrada(?:n)?|m'encanta(?:n)?|amo)\s+(.+)$")
        if m:
            items = [i.strip() for i in re.split(r"\s*,\s*|\s+y\s+|\s+i\s+", g(m, 1)) if i.strip()][:8]
            tipo, otro = ("nogusta", "gusta") if neg else ("gusta", "nogusta")
            for it in items:
                if len(it) > 60:
                    continue
                k = ARTICULOS.sub("", normalizar(it))
                self.quitar(pk, otro, k)
                self.poner(pk, tipo, k, it, ("no te gusta " if neg else "te gusta ") + it)
            return f"Apuntado ✅ Recordaré que **{'no ' if neg else ''}te gusta** {', '.join(items)}."
        m = M(r"^(?:prefiero|preferisc)\s+(.+)$")
        if m:
            v = g(m, 1)
            self.poner(pk, "dato", normalizar("prefiere " + v)[:40], v, f"prefieres {v}")
            return f"Apuntado ✅ Prefieres **{v}**."

        # ---- datos personales ----
        datos = [
            (r"^(?:vivo en|vivo a|visc a|visc en|resido en)\s+(.+)$", "ciudad", "vives en {}"),
            (r"^(?:tengo|tinc)\s+(\d{1,3})\s+(?:anos|anys)$", "edad", "tienes {} años"),
            (r"^(?:mi cumpleanos es|mi cumple es|el meu aniversari es)\s*(?:el\s+)?(.+)$", "cumpleanos", "tu cumpleaños es {}"),
            (r"^(?:trabajo (?:de|como)|treballo (?:de|com))\s+(.+)$", "trabajo", "trabajas de {}"),
            (r"^(?:trabajo en|treballo a|treballo en)\s+(.+)$", "lugar de trabajo", "trabajas en {}"),
            (r"^estudio\s+(.+)$", "estudios", "estudias {}"),
        ]
        for patron, clave, frase in datos:
            m = M(patron)
            if m:
                v = g(m, 1)
                self.poner(pk, "dato", clave, v, frase.format(v))
                return f"Apuntado ✅ {_cap(frase.format(v))}."

        # ---- preferencias sobre cómo responde ArIA ----
        m = M(r"^(?:respondeme|contestame|hablame|escribeme|responde|habla|respon-me|parla'm)\s+(?:siempre\s+)?(?:en|amb)\s+"
              r"(castellano|espanol|catalan|valenciano|ingles|frances|aleman|italiano|portugues|gallego|euskera)$")
        if m:
            idioma = IDIOMAS[m.group(1)]
            self.poner(pk, "pref", "idioma", idioma, f"quieres que te responda en {idioma}")
            return f"Apuntado ✅ Guardaré tu preferencia de idioma: **{idioma}**. Las respuestas locales disponibles se adaptarán cuando tengan traducción integrada."
        m = (M(r"^(?:se|sigues?) (?:mas |mes )?(breve|conciso|concisa|corta|corto|breu|concis|detallado|detallada|detallat)$")
             or M(r"^(?:respondeme|contestame|explicame)\s+(?:de forma |de manera |mas )?(breve|corto|corta|detallado|detallada)$")
             or M(r"^(?:quiero|prefiero|vull) (?:respuestas|respostes) (cortas|breves|largas|detalladas|curtes|llargues)$"))
        if m:
            est = ESTILOS[m.group(1)]
            self.poner(pk, "pref", "estilo", est, f"quieres respuestas {est}s")
            return f"Apuntado ✅ A partir de ahora te daré respuestas **{'más cortas' if est == 'breve' else 'más detalladas'}**."

        # ---- "mi X es Y" ----
        m = M(r"^(?:mi|mis|el meu|la meva|els meus|les meves)\s+([a-z][a-z ]{1,30}?)\s+(es|son|se llama|se llaman|es diu|es diuen)\s+(.+)$")
        if m:
            clave = m.group(1).strip()
            if clave.split()[0] not in PREGUNTA and clave not in ("nombre", "creador", "creadora"):
                verbo = {"es diu": "se llama", "es diuen": "se llaman"}.get(m.group(2), m.group(2))
                v = g(m, 3)
                self.poner(pk, "dato", clave, v, f"tu {clave} {verbo} {v}")
                return f"Apuntado ✅ Tu {clave} {verbo} **{v}**."

        # ---- consultas sobre sus datos ----
        palabras = set(re.findall(r"[a-z]+", n))
        if (texto.strip().endswith("?") or n.split()[0] in PREGUNTA) and palabras & PERSONAL:
            hallados = []
            for clave, _, frase in self.hechos(pk, "dato"):
                ct = set(re.findall(r"[a-z]+", clave)) - {"de"}
                if clave == "nombre":
                    continue
                if (ct and ct <= palabras) or (set(SIN.get(clave, [])) & palabras):
                    hallados.append(_cap(frase))
            if len(hallados) == 1:
                return hallados[0] + "."
            if hallados:
                return "\n".join(f"- {h}" for h in hallados)
            m = M(r"^(?:cual es|como se llama|cuales son|que es|cual era)\s+(?:mi|mis)\s+(.+)$")
            if m:
                return (f"Todavía no me has hablado de tu {g(m, 1)} 🙈. Dímelo con *«mi {g(m, 1)} es …»* y lo recordaré.")
        return None
