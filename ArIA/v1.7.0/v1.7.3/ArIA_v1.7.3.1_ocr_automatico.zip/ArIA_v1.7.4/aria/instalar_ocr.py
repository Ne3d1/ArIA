"""Instala automáticamente los datos OCR españoles e ingleses de Tesseract.

Tesseract es un ejecutable externo; pytesseract por sí solo no incluye los
modelos de idioma. Este módulo descarga únicamente los .traineddata ausentes
al directorio tessdata que usa la instalación detectada.
"""
from __future__ import annotations

import argparse
import os
import shutil
import re
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path

IDIOMAS = ("spa", "eng")
BASE_URL = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/{}.traineddata"


def buscar_tesseract(explicito: str | None = None) -> str | None:
    """Busca el binario respetando TESSERACT_CMD y rutas estándar."""
    if explicito:
        p = Path(explicito.strip().strip('"'))
        if p.is_file():
            return str(p)
    from .pantalla import _buscar_ejecutable_tesseract
    return _buscar_ejecutable_tesseract()


def directorio_tessdata(ejecutable: str) -> Path:
    """Obtiene el directorio efectivo desde el propio binario Tesseract."""
    # --list-langs incluye el directorio efectivo en su primera línea en
    # las versiones habituales de Tesseract 4/5 (no existe una opción
    # --print-tessdata-dir universal entre builds).
    proc = subprocess.run(
        [ejecutable, "--list-langs"], capture_output=True,
        text=True, encoding="utf-8", errors="replace", timeout=20,
    )
    salida = (proc.stdout or "") + "\n" + (proc.stderr or "")
    coincidencia = re.search(r'List of available languages in ["\'](.+?)["\']', salida, re.IGNORECASE)
    if coincidencia:
        candidato = Path(coincidencia.group(1).strip())
        if candidato.is_dir():
            return candidato

    # Fallback para builds de Windows que no imprimen el directorio.
    exe = Path(ejecutable).resolve()
    candidatos = [exe.parent / "tessdata", exe.parent.parent / "tessdata"]
    prefijo = os.environ.get("TESSDATA_PREFIX")
    if prefijo:
        candidatos.insert(0, Path(prefijo))
        candidatos.insert(0, Path(prefijo) / "tessdata")
    for candidato in candidatos:
        if candidato.is_dir():
            return candidato
    raise RuntimeError(
        "No pude localizar la carpeta tessdata de Tesseract. "
        "Comprueba la instalación o define TESSDATA_PREFIX."
    )


def directorio_tessdata_usuario() -> Path:
    """Directorio escribible por el usuario, sin permisos de administrador."""
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
        return base / "ArIA" / "tessdata"
    base = Path(os.environ.get("XDG_CACHE_HOME") or (Path.home() / ".cache"))
    return base / "aria" / "tessdata"


def idiomas_instalados(ejecutable: str, tessdata: Path | None = None) -> set[str]:
    comando = [ejecutable]
    if tessdata is not None:
        comando.extend(["--tessdata-dir", str(tessdata)])
    comando.append("--list-langs")
    proc = subprocess.run(
        comando, capture_output=True,
        text=True, encoding="utf-8", errors="replace", timeout=20,
    )
    texto = (proc.stdout or "") + "\n" + (proc.stderr or "")
    return {line.strip() for line in texto.splitlines() if line.strip() in IDIOMAS}


def descargar_modelo(codigo: str, destino: Path, timeout: int = 90) -> None:
    """Descarga un modelo oficial tessdata_fast y lo instala atómicamente."""
    url = BASE_URL.format(codigo)
    req = urllib.request.Request(url, headers={"User-Agent": "ArIA-OCR-setup/1.7.4"})
    destino.parent.mkdir(parents=True, exist_ok=True)
    temporal = None
    try:
        with urllib.request.urlopen(req, timeout=timeout) as respuesta:
            datos = respuesta.read()
        # Los modelos oficiales son binarios de cientos de KB/varios MB.
        if len(datos) < 100_000:
            raise RuntimeError(f"El archivo descargado para {codigo} parece incompleto ({len(datos)} bytes).")
        fd, nombre = tempfile.mkstemp(prefix=f".{codigo}-", suffix=".tmp", dir=str(destino.parent))
        temporal = Path(nombre)
        with os.fdopen(fd, "wb") as f:
            f.write(datos)
        temporal.replace(destino)
        temporal = None
    finally:
        if temporal is not None:
            try:
                temporal.unlink(missing_ok=True)
            except OSError:
                pass


def reparar_ocr(tesseract: str | None = None, *, descargar=True) -> tuple[bool, str]:
    ejecutable = buscar_tesseract(tesseract)
    if not ejecutable:
        return False, (
            "Tesseract OCR no está instalado. Ejecuta setup.bat con conexión a Internet "
            "para instalarlo automáticamente."
        )
    try:
        origen = directorio_tessdata(ejecutable)
        # No escribir en Program Files: Windows suele proteger esa carpeta.
        # ArIA mantiene sus modelos en LocalAppData y los pasa con --tessdata-dir.
        datos = directorio_tessdata_usuario()
        datos.mkdir(parents=True, exist_ok=True)
        presentes = idiomas_instalados(ejecutable, datos)
        faltan = [idioma for idioma in IDIOMAS if idioma not in presentes or not (datos / f"{idioma}.traineddata").is_file()]
        if not faltan:
            return True, f"OCR listo. Idiomas disponibles: spa, eng. Datos: {datos}"
        if not descargar:
            return False, "Faltan modelos OCR: " + ", ".join(faltan)
        instalados = []
        for idioma in faltan:
            destino = datos / f"{idioma}.traineddata"
            original = origen / f"{idioma}.traineddata"
            if original.is_file():
                shutil.copy2(original, destino)
                print(f"Copiando modelo OCR existente: {idioma}", flush=True)
            else:
                print(f"Descargando modelo OCR {idioma}...", flush=True)
                descargar_modelo(idioma, destino)
            instalados.append(idioma)
        # Verifica con el binario y el directorio privado que usará ArIA.
        finales = idiomas_instalados(ejecutable, datos)
        aun_faltan = sorted(set(IDIOMAS) - finales)
        if aun_faltan:
            return False, (
                "Se prepararon los modelos, pero Tesseract aún no los reconoce: "
                + ", ".join(aun_faltan) + f". Directorio de ArIA: {datos}"
            )
        return True, "Idiomas OCR preparados automáticamente: " + ", ".join(instalados) + f". Datos: {datos}"
    except Exception as exc:
        return False, (
            f"No pude instalar automáticamente los idiomas OCR: {exc}. "
            "Comprueba la conexión a Internet y los permisos de escritura en la carpeta tessdata."
        )


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Repara los idiomas de Tesseract para ArIA")
    parser.add_argument("--tesseract", help="Ruta a tesseract.exe")
    args = parser.parse_args(argv)
    ok, mensaje = reparar_ocr(args.tesseract)
    print(("[OK] " if ok else "[ERROR] ") + mensaje)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
