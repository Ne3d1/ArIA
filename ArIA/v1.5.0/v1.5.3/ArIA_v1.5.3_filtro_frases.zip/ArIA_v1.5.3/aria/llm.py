"""Compatibilidad histórica: ArIA funciona sin modelos de IA externos."""

class ErrorLLM(Exception):
    pass

SISTEMA = "ArIA utiliza razonamiento local y no conecta modelos externos."

def activo(cfg_llm=None):
    return False

def generar(*args, **kwargs):
    raise ErrorLLM("Los modelos externos están deshabilitados por diseño.")
