# Probabilidad

## Definición
La probabilidad cuantifica la incertidumbre entre 0 y 1. En un modelo equiprobable, la probabilidad de un suceso es el número de casos favorables dividido por el número de casos posibles.

## Método de trabajo
Define el espacio muestral; describe el suceso; comprueba si los resultados son equiprobables; calcula y expresa el resultado como fracción, decimal o porcentaje.

## Ejemplo explicado
En un dado equilibrado, la probabilidad de obtener un número par es 3/6 = 1/2.

## Errores y límites
No confundas probabilidad con frecuencia garantizada en pocas pruebas. Los sucesos independientes no cambian la probabilidad individual por resultados anteriores.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de probabilidad?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
