"""Punto de entrada de ArIA.  Uso:  python main.py [--cli] [--datos CARPETA]"""
import argparse
import os
import sys


def modo_cli():
    from aria import config
    from aria.cerebro import Cerebro
    from aria.memoria import Memoria

    cfg = config.cargar()
    cerebro = Cerebro(
        cfg, Memoria(),
        permiso=lambda ruta: {"s": "una", "t": "siempre"}.get(
            input(f"\n🔒 ¿Permites acceder a {ruta}? [s]í una vez / [t] siempre / [n]o: ").strip().lower()[:1], "no"),
        confirmar=lambda msg: input(f"\n{msg}\n¿Confirmas? [s/N]: ").strip().lower().startswith("s"),
        estado=lambda m: print(f"  … {m}", flush=True),
    )
    print("ArIA (modo texto). Escribe 'salir' para terminar, 'ayuda' para ver qué sé hacer.\n")
    while True:
        try:
            t = input("Tú > ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if t.lower() in ("salir", "exit", "quit"):
            break
        if t:
            print("\nArIA >\n" + cerebro.responder(t).texto + "\n")


def main():
    ap = argparse.ArgumentParser(description="ArIA, tu asistente local que aprende")
    ap.add_argument("--cli", action="store_true", help="usar el modo texto en lugar de la ventana")
    ap.add_argument("--datos", help="carpeta donde guardar memoria y chats (por defecto ./data)")
    args = ap.parse_args()
    if args.datos:
        os.environ["ARIA_DATA"] = os.path.abspath(args.datos)

    if not args.cli:
        try:
            import tkinter  # noqa: F401
        except ImportError:
            print("⚠️  Tkinter no está instalado, así que abro el modo texto.")
            print("   En Debian/Ubuntu: sudo apt install python3-tk · Fedora: sudo dnf install python3-tkinter · Arch: sudo pacman -S tk\n")
            args.cli = True
    if args.cli:
        modo_cli()
    else:
        from aria.gui import main as gui_main
        gui_main()


if __name__ == "__main__":
    sys.exit(main())
