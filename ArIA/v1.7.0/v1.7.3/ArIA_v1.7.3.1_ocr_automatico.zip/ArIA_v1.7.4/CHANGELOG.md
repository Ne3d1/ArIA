# Cambios — ArIA v1.7.4

## Corrección del OCR en Windows

- `setup.bat` ya no se limita a avisar de que faltan `spa` o `eng`: ejecuta un reparador automático.
- Nuevo módulo `aria.instalar_ocr`: detecta la carpeta de datos de Tesseract, copia los idiomas existentes y descarga los modelos ausentes desde el repositorio oficial `tessdata_fast`.
- Los datos se instalan en `%LOCALAPPDATA%\ArIA\tessdata`, por lo que no requiere permisos de escritura en `Program Files`.
- `aria.pantalla` utiliza esa carpeta mediante `--tessdata-dir` en la validación y el OCR real.
- Si no hay conexión, permisos o Tesseract no está instalado, el instalador muestra un aviso concreto y permite que el resto de ArIA continúe.

## Validación

- Suite de pruebas automatizadas ejecutada localmente.
- Las descargas se simulan en pruebas; no se descarga ningún modelo durante la suite.
- Se valida además la detección del directorio de datos con Tesseract 5.5.0 disponible en el entorno de desarrollo.
