# Bases de datos

## Definición
Una base de datos organiza información para consultarla y modificarla de forma consistente. En una base relacional, las tablas representan entidades y las relaciones conectan registros.

## Método de trabajo
Define entidades, atributos y claves; evita duplicación innecesaria; valida datos; utiliza transacciones; crea índices cuando mejoran consultas frecuentes.

## Ejemplo explicado
Una tabla de alumnos puede tener un identificador único y una tabla de matrículas puede referenciar ese identificador.

## Errores y límites
Un índice acelera ciertas consultas pero ocupa espacio y añade trabajo a las escrituras. No sustituyas copias de seguridad por índices.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de bases de datos?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
