@echo off
REM Instala todas las dependencias Python y comprueba OCR/Tkinter en Windows.
setlocal EnableExtensions
cd /d "%~dp0"
call aria_env.bat
set "VENV_PY=%ARIA_VENV_DIR%\Scripts\python.exe"
chcp 65001 >nul

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo [ERROR] No encuentro Python. Instálalo desde https://www.python.org/downloads/ marcando "Add Python to PATH".
  pause
  exit /b 1
)
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)"
if errorlevel 1 (
  echo [ERROR] Necesito Python 3.9 o superior.
  pause
  exit /b 1
)

if not exist "%VENV_PY%" (
  echo [1/4] Creando entorno virtual en "%ARIA_VENV_DIR%" ...
  if not exist "%ARIA_VENV_DIR%" mkdir "%ARIA_VENV_DIR%"
  %PY% -m venv "%ARIA_VENV_DIR%"
  if errorlevel 1 (
    echo [ERROR] No pude crear el entorno virtual.
    pause
    exit /b 1
  )
)

echo [2/4] Instalando dependencias de requirements.txt ...
"%VENV_PY%" -m pip install --upgrade pip
if errorlevel 1 goto :error
"%VENV_PY%" -m pip install -r requirements.txt --extra-index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto :error
"%VENV_PY%" -m pip check
if errorlevel 1 goto :error

"%VENV_PY%" -c "import importlib.util,sys; mods=['requests','bs4','ddgs','sympy','pypdf','docx','mss','PIL','pytesseract','psutil','pygetwindow','rapidfuzz','torch']; missing=[m for m in mods if importlib.util.find_spec(m) is None]; print('[ERROR] Faltan: '+', '.join(missing)) if missing else print('[OK] Todas las dependencias Python están instaladas.'); sys.exit(bool(missing))"
if errorlevel 1 goto :error

echo [3/4] Comprobando Tesseract OCR ...
where tesseract >nul 2>nul
if errorlevel 1 (
  echo [AVISO] Tesseract no está instalado. Solo afecta al OCR de pantalla.
  where winget >nul 2>nul
  if not errorlevel 1 (
    choice /C SN /N /M "¿Quieres instalar Tesseract OCR con winget? [S/N] "
    if errorlevel 2 goto :ocr_done
    winget install --id UB-Mannheim.TesseractOCR --exact --accept-package-agreements --accept-source-agreements
    if errorlevel 1 echo [AVISO] No se pudo instalar Tesseract automáticamente.
  ) else (
    echo Instálalo desde https://github.com/UB-Mannheim/tesseract/wiki
  )
) else (
  set "OCR_LANGS_OK=1"
  tesseract --list-langs 2>nul | findstr /X /C:"spa" >nul || set "OCR_LANGS_OK=0"
  tesseract --list-langs 2>nul | findstr /X /C:"eng" >nul || set "OCR_LANGS_OK=0"
  if "%OCR_LANGS_OK%"=="0" echo [AVISO] Faltan los idiomas spa o eng en Tesseract.
  if "%OCR_LANGS_OK%"=="1" echo [OK] Tesseract detectado con spa y eng.
)
:ocr_done

echo [4/4] Comprobando Tkinter ...
"%VENV_PY%" -c "import tkinter" 2>nul
if errorlevel 1 echo [AVISO] Falta Tkinter/Tcl-Tk. Repara la instalación de Python incluyendo Tcl/Tk.
echo.
echo Preparación terminada. Entorno: "%ARIA_VENV_DIR%"
echo Ejecuta run.bat (ventana) o run.bat --cli (terminal).
pause
exit /b 0

:error
echo [ERROR] Falló la instalación o comprobación de dependencias. Revisa la conexión y vuelve a ejecutar setup.bat.
pause
exit /b 1
