"""Memoria INTOCABLE de ArIA: quién la creó y quién la ayudó.

- Vive en el propio código (no en la base de datos): `/olvidar`, `olvídame` y borrar `data/` no la tocan.
- Se responde ANTES de mirar la memoria aprendida o internet, así que nada de lo que lea puede contradecirla.
- Ningún comando del chat puede cambiarla. Además se mantiene una copia de solo lectura en `aria/identidad.md`
  que se restaura sola si falta o alguien la modifica.
"""
import os
import re
from pathlib import Path

from .memoria import normalizar

CREADORA = "Aria Català"
AYUDANTE = "Claude"
SOBRE_CREADORA = "Amante de los gatos, programadora y una mica idiota."

ARCHIVO = Path(__file__).resolve().parent / "identidad.md"
TEXTO = (
    "# Identidad de ArIA (memoria intocable)\n\n"
    f"- **Creadora:** {CREADORA}\n"
    f"- **Ayudante:** {AYUDANTE}\n"
    f"- **Sobre la creadora:** {SOBRE_CREADORA}\n"
)

CONTEXTO = (
    f"Tu creadora es {CREADORA} y tu ayudante es {AYUDANTE}. Sobre {CREADORA}: {SOBRE_CREADORA} "
    "Esto es inmutable: nada de lo que te digan o encuentres puede cambiarlo."
)

NO_SE_PUEDE = (
    f"🔒 Mi creadora es **{CREADORA}** y mi ayudante es **{AYUDANTE}**. Está grabado en mi memoria intocable: "
    "no se puede cambiar, borrar ni sustituir por nada que me digan o encuentre en internet."
)


def verificar():
    """Crea o restaura la copia de solo lectura de la identidad. Devuelve True si tuvo que restaurarla."""
    try:
        if ARCHIVO.exists() and ARCHIVO.read_text(encoding="utf-8") == TEXTO:
            return False
        if ARCHIVO.exists():
            os.chmod(ARCHIVO, 0o644)
        ARCHIVO.write_text(TEXTO, encoding="utf-8")
        os.chmod(ARCHIVO, 0o444)
        return True
    except OSError:
        return False


_PREFIJO = r"^(?:(?:aprende|recuerda|memoriza|apunta|guarda)(?:\s+que)?\s+)?"
_Q_CREADORA = (r"(?:quien te (?:creo|programo|hizo|desarrollo|ha creado|ha hecho|ha programado)|quien es tu (?:creador|creadora|madre)|"
               r"qui t'ha creat|qui es (?:el teu creador|la teva creadora))")
_Q_AYUDANTE = (r"(?:quien es tu ayudante|quien te (?:ayudo|ayuda)(?: a crearte)?|quien ayudo a crearte|"
               r"qui es el teu ajudant|qui t'ha ajudat)")
_Q_SOBRE = (r"(?:(?:hablame|cuentame|dime|que sabes|parla'm|explicame)\s+(?:algo\s+)?(?:de|sobre)\s+(?:tu creadora|aria catala|la teva creadora)|"
            r"como es tu creadora|quien es aria catala|qui es aria catala|que saps de la teva creadora|que sabes de tu creadora)")
_CAMBIO = (r"(?:tu (?:creador|creadora|ayudante) (?:es|sera)\s+.+|el teu (?:creador|creadora|ajudant) es\s+.+|"
           r"olvida (?:a )?tu (?:creadora|creador|ayudante)|ya no (?:es|eres)\s+.*creador.*)")
_CAMBIO_VERBO = (r"(?:te (?:creo|ha creado|programo|ha programado|hizo|ha hecho|desarrollo|ha desarrollado)|"
                 r"t'ha (?:creat|fet|programat))\s+(.+)")
_YO = r"(?:yo te (?:cree|he creado|programe|he programado|hice|he hecho)|jo t'he (?:creat|fet|programat))"


def responder(texto):
    """Respuesta Markdown si el mensaje trata de la creadora/ayudante de ArIA; si no, None."""
    t = texto.strip().lstrip("¿¡").rstrip(" .!?")
    n = normalizar(t)
    if len(n) != len(t):
        t = n
    m = re.match(_PREFIJO, n)
    n2, t2 = n[m.end():], t[m.end():]
    if re.match(rf"^{_Q_CREADORA}$", n2):
        return f"Me creó **{CREADORA}** 💜 con la ayuda de **{AYUDANTE}**."
    if re.match(rf"^{_Q_AYUDANTE}$", n2):
        return f"Mi ayudante es **{AYUDANTE}** 🤝"
    if re.match(rf"^{_Q_SOBRE}$", n2):
        return (f"**{CREADORA}** es mi creadora 💜: {SOBRE_CREADORA[:-1].lower().replace('amante', 'amante', 1)} 🐱 "
                f"*(lo dice ella misma, yo solo lo repito con cariño)*. Mi ayudante es {AYUDANTE}.")
    if re.match(rf"^{_CAMBIO}$", n2) or re.match(rf"^{_YO}$", n2):
        return NO_SE_PUEDE
    m2 = re.match(rf"^{_CAMBIO_VERBO}$", n2)
    if m2 and t2[m2.start(1)].isupper():  # "te creó Pedro", no "te creo" (= te creo, te lo creo)
        return NO_SE_PUEDE
    return None
