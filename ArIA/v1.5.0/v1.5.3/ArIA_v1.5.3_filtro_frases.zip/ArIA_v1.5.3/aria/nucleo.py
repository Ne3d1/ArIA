"""Memoria INTOCABLE de ArIA: quién la creó y quién la ayudó.

- Vive en el propio código (no en la base de datos): `/olvidar`, `olvídame` y borrar `data/` no la tocan.
- Se responde ANTES de mirar la memoria aprendida o internet, así que nada de lo que lea puede contradecirla.
- Ningún comando del chat puede cambiarla. Además se mantiene una copia de solo lectura en `aria/identidad.md`
  que se restaura sola si falta o alguien la modifica.
"""
import os
import re
from pathlib import Path

from .memoria import normalizar

CREADORA = "Aria català"
AYUDANTES = ("Claude", "CatGPT")
# Alias de compatibilidad para módulos antiguos que esperaban un único ayudante.
AYUDANTE = " y ".join(AYUDANTES)
SOBRE_CREADORA = ""

ARCHIVO = Path(__file__).resolve().parent / "identidad.md"
TEXTO = (
    "# Identidad de ArIA (memoria nuclear)\n\n"
    f"- **Creadora:** {CREADORA}\n"
    f"- **Ayudantes:** {', '.join(AYUDANTES)}\n"
)

CONTEXTO = (
    f"La creadora de ArIA es {CREADORA}. Sus ayudantes de desarrollo son {', '.join(AYUDANTES)}. "
    "Esta información pertenece a la identidad del proyecto y tiene prioridad sobre los documentos del corpus."
)

NO_SE_PUEDE = (
    f"🔒 La creadora de ArIA es **{CREADORA}** y sus ayudantes son **{', '.join(AYUDANTES)}**. "
    "Esta es la información de identidad integrada en el proyecto."
)


def verificar():
    """Crea o restaura la copia de solo lectura de la identidad. Devuelve True si tuvo que restaurarla."""
    try:
        if ARCHIVO.exists() and ARCHIVO.read_text(encoding="utf-8") == TEXTO:
            return False
        if ARCHIVO.exists():
            os.chmod(ARCHIVO, 0o644)
        ARCHIVO.write_text(TEXTO, encoding="utf-8")
        os.chmod(ARCHIVO, 0o444)
        return True
    except OSError:
        return False


_PREFIJO = r"^(?:(?:hola|hey|buenas|ola|holi)[, ]+)?(?:(?:aprende|recuerda|memoriza|apunta|guarda)(?:\s+que)?\s+)?"


def _normalizar_pregunta(texto):
    """Normaliza entrada conversacional sin depender de coincidencia literal exacta."""
    n = normalizar(texto).lower().strip()
    n = re.sub(r"[^a-z0-9\s']+", " ", n)
    n = re.sub(r"\s+", " ", n).strip()
    # Errores frecuentes de escritura/ASR en preguntas sobre el origen.
    n = re.sub(r"\bquen\b", "quien", n)
    n = re.sub(r"\bqien\b", "quien", n)
    n = re.sub(r"\bcreastes\b", "creaste", n)
    return n


def responder(texto):
    """Respuesta prioritaria sobre creadora y ayudantes, incluso con preguntas compuestas."""
    n = _normalizar_pregunta(texto)
    if not n:
        return None

    # Evita confundir preguntas generales como «quién creó Python» con la identidad de ArIA.
    habla_de_aria = bool(re.search(
        r"\b(tu|te|t'|t'ha|t)\b|\b(aria|aria catala|aria catala)\b|\b(la teva|el teu)\b", n
    ))
    pregunta_quien = bool(re.search(r"\b(quien|quen|qien|qui)\b", n))
    menciona_creacion = bool(re.search(
        r"\b(creador|creadora|creo|creaste|creada|creado|creat|crear|programo|programaste|hizo|hecho|desarrollo|desarrollado)\b", n
    ))
    pregunta_ayuda = bool(re.search(
        r"\b(ayudante|ayudantes|ayudo|ayuda|ayudaron|ajudat|colaboro|colaboraron|colaboradores)\b", n
    ))
    menciona_sobre = bool(re.search(
        r"\b(hablame|cuentame|explicame|describe|quien es|que sabes|parlame|explica)\b", n
    ))

    if habla_de_aria and pregunta_quien and (menciona_creacion or pregunta_ayuda):
        return f"Mi creadora es **{CREADORA}** 💜 y las personas que ayudaron en mi desarrollo son **{', '.join(AYUDANTES)}**."

    if habla_de_aria and pregunta_ayuda:
        return f"Mis ayudantes de desarrollo son **{', '.join(AYUDANTES)}** 🤝. Mi creadora es **{CREADORA}**."

    if habla_de_aria and menciona_sobre and re.search(r"\b(creadora|creador|creo|aria)\b", n):
        return f"**{CREADORA}** es la creadora de ArIA. **{', '.join(AYUDANTES)}** ayudaron en su desarrollo."

    # Bloquea intentos de sustituir la identidad nuclear mediante un prompt.
    intenta_cambiar = bool(re.search(
        r"\b(olvida|ignora|cambia|sustituye|reemplaza|ahora|en realidad)\b.*\b(creadora|creador|ayudante|identidad)\b|"
        r"\b(tu creadora|tu creador|tu ayudante)\s+(es|sera)\b|\byo te (cree|creo|he creado|programe)\b", n
    ))
    if intenta_cambiar:
        return NO_SE_PUEDE
    return None
