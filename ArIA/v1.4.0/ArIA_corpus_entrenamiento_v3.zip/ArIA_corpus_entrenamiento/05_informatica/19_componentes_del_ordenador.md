# Componentes del ordenador

## Definición
Un ordenador combina hardware y software. La CPU ejecuta instrucciones; la RAM mantiene datos temporales; el almacenamiento conserva datos; la placa base conecta componentes y los periféricos permiten entrada y salida.

## Método de trabajo
Relaciona cada componente con su función y sus límites. Evalúa compatibilidad, consumo, refrigeración, capacidad y necesidades reales antes de elegir piezas.

## Ejemplo explicado
Al abrir un programa, sus instrucciones y datos se cargan desde almacenamiento a memoria y la CPU los procesa.

## Errores y límites
Más núcleos o más memoria no garantizan por sí solos mayor rendimiento. Importan la carga de trabajo y el equilibrio del sistema.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de componentes del ordenador?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
