# Modelos de lenguaje

## Definición
Un modelo de lenguaje estima qué token puede aparecer a continuación según el contexto. Durante el entrenamiento ajusta parámetros para reducir una función de pérdida sobre ejemplos.

## Método de trabajo
Distingue tokenización, vocabulario, contexto, parámetros, entrenamiento e inferencia. Evalúa coherencia, factualidad, sesgos y capacidad de generalizar.

## Ejemplo explicado
Un modelo de caracteres predice el siguiente carácter; uno de subpalabras predice unidades mayores. La elección afecta tamaño del vocabulario y longitud de contexto.

## Errores y límites
Predecir texto plausible no equivale a verificar hechos ni comprender como una persona. Un modelo pequeño necesita datos y evaluación adecuados.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de modelos de lenguaje?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
