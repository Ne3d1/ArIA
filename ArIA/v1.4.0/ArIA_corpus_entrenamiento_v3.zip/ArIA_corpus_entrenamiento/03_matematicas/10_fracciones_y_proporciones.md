# Fracciones y proporciones

## Definición
Una fracción representa partes iguales de una unidad o el cociente entre dos números. Las fracciones equivalentes representan la misma cantidad aunque tengan numeradores y denominadores distintos.

## Método de trabajo
Para sumar o restar, utiliza denominador común. Para multiplicar, multiplica numeradores y denominadores. Para dividir, multiplica por el inverso de la segunda fracción. Simplifica cuando sea posible.

## Ejemplo explicado
Tres cuartos de 20 son 15: 20 ÷ 4 = 5 y 5 × 3 = 15.

## Errores y límites
No sumes denominadores al sumar fracciones. Comprueba si el resultado tiene sentido respecto a las cantidades iniciales.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de fracciones y proporciones?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
