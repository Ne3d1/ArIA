# Diseño de experimentos

Un experimento debe permitir responder una pregunta mediante observaciones controladas. Define variable independiente, variable dependiente y variables que deben mantenerse constantes.

Repite mediciones cuando sea posible, registra instrumentos y condiciones, conserva datos originales y describe anomalías. Un grupo de control puede ayudar a comparar, aunque su diseño depende de la pregunta.

Distingue precisión de exactitud. La precisión describe la consistencia de medidas repetidas; la exactitud, su proximidad al valor de referencia. Comunica incertidumbre y posibles fuentes de error.
