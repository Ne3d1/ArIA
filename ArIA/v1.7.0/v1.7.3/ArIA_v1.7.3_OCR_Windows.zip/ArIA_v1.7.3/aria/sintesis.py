"""Síntesis local de evidencias, independiente del tema.

No genera hechos nuevos: segmenta afirmaciones, elimina duplicados, agrupa
formulaciones parecidas y prioriza aportaciones complementarias. La coincidencia
entre dominios es una señal de corroboración, no una prueba de verdad.
"""
from __future__ import annotations

import re
import unicodedata
from urllib.parse import urlparse

_STOP = set("""el la los las un una unos unas de del al a en y o u que se su sus por con para como es son ser esta este esto estas estos ese esa eso lo le les me mi mis tu tus te nos si no mas pero ya muy sobre entre hay fue ha han he era eran cual cuales quien quienes cuando donde cuanto cuantos dime explica explicame sabes puedes podrias hablame cuentame the of and to in is are for on with it that this i you what who how""".split())
_RUIDO = re.compile(r"\b(?:escuche|escucha|siga a|síguenos|siguenos|suscr[ií]bete|spotify|apple podcasts|podcast|patrocinad[oa]|anuncio|haz clic|haga clic|leer m[aá]s|compartir en)\b", re.I)


def _normalizar(s: str) -> str:
    s = unicodedata.normalize("NFD", str(s or "").lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def _tokens(s: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9]{2,}", _normalizar(s)) if w not in _STOP}


def _frases(texto: str) -> list[str]:
    texto = re.sub(r"\s+", " ", texto or "").strip()
    partes = re.split(r"(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÜ¿¡0-9])", texto)
    salida = []
    for p in partes:
        p = p.strip(" \t-*•#")
        if len(p) < 45 or len(p.split()) < 7 or _RUIDO.search(p):
            continue
        if p.endswith(":") or len(p.split()) < 8:
            continue
        salida.append(p)
    return salida



def _polaridad(frase: str) -> bool:
    return bool(re.search(r"\b(?:no|nunca|jam[aá]s|sin|not|never)\b", _normalizar(frase)))


def _es_definicion(frase: str, consulta: str) -> bool:
    """Detecta una definición directa del sujeto preguntado, sin tema fijo."""
    sujeto = [w for w in re.findall(r"[a-z0-9]{2,}", _normalizar(consulta)) if w not in _STOP]
    palabras = re.findall(r"[a-z0-9]{2,}", _normalizar(frase))
    while palabras and palabras[0] in {"el", "la", "los", "las", "un", "una"}:
        palabras.pop(0)
    if not sujeto or palabras[:len(sujeto)] != sujeto:
        return False
    resto = palabras[len(sujeto):]
    return bool(resto and (resto[0] in {"es", "son", "consiste", "significa", "is", "are", "means"}
                           or resto[:2] in (["se", "define"], ["no", "es"], ["no", "son"])))

def _jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / max(1, len(a | b))


def _dominio(origen) -> str:
    if isinstance(origen, dict):
        url = origen.get("url", "")
    elif isinstance(origen, (tuple, list)) and origen:
        url = origen[0]
    else:
        url = str(origen or "")
    try:
        host = (urlparse(url).hostname or "").lower()
        return host.removeprefix("www.")
    except Exception:
        return ""


def consolidar(consulta: str, textos: list[str], fuentes=None, max_frases: int = 4) -> dict:
    """Extrae y consolida afirmaciones útiles de varios documentos.

    Cada texto se asocia, por posición, con una fuente. Devuelve afirmaciones
    únicas, dominios que las respaldan y métricas internas explicables.
    """
    fuentes = list(fuentes or [])
    q = _tokens(consulta)
    candidatas = []
    for i, texto in enumerate(textos or []):
        origen = fuentes[i] if i < len(fuentes) else ""
        dominio = _dominio(origen)
        for frase in _frases(texto):
            ts = _tokens(frase)
            if not ts:
                continue
            cobertura = len(q & ts) / max(1, len(q)) if q else 0.0
            # La cobertura se combina con una señal de contenido explicativo,
            # sin convertir la puntuación en una afirmación de veracidad.
            explicativa = bool(re.search(r"\b(?:es|son|consiste|utiliza|permite|puede|pueden|incluye|se produce|funciona|mediante|porque|debido|provoca|causa|significa|representa|contiene|requiere)\b", _normalizar(frase)))
            calidad = min(1.0, len(ts) / 24) * 0.12 + (0.10 if explicativa else 0)
            score = 0.78 * cobertura + calidad
            candidatas.append({"texto": frase, "tokens": ts, "score": score,
                               "dominio": dominio, "indice": i})

    candidatas.sort(key=lambda x: x["score"], reverse=True)
    grupos = []
    for c in candidatas:
        mejor = None
        mejor_sim = 0.0
        for g in grupos:
            inter = len(c["tokens"] & g["tokens"])
            sim = max(_jaccard(c["tokens"], g["tokens"]), inter / max(1, min(len(c["tokens"]), len(g["tokens"]))))
            ambas_definiciones = _es_definicion(c["texto"], consulta) and _es_definicion(g["texto"], consulta)
            if ambas_definiciones and _polaridad(c["texto"]) != _polaridad(g["texto"]):
                sim = 0.0  # conservar afirmaciones con polaridad opuesta para no ocultar conflictos
            elif ambas_definiciones and inter / max(1, min(len(c["tokens"]), len(g["tokens"]))) >= 0.30:
                sim = 1.0  # una única definición principal, aunque se redacte distinto
            if sim > mejor_sim:
                mejor, mejor_sim = g, sim
        if mejor is not None and mejor_sim >= 0.58:
            if c["dominio"]:
                mejor["dominios"].add(c["dominio"])
            # Preferir la formulación más completa, conservando una sola idea.
            if c["score"] > mejor["score"] or (c["score"] == mejor["score"] and len(c["texto"]) > len(mejor["texto"])):
                mejor.update({k: c[k] for k in ("texto", "tokens", "score", "indice")})
        else:
            grupos.append({**c, "dominios": {c["dominio"]} if c["dominio"] else set()})

    # Primero se anclan afirmaciones que mencionan directamente la consulta.
    # Después se añaden frases conectadas con sus conceptos, formando una red
    # pequeña de evidencias complementarias sin exigir repetir el tema literal.
    directas = [g for g in grupos if not q or len(q & g["tokens"]) / max(1, len(q)) >= 0.5]
    directas.sort(key=lambda x: x["score"], reverse=True)
    elegidas = []
    anclas = set()
    for g in directas:
        if len(elegidas) >= max_frases:
            break
        elegidas.append(g)
        anclas.update(g["tokens"])
    pendientes = [g for g in grupos if g not in elegidas]
    while pendientes and len(elegidas) < max_frases and anclas:
        conectadas = [g for g in pendientes if len(g["tokens"] & anclas) >= 1 and len(g["texto"].split()) >= 8]
        if not conectadas:
            break
        conectadas.sort(key=lambda x: (len(x["tokens"] & anclas), x["score"]), reverse=True)
        elegido = conectadas[0]
        elegidas.append(elegido)
        anclas.update(elegido["tokens"])
        pendientes.remove(elegido)

    if not elegidas:
        elegidas = [g for g in grupos if g["score"] >= 0.12][:max_frases]

    return {
        "afirmaciones": [g["texto"] for g in elegidas],
        "corroboradas": [g for g in elegidas if len(g["dominios"]) >= 2],
        "dominios": sorted({d for g in elegidas for d in g["dominios"]}),
        "total_candidatas": len(candidatas),
        "total_unicas": len(grupos),
    }
