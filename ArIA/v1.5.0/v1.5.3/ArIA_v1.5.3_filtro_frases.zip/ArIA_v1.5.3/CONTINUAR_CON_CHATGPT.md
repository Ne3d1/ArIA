# Continuidad del proyecto — ArIA v1.5.3

## Estado de esta versión

La v1.5.3 parte de v1.5.2. Añade filtrado a nivel de frase tras la selección de páginas: descarta promociones/podcasts, exige vínculo temático directo y, para «qué es», una frase definitoria explícita. La memoria solo recibe frases seleccionadas, no páginas enteras. Si falta una definición, ArIA no improvisa con menciones incidentales.

## Pruebas

`python -m unittest discover -q` ejecutado en el paquete: 66 pruebas superadas. También deben ejecutarse `./test.sh` en Linux y `test.bat` en Windows tras instalar dependencias. No se ha validado aquí una búsqueda real en Internet; los tests de integración web usan respuestas simuladas.

## Próximo trabajo

1. Evaluar búsquedas reales con un conjunto de consultas en español y catalán.
2. Extraer afirmaciones atómicas y vincularlas a pasajes concretos de cada URL.
3. Contrastar afirmaciones entre dominios independientes y detectar contradicciones.
4. Guardar conocimiento estructurado con fecha, fuente, fragmento, idioma y estado de verificación.
5. No usar porcentajes de similitud como probabilidad de verdad.

Mantener las reglas del proyecto: funcionamiento local, sin APIs de modelos generativos externos; memoria/RAG no equivale a entrenamiento neuronal; conservar identidad de ArIA y pruebas de regresión; no afirmar pruebas no realizadas.
