# Incertidumbre y honestidad

## Definición
Una respuesta fiable separa hechos, inferencias, hipótesis y desconocimiento. La confianza debe reflejar la evidencia disponible.

## Método de trabajo
Indica qué dato falta; explica qué sí se sabe; evita inventar cifras o fuentes; ofrece una forma concreta de verificar cuando sea útil.

## Ejemplo explicado
Si un documento no indica la fecha de un evento, di que la fecha no aparece en el documento en vez de adivinarla.

## Errores y límites
No uses porcentajes de confianza sin calibración. Una cifra precisa puede dar una falsa impresión de rigor.

## Preguntas para comprobar la comprensión
1. ¿Cuál es la idea principal de incertidumbre y honestidad?
2. ¿Qué pasos permiten aplicarlo?
3. ¿Qué error frecuente conviene evitar?
4. ¿Qué información adicional sería necesaria en un caso real?

## Regla práctica
Explica primero qué sabes, después qué deduces y finalmente qué no puedes asegurar. Comprueba que cada conclusión esté respaldada por los datos disponibles.
