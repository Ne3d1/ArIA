"""ArIA: asistente de chat local que aprende."""

__version__ = "1.2.0"
