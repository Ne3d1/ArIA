"""Funciones opcionales para inspeccionar ventanas y leer texto de pantalla.

No guarda capturas ni las transmite. La captura y el OCR se ejecutan localmente;
la aplicación debe pedir permiso explícito antes de cada inspección.
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
from pathlib import Path


def programas_abiertos(limite=35):
    """Devuelve procesos visibles/activos sin argumentos ni datos de usuario."""
    try:
        import psutil
    except ImportError:
        return [], "Falta psutil. Ejecuta setup para instalar dependencias."

    resultados = []
    vistos = set()
    try:
        for p in psutil.process_iter(["name", "status"]):
            try:
                nombre = (p.info.get("name") or "").strip()
                if nombre and nombre.lower() not in vistos:
                    vistos.add(nombre.lower())
                    resultados.append(nombre)
            except (psutil.Error, OSError):
                continue
    except psutil.Error as e:
        return [], f"No pude consultar los procesos: {e}"
    return sorted(resultados, key=str.casefold)[:limite], None


def ventanas_abiertas():
    """Intenta recuperar títulos de ventanas; depende de soporte del sistema."""
    try:
        import pygetwindow
        titulos = [x.title.strip() for x in pygetwindow.getAllWindows() if x.title.strip()]
        return list(dict.fromkeys(titulos)), None
    except Exception as e:
        return [], f"No se pudieron leer los títulos de ventana en este sistema ({e})."


def _buscar_ejecutable_tesseract():
    """Localiza Tesseract aunque Windows no haya actualizado PATH."""
    indicado = os.environ.get("TESSERACT_CMD", "").strip().strip('"')
    if indicado and Path(indicado).is_file():
        return str(Path(indicado))

    encontrado = shutil.which("tesseract")
    if encontrado:
        return encontrado

    if os.name == "nt":
        bases = [
            os.environ.get("ProgramFiles", r"C:\Program Files"),
            os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
            os.environ.get("LOCALAPPDATA", ""),
        ]
        candidatos = [base.rstrip("\\/") + r"\Tesseract-OCR\tesseract.exe"
                      for base in bases if base]
        local = os.environ.get("LOCALAPPDATA", "")
        if local:
            candidatos.append(local.rstrip("\\/") + r"\Programs\Tesseract-OCR\tesseract.exe")
        candidatos.extend([
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        ])
        for candidato in candidatos:
            if Path(candidato).is_file():
                return candidato
    return None


def configurar_tesseract(pytesseract):
    """Configura pytesseract y devuelve la ruta encontrada o None."""
    ejecutable = _buscar_ejecutable_tesseract()
    if ejecutable:
        pytesseract.pytesseract.tesseract_cmd = ejecutable
    return ejecutable


def leer_pantalla():
    """Captura la pantalla principal en memoria y extrae texto mediante Tesseract."""
    try:
        import mss
        from PIL import Image
    except ImportError:
        raise RuntimeError("Faltan mss o Pillow. Ejecuta setup para instalar las dependencias.")
    try:
        import pytesseract
    except ImportError:
        raise RuntimeError("Falta pytesseract. Ejecuta setup para instalar las dependencias Python.")

    ejecutable = configurar_tesseract(pytesseract)
    if not ejecutable:
        raise RuntimeError(
            "No encuentro Tesseract OCR. Instálalo desde "
            "https://github.com/UB-Mannheim/tesseract/wiki y reinicia ArIA. "
            "Si está instalado en otra carpeta, define TESSERACT_CMD con la ruta completa "
            "a tesseract.exe."
        )

    try:
        idiomas = set(pytesseract.get_languages(config=""))
        faltan = {"spa", "eng"} - idiomas
        if faltan:
            raise RuntimeError(
                "Tesseract está instalado, pero faltan los idiomas: " + ", ".join(sorted(faltan)) +
                ". Reinstala Tesseract incluyendo Spanish y English en Additional language data."
            )
    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError("He encontrado Tesseract, pero no puedo consultar sus idiomas: " + str(e))

    with mss.mss() as sct:
        monitor = sct.monitors[1]  # monitor principal; no captura todos los monitores
        shot = sct.grab(monitor)
        img = Image.frombytes("RGB", shot.size, shot.rgb)
    try:
        texto = pytesseract.image_to_string(img, lang="spa+eng")
    except Exception as e:
        raise RuntimeError("Tesseract está localizado, pero ha fallado el OCR: " + str(e))
    # La imagen se descarta al salir; no se escribe a disco.
    return texto.strip(), img.size
