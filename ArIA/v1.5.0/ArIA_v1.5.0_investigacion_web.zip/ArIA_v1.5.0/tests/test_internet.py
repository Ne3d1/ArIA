import copy
import tempfile
import unittest
from unittest.mock import patch

from aria import web
from aria.cerebro import Cerebro, quiere_busqueda_web
from aria.config import DEFAULTS
from aria.memoria import Memoria


class SeguridadWeb(unittest.TestCase):
    def test_bloquea_destinos_locales_y_privados(self):
        for url in ("http://127.0.0.1/", "http://192.168.1.2/", "http://localhost/",
                    "file:///etc/passwd", "http://10.0.0.1:8080/"):
            with self.subTest(url=url):
                self.assertFalse(web.validar_url(url))

    @patch("aria.web.socket.getaddrinfo")
    def test_dominio_publico_se_permite(self, dns):
        dns.return_value = [(None, None, None, None, ("93.184.216.34", 0))]
        self.assertTrue(web.validar_url("https://example.org/path"))

    @patch("aria.web.socket.getaddrinfo")
    def test_dominio_que_resuelve_a_ip_privada_se_bloquea(self, dns):
        dns.return_value = [(None, None, None, None, ("127.0.0.1", 0))]
        self.assertFalse(web.validar_url("https://evil.example/path"))

    @patch("aria.web.requests.get")
    @patch("aria.web.validar_url", return_value=True)
    def test_redireccion_se_revalida(self, validar, get):
        import requests
        from unittest.mock import Mock
        redir = Mock()
        redir.is_redirect = True
        redir.is_permanent_redirect = False
        redir.headers = {"location": "http://127.0.0.1/secret"}
        ok = Mock()
        ok.is_redirect = False
        ok.is_permanent_redirect = False
        ok.raise_for_status.return_value = None
        get.side_effect = [redir, ok]
        validar.side_effect = [True, False]
        with self.assertRaises(web.ErrorWeb):
            web._get_publico("https://example.org")


class BusquedaWeb(unittest.TestCase):
    @patch("aria.web.leer_pagina")
    @patch("aria.web.wikipedia")
    @patch("aria.web.duckduckgo")
    @patch("aria.web.validar_url", return_value=True)
    def test_busqueda_combina_fuentes_y_deduplica(self, validar, ddg, wiki, leer):
        ddg.return_value = [
            {"titulo": "Ordenadores", "url": "https://example.org/ordenadores?utm_source=x", "resumen": "Resumen suficientemente largo sobre ordenadores y sus componentes."},
            {"titulo": "Duplicado", "url": "https://example.org/ordenadores", "resumen": "Duplicado."},
        ]
        wiki.return_value = [{"titulo": "Computadora", "url": "https://es.wikipedia.org/wiki/Computadora", "texto": "Una computadora es una máquina electrónica." * 10}]
        leer.side_effect = [("Ordenadores", "Un ordenador procesa datos y ejecuta instrucciones. " * 8),
                            ("Computadora", "Una computadora es una máquina electrónica. " * 8)]
        fuentes = web.buscar("qué es un ordenador", paginas=2)
        self.assertGreaterEqual(len(fuentes), 1)
        self.assertTrue(all(len(f["texto"]) > 40 for f in fuentes))
        self.assertEqual(len({f["url"] for f in fuentes}), len(fuentes))

    def test_busqueda_rechaza_consulta_vacia(self):
        with self.assertRaises(web.ErrorWeb):
            web.buscar("  ")


class IntegracionInvestigacion(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.mem = Memoria(ruta=f"{self.tmp.name}/memoria.db")
        self.cfg = copy.deepcopy(DEFAULTS)
        self.cfg["aprender_de_internet"] = True
        self.cerebro = Cerebro(self.cfg, self.mem)

    def tearDown(self):
        self.mem.bd.close()
        self.tmp.cleanup()

    @patch("aria.cerebro.web.buscar")
    def test_investiga_guarda_contenido_y_muestra_fuentes(self, buscar):
        buscar.return_value = [{"titulo": "Fuente técnica", "url": "https://example.org/cpu",
                                "texto": "Un procesador ejecuta instrucciones y coordina operaciones del ordenador. "
                                        "La unidad de control dirige el flujo de datos y la unidad aritmético lógica "
                                        "realiza operaciones matemáticas y lógicas."}]
        r = self.cerebro.responder("investiga cómo funciona un procesador")
        self.assertEqual(r.origen, "web")
        self.assertIn("example.org/cpu", r.texto)
        self.assertIn("fragmentos nuevos", r.texto)
        self.assertGreaterEqual(len(self.mem.buscar("procesador instrucciones", k=3)), 1)

    @patch("aria.cerebro.web.buscar")
    def test_comando_investiga(self, buscar):
        buscar.return_value = [{"titulo": "Fuente", "url": "https://example.org/a",
                                "texto": "La memoria RAM almacena temporalmente datos e instrucciones que necesita la CPU." * 3}]
        r = self.cerebro.responder("/investiga memoria RAM")
        self.assertEqual(r.origen, "web")


    @patch("aria.cerebro.web.buscar")
    def test_aprende_de_internet_guarda_y_lo_anuncia(self, buscar):
        buscar.return_value = [{"titulo": "Fuente de RAM", "url": "https://example.org/ram",
                                "texto": "La memoria RAM es memoria volátil que conserva temporalmente "
                                        "los datos y programas que utiliza el procesador." * 3}]
        r = self.cerebro.responder("aprende de internet sobre memoria RAM")
        self.assertEqual(r.origen, "web")
        self.assertIn("He aprendido esto", r.texto)
        self.assertGreaterEqual(len(self.mem.buscar("memoria RAM volátil", k=3)), 1)

    @patch("aria.cerebro.web.buscar")
    def test_busqueda_automatica_si_no_hay_evidencia_local(self, buscar):
        self.cfg["buscar_automaticamente_si_no_sabe"] = True
        buscar.return_value = [{"titulo": "Fuente", "url": "https://example.org/termica",
                                "texto": "La conducción térmica es la transferencia de energía "
                                        "por contacto entre cuerpos a distinta temperatura." * 3}]
        r = self.cerebro.responder("¿Qué es la conducción térmica?")
        self.assertEqual(r.origen, "web")
        buscar.assert_called_once()

    @patch("aria.cerebro.web.buscar")
    def test_no_busca_automaticamente_si_ya_hay_respuesta_local(self, buscar):
        self.cfg["buscar_automaticamente_si_no_sabe"] = True
        self.mem.aprender_texto("La fotosíntesis es el proceso por el que las plantas convierten luz en energía química.",
                                fuente="test", titulo="Fotosíntesis")
        self.cerebro.responder("¿Qué es la fotosíntesis?")
        buscar.assert_not_called()

    def test_detecta_intenciones_de_busqueda(self):
        for q in ("investiga procesadores", "consulta en internet la fotosíntesis",
                  "busca en la web Python", "dame el enlace de la web oficial de Python"):
            self.assertTrue(quiere_busqueda_web(q), q)


if __name__ == "__main__":
    unittest.main()
