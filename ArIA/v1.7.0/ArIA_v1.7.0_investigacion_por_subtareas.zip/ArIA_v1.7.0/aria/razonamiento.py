"""Motor de razonamiento y composición local de ArIA.

No usa redes neuronales, modelos descargados ni servicios remotos. Combina
recuperación léxica, expansión semántica explícita, análisis de intención,
selección de evidencias y composición por estructuras discursivas.
"""
from __future__ import annotations

import re
import unicodedata
from collections import Counter

from . import sintesis

try:
    from rapidfuzz import fuzz
except ImportError:  # pragma: no cover - fallback sin dependencia opcional
    fuzz = None

_STOP = set("""el la los las un una unos unas de del al a en y o u que se su sus por con para como es son ser
esta este esto estas estos ese esa eso lo le les me mi mis tu tus te nos si no mas pero ya muy sobre entre hay
fue ha han he era eran cual cuales quien quienes cuando donde cuanto cuantos dime explica explicame sabes puedes
podrias hablame cuentame the of and to in is are for on with it that this i you what who how amb per com""".split())

# Expansiones transparentes, pequeñas y editables. No son embeddings ni un modelo.
_SINONIMOS = {
    "ordenador": {"computadora", "pc", "equipo", "ordinador"}, "ordinador": {"ordenador", "computadora", "pc"}, "computadora": {"ordenador", "pc"},
    "movil": {"telefono", "celular", "smartphone"}, "telefono": {"movil", "celular"},
    "coche": {"auto", "automovil", "vehiculo", "cotxe"}, "cotxe": {"coche", "auto", "vehiculo"}, "auto": {"coche", "automovil"},
    "rapido": {"veloz", "rapidamente"}, "veloz": {"rapido"},
    "dinero": {"capital", "fondos"}, "trabajo": {"empleo", "labor"},
    "comprar": {"adquirir", "obtener"}, "adquirir": {"comprar"},
    "problema": {"dificultad", "inconveniente", "problema"}, "dificultad": {"problema"},
    "feina": {"trabajo", "empleo"}, "treball": {"trabajo", "empleo"},
    "avantatge": {"ventaja", "beneficio"}, "desavantatge": {"desventaja", "inconveniente"},
    "causa": {"motivo", "razon", "origen"}, "motivo": {"causa", "razon"},
    "ventaja": {"beneficio", "punto_fuerte"}, "desventaja": {"inconveniente", "limitacion", "riesgo", "problema", "dependencia"},
    "depende": {"limitacion", "condicion", "variable"}, "bajar": {"disminuir", "reducir", "descender"},
    "explicar": {"describir", "aclarar", "detallar"}, "definicion": {"significado", "concepto"},
    "crear": {"desarrollar", "construir", "producir"}, "desarrollar": {"crear", "construir"},
    "aumentar": {"incrementar", "crecer", "subir"}, "disminuir": {"reducir", "bajar"},
}

_INTENCIONES = {
    "causa": re.compile(r"\b(por que|porque|per que|perque|causa|motivo|razon|devido a|debido a|ja que)\b"),
    "proceso": re.compile(r"\b(como funciona|como se hace|com funciona|com es fa|com es|proceso|proces|pasos|passos|procedimiento|procediment)\b"),
    "comparacion": re.compile(r"\b(diferencia|diferencies|compar|versus|frente a|millor que|pitjor que|mejor que|peor que)\b"),
    "ventajas": re.compile(r"\b(ventajas|avantatges|beneficios|beneficis|puntos fuertes)\b"),
    "desventajas": re.compile(r"\b(desventajas|desavantatges|inconvenientes|limitaciones|limitacions|riesgos)\b"),
    "lista": re.compile(r"\b(tipos|tipus|clases|exemples|ejemplos|lista|llista|cuales son|quins son|quines son|menciona)\b"),
    "resumen": re.compile(r"\b(resumen|resume|resumeme|resumeix|resum|en pocas palabras|idea principal)\b"),
    "definicion": re.compile(r"\b(que es|que significa|què vol dir|define|definicion|definicio|concepte|concepto)\b"),
}


def normalizar(texto: str) -> str:
    texto = unicodedata.normalize("NFD", str(texto).lower())
    return "".join(c for c in texto if unicodedata.category(c) != "Mn")


def palabras(texto: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9]+", normalizar(texto)) if w not in _STOP and len(w) > 1]


def expandir_consulta(texto: str) -> str:
    """Añade sinónimos acotados para recuperar documentos con otras palabras."""
    base = palabras(texto)
    ampliadas = list(base)
    for palabra in base:
        ampliadas.extend(sorted(_SINONIMOS.get(palabra, ()))[:2])
    return " ".join(dict.fromkeys(ampliadas))


def detectar_intencion(consulta: str) -> str:
    n = normalizar(consulta)
    # «por qué» se separa de «porque» para no confundir pregunta con explicación.
    if re.search(r"\b(por que|per que)\b", n):
        return "causa"
    for nombre, patron in _INTENCIONES.items():
        if patron.search(n):
            return nombre
    return "general"


def extraer_entidades_comparadas(consulta: str) -> list[str]:
    """Recupera nombres versionados y abreviaciones con prefijo heredado."""
    patron = r"\b[A-Z][A-Za-z]{1,12}(?:[- ][A-Z]{1,4})?\s*\d+(?:\.\d+){0,2}\b"
    encontradas = list(re.finditer(patron, consulta))
    if not encontradas:
        return []
    entidades = [re.sub(r"\s+", " ", m.group(0)).strip() for m in encontradas]
    prefijo = re.match(r"(.+?)\s*\d+(?:\.\d+){0,2}$", entidades[0])
    if prefijo:
        resto = consulta[encontradas[0].end():]
        for numero in re.findall(r"(?<![A-Za-z])\d+(?:\.\d+){0,2}\b", resto):
            entidades.append(prefijo.group(1).strip() + " " + numero)
    return list(dict.fromkeys(entidades))


def planificar_investigacion(consulta: str, max_subconsultas: int = 8) -> list[str]:
    """Crea búsquedas atómicas para preguntas comparativas o con varios requisitos.

    Es un planificador léxico y transparente, no un modelo semántico. Conserva
    la consulta original y añade búsquedas por entidad/dimensión cuando detecta
    elementos comparados, fechas, velocidades o características.
    """
    original = re.sub(r"\s+", " ", consulta).strip(" ¿?¡!.")
    if not original:
        return []
    n = normalizar(original)
    plan = [original]

    # Identificadores técnicos versionados (PCIe 3.0, USB 4, Wi-Fi 7, etc.).
    entidades = extraer_entidades_comparadas(original)
    dimensiones = []
    if re.search(r"\b(velocidad|velocidades|ancho de banda|transferencia|rendimiento)\b", n):
        dimensiones.append("velocidad tasa de transferencia ancho de banda")
    if re.search(r"\b(fecha|fechas|ano|años|lanzamiento|publicacion|publicada|version)\b", n):
        dimensiones.append("fecha de lanzamiento publicación especificación")
    if re.search(r"\b(tecnic|caracteristic|arquitectura|codificacion|diferencia|diferencias)\b", n):
        dimensiones.append("características técnicas arquitectura diferencias")
    if entidades:
        for entidad in entidades:
            if dimensiones:
                plan.append(f"{entidad} " + " ".join(dimensiones))
            else:
                plan.append(f"{entidad} especificaciones características técnicas")
    else:
        # En preguntas generales se conserva una sola búsqueda salvo que se
        # soliciten explícitamente varias dimensiones independientes.
        pide_fechas = bool(re.search(r"\b(fecha|fechas|ano|años|cronologia|cuando)\b", n))
        pide_cifras = bool(re.search(r"\b(cifra|cifras|velocidad|velocidades|porcentaje|cantidad|cuanto)\b", n))
        pide_ventajas = bool(re.search(r"\b(ventajas|avantatges|beneficios|beneficis)\b", n))
        pide_limites = bool(re.search(r"\b(desventajas|desavantatges|inconvenientes|limitaciones|riesgos)\b", n))
        if sum((pide_fechas, pide_cifras, pide_ventajas, pide_limites)) >= 2:
            if pide_fechas:
                plan.append(f"{original} fechas cronología año")
            if pide_cifras:
                plan.append(f"{original} cifras valores numéricos unidades")
            if pide_ventajas:
                plan.append(f"{original} ventajas beneficios")
            if pide_limites:
                plan.append(f"{original} desventajas limitaciones riesgos")
    salida = []
    for q in plan:
        q = re.sub(r"\s+", " ", q).strip()
        if q and q.casefold() not in {x.casefold() for x in salida}:
            salida.append(q)
        if len(salida) >= max(1, max_subconsultas):
            break
    return salida


def descomponer_pregunta(consulta: str) -> list[str]:
    """Descompone peticiones compuestas en subobjetivos interpretables."""
    n = normalizar(consulta)
    partes = []
    if re.search(r"\b(ventajas|avantatges|beneficios|beneficis)\b", n):
        partes.append("ventajas y beneficios")
    if re.search(r"\b(desventajas|desavantatges|inconvenientes|limitaciones|riesgos)\b", n):
        partes.append("desventajas, inconvenientes y riesgos")
    if re.search(r"\b(como funciona|com funciona|como se hace|com es fa|proceso|processos|pasos|passos)\b", n):
        partes.append("funcionamiento y pasos")
    if re.search(r"\b(ejemplos|por ejemplo)\b", n):
        partes.append("ejemplos")
    return partes


def _es_ruido_documental(linea: str) -> bool:
    """Descarta rutas, trazas y líneas de metadatos que no son evidencia lingüística."""
    x = linea.strip()
    if not x:
        return True
    if re.match(r"^(?:/home/|/mnt/|/tmp/|/run/|[A-Za-z]:[\\/])", x):
        return True
    if x.count("/") >= 3 or x.count("\\") >= 3:
        return True
    if re.search(r"(?:documents|documentos)/.*(?:corpus|entrenamiento|aria)", x, re.I):
        return True
    return False


def _limpiar_linea_documental(linea: str) -> str:
    """Normaliza una línea de documento y elimina encabezados/metadatos."""
    x = (linea or "").strip()
    if not x or _es_ruido_documental(x):
        return ""
    # Los encabezados Markdown describen la estructura, no son contenido-respuesta.
    if re.match(r"^#{1,6}\s+", x):
        return ""
    x = re.sub(r"^[-*•]+\s*", "", x)
    x = x.replace("**", "").replace("`", "").strip()
    if not x or len(x) < 24:
        return ""
    # Encabezados y etiquetas editoriales no deben convertirse en respuestas.
    if re.match(r"^(?:definicion(?! breve)|glosario|concepto central|fuentes|fuente|preguntas para comprobar|lista de comprobacion|actividad \d+)\b", normalizar(x)):
        return ""
    if re.match(r"^(?:concepto central|definicion breve|procedimiento asociado|ejemplo de referencia|riesgo de interpretacion):", normalizar(x)):
        x = x.split(":", 1)[1].strip()
    if len(x) < 24:
        return ""
    return x


def _frases(textos):
    """Extrae frases útiles conservando el documento de origen y su posición."""
    salida = []
    for origen, texto in enumerate(textos):
        # Los fragmentos de la memoria pueden haber unido párrafos Markdown
        # mediante espacios. Recupera los límites de encabezados antes de puntuar.
        texto = texto or ""
        texto = re.sub(r"(?i)#\s*glosario y relaciones:.*?(?=Concepto central:)", "", texto)
        texto = re.sub(r"(?m)(?:^|\s)#{1,6}\s*[^#\n]*(?=\s+#{1,6}\s*|\n|$)", "\n", texto)
        texto = re.sub(
            r"\s+(?=(?:Concepto central|Definición breve|Procedimiento asociado|Ejemplo de referencia|Riesgo de interpretación|Relaciones útiles|Preguntas relacionadas):)",
            "\n", texto, flags=re.I)
        pos = 0
        for linea in re.split(r"\n+", texto):
            linea = _limpiar_linea_documental(linea)
            if not linea:
                pos += 1
                continue
            # Cada línea puede contener varios enunciados; no mezclar títulos con prosa.
            for frase in re.split(r"(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÜ¿¡])", linea):
                frase = frase.strip(" \t-*•#")
                if len(frase) >= 24 and not _es_ruido_documental(frase):
                    salida.append((frase, origen, pos))
            pos += 1
    return salida


def _similitud(consulta, frase):
    q, f = set(palabras(consulta)), set(palabras(frase))
    if not q or not f:
        return 0.0
    cobertura = len(q & f) / len(q)
    jaccard = len(q & f) / len(q | f)
    fuzzy = (fuzz.token_set_ratio(normalizar(consulta), normalizar(frase)) / 100) if fuzz else 0.0
    return min(1.0, 0.58 * cobertura + 0.22 * jaccard + 0.20 * fuzzy)


def _puntuacion(consulta, frase, intencion):
    n = normalizar(frase)
    score = _similitud(consulta, frase)
    if intencion == "causa" and re.search(r"\b(porque|debido a|ya que|puesto que|a causa de|por ello)\b", n):
        score += 0.16
    elif intencion == "proceso" and re.search(r"\b(primero|despues|luego|finalmente|consiste|proceso|mediante)\b", n):
        score += 0.12
    elif intencion == "ventajas" and re.search(r"\b(ventaja|beneficio|permite|mejora|facilita)\b", n):
        score += 0.14
    elif intencion == "desventajas" and re.search(r"\b(desventaja|riesgo|limita|problema|inconveniente|sin embargo|depende|puede bajar|puede disminuir|no obstante)\b", n):
        score += 0.14
    elif intencion == "definicion" and re.search(r"\b(es|significa|se define|consiste en|se trata de)\b", n):
        score += 0.10
    return min(1.0, score)


def _limpiar_repeticiones(frases):
    elegidas, vistos = [], set()
    for frase in frases:
        clave = " ".join(palabras(frase))
        if not clave or clave in vistos:
            continue
        if any(_similitud(frase, anterior) > 0.88 for anterior in elegidas):
            continue
        vistos.add(clave)
        elegidas.append(frase)
    return elegidas


def _es_catalan(consulta: str) -> bool:
    n = normalizar(consulta)
    indicios = ("com funciona", "per que", "perque", "quin ", "quina ",
                "quins ", "quines ", "avantatges", "desavantatges",
                "resumeix", "diferencies", "amb ")
    return sum(1 for x in indicios if x in n) >= 1 or bool(re.search(r"\bexplica'm\b", n))


def componer_respuesta(consulta: str, textos: list[str], max_frases: int = 4, fuentes=None) -> dict:
    """Construye explicaciones legibles a partir de evidencias locales.

    No usa un LLM: selecciona, limpia, relaciona y ordena frases de las fuentes.
    La respuesta conserva los límites de la evidencia y nunca inventa datos para
    rellenar una explicación.
    """
    if not textos:
        return {"texto": "", "confianza": 0.0, "cubierto": []}
    intencion = detectar_intencion(consulta)
    subobjetivos = descomponer_pregunta(consulta)
    candidatas = _frases(textos)
    if not candidatas:
        return {"texto": "", "confianza": 0.0, "cubierto": []}

    puntuadas = sorted(
        ((_puntuacion(consulta, f, intencion), f, origen, pos) for f, origen, pos in candidatas),
        key=lambda x: (x[0], -x[2], -x[3]), reverse=True,
    )
    umbral = 0.10 if intencion == "general" else 0.12
    anclas = [(score, frase, origen, pos) for score, frase, origen, pos in puntuadas if score >= umbral]
    if not anclas:
        return {"texto": "", "confianza": puntuadas[0][0], "cubierto": []}

    seleccion = []
    # Para una definición, explicación general o proceso, una frase definitoria
    # puede aportar el vocabulario que conecta otras frases del mismo párrafo.
    primera = anclas[0]
    seleccion.append(primera[1])
    tema_tokens = set(palabras(consulta))
    mismo_parrafo = [x for x in puntuadas if x[2] == primera[2] and x[3] == primera[3] and x[1] != primera[1]]
    mismo_parrafo.sort(key=lambda x: x[0], reverse=True)
    for _, frase, _, _ in mismo_parrafo:
        if len(seleccion) >= max_frases:
            break
        seleccion.append(frase)
    tokens_ancla = set().union(*(set(palabras(x)) for x in seleccion))

    # Prioriza evidencia de la misma fuente o que comparte conceptos concretos
    # con la definición principal. Esto evita devolver solo el título/glosario.
    relacionadas = []
    for score, frase, origen, pos in puntuadas:
        if frase in seleccion:
            continue
        ft = set(palabras(frase))
        solape_ancla = len((ft - _STOP) & (tokens_ancla - _STOP))
        solape_tema = len(ft & tema_tokens)
        misma_fuente = origen == primera[2]
        if misma_fuente and solape_ancla >= 1:
            relacionado = score + 0.12 + min(0.12, solape_ancla * 0.025)
        elif solape_ancla >= 2:
            relacionado = score + min(0.10, solape_ancla * 0.02)
        else:
            relacionado = score
        if relacionado >= umbral and (misma_fuente and solape_ancla >= 1 or solape_ancla >= 2 or solape_tema >= 1):
            relacionadas.append((relacionado, frase, origen, pos))
    relacionadas.sort(key=lambda x: (x[0], -x[2], -x[3]), reverse=True)

    # En preguntas compuestas, reservar una evidencia por subobjetivo.
    for objetivo in subobjetivos:
        mejor = max(candidatas, key=lambda x: _puntuacion(objetivo, x[0], detectar_intencion(objetivo)), default=None)
        if mejor and _puntuacion(objetivo, mejor[0], detectar_intencion(objetivo)) >= 0.12:
            if mejor[0] not in seleccion:
                seleccion.append(mejor[0])

    for _, frase, _, _ in relacionadas:
        if len(seleccion) >= max_frases:
            break
        if frase not in seleccion:
            seleccion.append(frase)

    seleccion = _limpiar_repeticiones(seleccion)[:max_frases]
    # Segunda capa general: consolida afirmaciones entre documentos, elimina
    # duplicados semánticos y busca complementariedad sin reglas por disciplina.
    # La síntesis multi-fuente se aplica a resultados web identificables.
    # La memoria local conserva el constructor estructural existente (incluidos
    # los seguimientos breves que heredan el tema de la conversación).
    es_web = bool(fuentes) and any(
        isinstance(f, (tuple, list)) and len(f) and str(f[0]).startswith(("http://", "https://"))
        for f in fuentes
    )
    consolidada = sintesis.consolidar(consulta, textos, fuentes=fuentes, max_frases=max_frases) if es_web else {}
    if consolidada.get("afirmaciones"):
        seleccion = consolidada["afirmaciones"]
    if not seleccion:
        return {"texto": "", "confianza": puntuadas[0][0], "cubierto": []}

    mejor_score = max(x[0] for x in puntuadas)
    media = sum(_puntuacion(consulta, f, intencion) for f in seleccion) / len(seleccion)
    confianza = round(min(0.96, 0.55 * mejor_score + 0.45 * media), 2)

    catalan = _es_catalan(consulta)
    if catalan:
        inicios = {
            "causa": "L’explicació disponible descriu la causa així:",
            "proceso": "El funcionament es pot descriure en aquests passos:",
            "comparacion": "La comparació que permeten les fonts és aquesta:",
            "ventajas": "Els avantatges que indiquen les fonts són:",
            "desventajas": "Les limitacions que indiquen les fonts són:",
            "definicion": "El concepte es pot explicar així:",
            "resumen": "En resum, les idees principals són:",
            "lista": "Els elements que apareixen a les fonts són:",
            "general": "Aquesta és la informació més rellevant que he trobat:",
        }
    else:
        inicios = {
            "causa": "La explicación disponible describe la causa así:",
            "proceso": "El funcionamiento se puede describir de esta manera:",
            "comparacion": "La comparación que permiten las fuentes es esta:",
            "ventajas": "Las ventajas que indican las fuentes son:",
            "desventajas": "Las limitaciones que indican las fuentes son:",
            "definicion": "El concepto se puede explicar así:",
            "resumen": "En resumen, las ideas principales son:",
            "lista": "Los elementos que aparecen en las fuentes son:",
            "general": "Esta es la información más relevante que he encontrado:",
        }
    inicio = inicios.get(intencion, inicios["general"])

    # Respuestas en prosa, no una lista de fragmentos sin conexión.
    # Un único párrafo permite leer las afirmaciones como una explicación,
    # no como una colección de citas inconexas.
    cuerpo = " ".join(seleccion)
    aviso = ""
    if confianza < 0.22:
        aviso = "\n\n_No tengo evidencias suficientes para afirmarlo con seguridad; esto es una coincidencia parcial._"
    elif confianza < 0.38:
        aviso = "\n\n_La respuesta es provisional: convendría contrastarla con más información._"
    return {
        "texto": inicio + "\n\n" + cuerpo + aviso,
        "confianza": confianza,
        "cubierto": subobjetivos,
        "corroboradas": consolidada.get("corroboradas", []),
        "dominios": consolidada.get("dominios", []),
    }

