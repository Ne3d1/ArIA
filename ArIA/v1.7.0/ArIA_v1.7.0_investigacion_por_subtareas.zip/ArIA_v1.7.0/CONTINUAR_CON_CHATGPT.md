# Continuidad del proyecto — ArIA v1.7.0

## Estado de esta versión

La v1.7.0 parte de v1.6.0 y añade investigación por subtareas para preguntas complejas. La v1.6.0 ya aportaba síntesis multi-fuente, sin reglas exclusivas de computación cuántica. El sistema segmenta afirmaciones, agrupa definiciones directas equivalentes, elimina duplicados, utiliza afirmaciones pertinentes como anclas para recuperar detalles complementarios y selecciona aportaciones distintas. La salida web se presenta en prosa continua y conserva las fuentes consultadas.

La capa nueva cuenta dominios distintos que contienen una afirmación equivalente. La interfaz lo describe como coincidencia entre dominios, no como verificación. Se ha eliminado el porcentaje de «ajuste temático» de la respuesta visible.

## Cambios técnicos

- `aria/razonamiento.py`: `planificar_investigacion` genera búsquedas por entidad y dimensión para comparaciones explícitas; `extraer_entidades_comparadas` propaga prefijos versionados omitidos en listas como «PCIe 3.0, 4.0, 5.0 y 6.0». Las consultas sencillas conservan una sola búsqueda.
- `aria/cerebro.py`: ejecuta las subconsultas, agrega resultados por URL, extrae evidencias contra cada entidad y combina afirmaciones de distintas páginas. Si una entidad no aparece en las evidencias seleccionadas, añade una nota de cobertura parcial.
- Se añadieron pruebas de planificación y una integración simulada que comprueba que cada versión PCIe se investiga por separado.

- Nuevo módulo `aria/sintesis.py` para consolidación de afirmaciones independiente del tema.
- `aria/web.py`: `extraer_evidencias` utiliza anclas conceptuales derivadas de definiciones y evidencias relacionadas; se eliminó el alias temático específico de computación cuántica.
- `aria/cerebro.py`: investigación en dos pasadas; las evidencias de todas las fuentes pueden aportar anclas para recuperar detalles complementarios en otras fuentes. La memoria guarda solo el texto seleccionado.
- `aria/razonamiento.py`: integración de síntesis para resultados web; se mantiene el constructor de memoria local para no romper seguimientos contextuales.
- La respuesta informa cuando una afirmación aparece en más de un dominio, con una advertencia explícita de que no es verificación independiente.

## Pruebas y validación

- `python -m compileall -q aria main.py tests`
- `python -m unittest discover -q`: 78 pruebas superadas en esta versión.
- La suite de integración web usa respuestas simuladas; no se ha realizado una búsqueda real en Internet.
- Pendiente ejecutar `./test.sh` y `test.bat` en instalaciones limpias de Linux y Windows.
- Pendiente probar USB en FAT/exFAT/NTFS y revisar permisos de ejecución.

## Límites conocidos

- Coincidencia de dominios no demuestra independencia editorial ni veracidad.
- No existe aún un detector semántico robusto de contradicciones.
- El motor sigue siendo heurístico y local; no es un LLM generativo de propósito general.
- La extracción puede fallar en páginas con JavaScript, paywalls, contenido dinámico o estructura atípica.
- Los fragmentos web antiguos almacenados en la memoria de instalaciones previas no se migran ni eliminan automáticamente.

## Próximos pasos

1. Ejecutar un conjunto de búsquedas reales, en español y catalán, sobre comparaciones técnicas, ciencia, historia, economía y programación.
2. Mejorar la extracción de entidades y dimensiones en lenguaje natural, incluidas comparaciones sin identificadores versionados.
3. Añadir cobertura por dimensión (fechas, cifras, características) además de cobertura por entidad.
4. Extraer afirmaciones atómicas con URL, título, fecha de consulta, fragmento exacto, idioma y huella de contenido.
5. Mejorar la deduplicación entre paráfrasis y detectar contradicciones explícitas con trazabilidad a los pasajes.
6. Incorporar estados separados: recuperado, repetido en varias fuentes, contrastado y verificado manualmente.
7. Añadir controles de calidad para que ningún puntaje heurístico se presente como probabilidad de verdad.

Mantener los requisitos del proyecto: ejecución local, sin APIs de modelos generativos externos; memoria/RAG no equivale a entrenamiento neuronal; preservar la identidad nuclear de ArIA; conservar soporte Windows/Linux y el entorno virtual local para USB; no afirmar pruebas no realizadas.
