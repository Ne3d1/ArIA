# Continuación del desarrollo de ArIA

Este archivo permite que otra IA o desarrollador continúe el trabajo sin tener que reconstruir el contexto.

## Estado de esta versión

- Proyecto: ArIA, versión 1.4.0 (revisión de respuesta local).
- Base: ArIA v1.2.0 proporcionada por la creadora.
- Creadora declarada: **Aria català**.
- Ayudantes de desarrollo declarados: **Claude y CatGPT**.
- Objetivo: asistente local que aprende de archivos y textos, recupera evidencias y genera texto mediante componentes propios.

## Cambios ya realizados

1. Se ha corregido `aria/nucleo.py` para reconocer preguntas sobre la creadora y los ayudantes con saludos, errores tipográficos frecuentes, preguntas compuestas y catalán. La identidad se resuelve antes de consultar la memoria general.
2. `aria/identidad.md` se ha actualizado y ya no incluye una biografía personal no necesaria.
3. Se ha añadido `aria/entrada.py` para limpiar caracteres Unicode invisibles, BOM y espacios no separables sin alterar bloques de código.
4. Se ha ampliado `aria/razonamiento.py` con intenciones, vocabulario y estructuras de respuesta en catalán.
5. Se han añadido pruebas de regresión para identidad, lectura de prompts y respuestas en catalán.
6. Se han actualizado los instaladores y lanzadores Linux/Windows. En Linux, si el USB no permite enlaces simbólicos, el entorno virtual va a `~/.cache/aria/venvs/`. En Windows va a `%LOCALAPPDATA%\ArIA\venvs\`. El proyecto y sus datos pueden permanecer en USB.
7. Se ha ampliado el corpus a 36 archivos en castellano y catalán. Hay textos de prompts, redacción, razonamiento, ciencia, matemáticas, informática, programación, seguridad y ejemplos JSONL.

## Independencia de modelos externos

No añadir llamadas ni dependencias a OpenAI, Anthropic/Claude, CatGPT, Ollama, Hugging Face, Gemini ni otros proveedores de modelos. Claude y CatGPT aparecen únicamente como ayudantes de desarrollo en la identidad del proyecto. `torch` es una biblioteca local de cálculo para entrenar desde cero el pequeño Transformer propio de ArIA; no es un modelo preentrenado ni un servicio remoto. La búsqueda web explícita recupera páginas y no delega la generación de respuestas a otra IA.

## Pruebas

Ejecutar desde la raíz del proyecto:

```bash
python -m compileall -q aria main.py tests
python -m unittest discover -v
```

Los scripts `test.sh` y `test.bat` ejecutan estas comprobaciones usando el entorno virtual del sistema correspondiente.

## Próximos pasos recomendados

1. Probar `setup.bat`, `run.bat` y `test.bat` en un Windows real; la sintaxis se ha revisado, pero este entorno de desarrollo no ejecuta Windows.
2. Probar instalación y ejecución desde un USB FAT/exFAT en Linux y desde una carpeta local en Windows.
3. Ampliar las pruebas de preguntas en catalán y castellano sin reducir la prioridad de la identidad nuclear.
4. Mejorar el análisis semántico de preguntas compuestas manteniendo respuestas basadas en evidencias y evitando inventar hechos.
5. Medir el entrenamiento del Transformer con corpus más amplios. No presentar el modelo pequeño como equivalente a un LLM moderno: requiere muchos más datos y entrenamiento y puede producir texto imperfecto.
6. Si se modifica el formato de memoria SQLite, añadir migraciones compatibles y pruebas de persistencia.

## Cómo cargar el corpus

Ejecutar `./importar_corpus.sh` en Linux o `importar_corpus.bat` en Windows. El script importa el ZIP v3 directamente y crea 217 pares QA deduplicados en la prueba de referencia. La identidad no depende de esta importación porque está integrada en `aria/nucleo.py`.

## Regla de entrega

Si el siguiente asistente no puede completar todo el trabajo, debe entregar el ZIP en el estado actual, indicar exactamente qué pruebas ha ejecutado y enumerar los pendientes. No debe afirmar que ha probado Windows si no lo ha ejecutado en Windows.

## Cambios de la revisión 1.4.0

- Se ha incorporado el corpus v3 como ZIP dentro de `recursos/`.
- Se añadió `importar_corpus.py` y lanzadores `.sh` / `.bat` para importar el ZIP directamente, por bloques, sin extraerlo entero y sin límite artificial de tamaño de archivo.
- La recuperación de respuestas valida la cobertura respecto a los términos originales de la consulta, no respecto a la consulta expandida con sinónimos.
- Se eliminó el fallback que podía devolver el primer fragmento aunque no contuviera una respuesta útil.
- El razonamiento y el corpus neuronal filtran rutas absolutas y ruido de indexación.
- El Transformer requiere al menos 10.000 caracteres limpios y descarta checkpoints anteriores entrenados con muestras insuficientes.
- La generación comprueba señales básicas de calidad antes de mostrar el resultado.

Importante: importar el corpus añade conocimiento recuperable a SQLite; el entrenamiento neuronal es un paso distinto y debe ejecutarse después con `/entrenar-modelo`.
